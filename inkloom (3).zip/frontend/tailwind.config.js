/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{ts,tsx}'],
  theme: {
    extend: {
      colors: {
        inkloom: { paper: '#f7f7f2', ink: '#173b32', green: '#1f5b4b', mint: '#e1eee8', amber: '#f0bd66' },
      },
    },
  },
  plugins: [],
};
