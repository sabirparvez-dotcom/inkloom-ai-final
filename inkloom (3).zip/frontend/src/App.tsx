import { useCallback, useEffect, useRef, useState } from 'react';
import {
  AlertCircle, ArrowDownToLine, ArrowRight, BadgeCheck, BarChart3, BookOpenCheck, Check,
  CheckCircle2, ChevronRight, ClipboardCheck, Clock3, FileCheck2, FileText, Home, Info,
  Files, LoaderCircle, Plus, RefreshCw, RotateCcw, ScanText, ShieldCheck, Sparkles, Trash2,
  MessageSquare, Upload, X, type LucideIcon,
} from 'lucide-react';
import {
  Bar, BarChart, CartesianGrid, Cell, Pie, PieChart, ResponsiveContainer, Tooltip, XAxis, YAxis,
} from 'recharts';
import { api } from './api';
import type {
  ApprovedClaim, AuditEntry, BatchCheckItem, BannedTerm, Channel, DashboardData, Disclaimer, Draft, DraftComment, DraftHistory, EvaluationInfo, EvaluationRun, EvidenceDocument,
  Evidence, Finding, Guidelines, HealthScoreBreakdown, PreferredTerm, Product, RevisionComparison, Role, SampleDraft, ServiceStatus, Severity, ToneRule,
} from './types';

const NAV_ITEMS: { id: View; label: string; icon: LucideIcon; roles?: Role[] }[] = [
  { id: 'home', label: 'Overview', icon: Home },
  { id: 'new', label: 'New content', icon: ScanText, roles: ['Creator'] },
  { id: 'batch', label: 'Batch check', icon: Files, roles: ['Creator'] },
  { id: 'review', label: 'Review queue', icon: ClipboardCheck, roles: ['Reviewer'] },
  { id: 'dashboard', label: 'Dashboard', icon: BarChart3 },
  { id: 'history', label: 'History', icon: Clock3 },
  { id: 'guidelines', label: 'Guidelines', icon: BookOpenCheck, roles: ['Admin'] },
  { id: 'evidence', label: 'Evidence library', icon: FileCheck2, roles: ['Admin'] },
  { id: 'evaluation', label: 'Evaluation', icon: Sparkles, roles: ['Admin'] },
  { id: 'audit-log', label: 'Audit log', icon: FileText, roles: ['Admin'] },
  { id: 'status', label: 'Status', icon: Info },
];
type View = 'home' | 'new' | 'batch' | 'report' | 'review' | 'dashboard' | 'history' | 'guidelines' | 'evidence' | 'evaluation' | 'audit-log' | 'status';
const ROUTE_PATHS: Record<View, string> = {
  home: '/', new: '/new', batch: '/batch', report: '/report', review: '/review', dashboard: '/dashboard',
  history: '/history', guidelines: '/guidelines', evidence: '/evidence', evaluation: '/evaluation', 'audit-log': '/audit-log', status: '/status',
};
function viewFromPath(path: string): View {
  return (Object.entries(ROUTE_PATHS).find(([, route]) => route === path)?.[0] as View | undefined) ?? 'home';
}
type EditorKind = 'product' | 'term' | 'preferred' | 'claim' | 'tone' | 'disclaimer' | 'logo';
type Editor = { kind: EditorKind; id: number | null; title: string; values: Record<string, string | number | boolean | null> };
const VIEW_NAMES: Record<View, string> = {
  home: 'Overview', new: 'New content', batch: 'Batch check', report: 'Review report', review: 'Review queue',
  dashboard: 'Dashboard', history: 'History', guidelines: 'Guideline manager', evidence: 'Evidence library',
  evaluation: 'Evaluation', 'audit-log': 'Audit log', status: 'Service status',
};
const SEVERITY_COLORS: Record<Severity, string> = { High: '#bc5048', Medium: '#c28b31', Low: '#72917e', Info: '#8b8ca0' };

function humanize(value: string) {
  return value.replaceAll('_', ' ').replace(/\b\w/g, (letter) => letter.toUpperCase());
}
function dateLabel(value?: string) {
  if (!value) return 'Just now';
  const date = new Date(value);
  return Number.isNaN(date.getTime()) ? value : date.toLocaleString([], { dateStyle: 'medium', timeStyle: 'short' });
}
function statusLabel(status?: string) {
  return (status || 'draft').replaceAll('_', ' ');
}
function messageFrom(error: unknown) {
  return error instanceof Error ? error.message : 'Something went wrong. Please try again.';
}

function IconMark() {
  return <div className="brand-mark" aria-hidden="true"><img src="/inkloom-mark.svg" width="34" height="34" alt="" /></div>;
}

function StatusBadge({ status }: { status: string }) {
  return <span className={`status ${status.replaceAll(' ', '_')}`}>{statusLabel(status)}</span>;
}

function CreativeAssetPanel({ draft }: { draft: Draft }) {
  const creative = draft.creative;
  if (!creative) return null;
  return <section className="card panel creative-preview" aria-label="Uploaded ad creative and visual check status">
    <div className="card-heading"><div><h2>Ad creative · visual checks</h2><div className="small-copy" style={{ marginTop: 4 }}>{creative.source_filename}</div></div><span className="source-badge visual">OCR + OpenCV</span></div>
    <img src={`/api/drafts/${draft.id}/creative`} alt={`Uploaded ad creative ${creative.source_filename}`} loading="lazy" />
    <div className="creative-status"><p><strong>OCR:</strong> {creative.ocr_notice || (draft.text ? 'Readable text was extracted and passed to the existing checks.' : 'No readable text was extracted; text checks were skipped.')}</p><p><strong>Logo:</strong> {creative.logo_notice || 'Logo matching did not return a status.'}</p></div>
  </section>;
}

function HealthScorePanel({ breakdown }: { breakdown: HealthScoreBreakdown }) {
  return <section className="card panel health-score-panel" title={breakdown.formula} aria-label={`Brand Health Score ${breakdown.score} out of 100`}>
    <div className="health-score-main"><span className="small-copy">Brand Health Score</span><strong>{breakdown.score}<small>/100</small></strong></div>
    <div className="health-score-breakdown">{(['High', 'Medium', 'Low'] as const).map((severity) => <div key={severity}><span>{severity} · {breakdown.weights[severity]} points each</span><b>{breakdown.counts[severity]} finding(s) · −{breakdown.deductions[severity]}</b></div>)}<small>{breakdown.formula}</small></div>
  </section>;
}

function PageHeading({ eyebrow, title, subtitle, action }: { eyebrow?: string; title: string; subtitle?: string; action?: React.ReactNode }) {
  return <div className="page-heading"><div>{eyebrow && <div className="eyebrow">{eyebrow}</div>}<h1 className="page-title">{title}</h1>{subtitle && <p className="page-subtitle">{subtitle}</p>}</div>{action}</div>;
}

function LoadingButton({ busy, children, ...props }: React.ButtonHTMLAttributes<HTMLButtonElement> & { busy?: boolean }) {
  return <button {...props} disabled={props.disabled || busy} className={`button ${props.className || ''}`}>{busy ? <span className="spinner" aria-label="Working" /> : null}{children}</button>;
}

function HighlightedDraft({ text, findings }: { text: string; findings: Finding[] }) {
  const spans = findings.filter((finding) => finding.start >= 0 && finding.end > finding.start && finding.end <= text.length)
    .sort((a, b) => a.start - b.start || a.end - b.end);
  const pieces: React.ReactNode[] = [];
  let cursor = 0;
  spans.forEach((finding, index) => {
    if (finding.start < cursor) return;
    if (finding.start > cursor) pieces.push(<span key={`plain-${index}`}>{text.slice(cursor, finding.start)}</span>);
    pieces.push(<mark className="mark" key={`mark-${index}`} title={`${humanize(finding.type)} · ${finding.severity}`}>{text.slice(finding.start, finding.end)}</mark>);
    cursor = finding.end;
  });
  if (cursor < text.length) pieces.push(<span key="plain-end">{text.slice(cursor)}</span>);
  return <div className="draft-paper" aria-label="Draft with flagged passages highlighted">{pieces.length ? pieces : text}</div>;
}

function FindingCard({ finding, findingIndex, onApply, onEvidence, onDismiss, onLabel, canEdit, canReview, busy, reviewerBusy }: {
  finding: Finding; findingIndex: number; onApply: (finding: Finding) => void; onEvidence: (evidence: Evidence) => void;
  onDismiss: (findingIndex: number, reason: string) => void;
  onLabel: (findingIndex: number, reviewerLabel: 'valid' | 'false_positive' | null) => void;
  canEdit: boolean; canReview: boolean; busy: boolean; reviewerBusy: boolean;
}) {
  const dismissWithReason = () => {
    const reason = window.prompt('Why is this finding being dismissed? The reason will be saved in the review history.');
    if (reason?.trim()) onDismiss(findingIndex, reason.trim());
  };
  return <article className={`finding-card ${finding.severity.toLowerCase()}`}>
    <div className="finding-top"><div className="finding-type">{humanize(finding.type)}</div><div className="finding-meta"><span className={`severity ${finding.severity.toLowerCase()}`}>{finding.severity}</span><span className={`source-badge ${finding.source === 'AI' ? 'ai' : finding.source === 'Visual' ? 'visual' : ''}`}>{finding.source}</span></div></div>
    <p>{finding.explanation}</p>
    {finding.span && <div className="small-copy"><strong>Flagged text:</strong> “{finding.span}”</div>}
    {finding.severity_downgraded_by_feedback && <div className="feedback-downgrade">{finding.severity_note || 'Downgraded by reviewer feedback'}</div>}
    <div className="finding-suggestion"><strong>Suggested correction</strong><br />{finding.suggestion}</div>
    {finding.uncertainty && <div className="uncertainty"><Sparkles size={12} style={{ verticalAlign: 'middle', marginRight: 5 }} />{finding.uncertainty}</div>}
    {finding.evidence.map((evidence, index) => <div className="evidence-row" key={`${evidence.guideline_ref}-${index}`}><FileCheck2 size={13} /><span><strong>{evidence.label}</strong>{evidence.detail ? ` · ${evidence.detail}` : ''} <button onClick={() => onEvidence(evidence)}>View guideline</button></span></div>)}
    {finding.reviewer_label && <div className="reviewer-annotation"><strong>Reviewer feedback:</strong> {humanize(finding.reviewer_label)} <span>· informs future checks; this saved revision stays unchanged</span></div>}
    {finding.dismissal_reason && <div className="dismissal-note"><strong>Dismissed by {finding.dismissed_by_role || 'Reviewer'}:</strong> {finding.dismissal_reason}{finding.dismissed_at && <small style={{ display: 'block', marginTop: 4 }}>{dateLabel(finding.dismissed_at)}</small>}</div>}
    {canReview && <div className="reviewer-actions"><strong>Reviewer tools · labels inform future checks; this saved check and score stay unchanged</strong><div>
      <button className="button button-secondary button-small" disabled={reviewerBusy} onClick={() => onLabel(findingIndex, 'valid')}>Mark valid</button>
      <button className="button button-secondary button-small" disabled={reviewerBusy} onClick={() => onLabel(findingIndex, 'false_positive')}>Mark false positive</button>
      {finding.reviewer_label && <button className="button button-secondary button-small" disabled={reviewerBusy} onClick={() => onLabel(findingIndex, null)}>Clear label</button>}
      <button className="button button-danger button-small" disabled={reviewerBusy} onClick={dismissWithReason}>Dismiss with reason</button>
    </div></div>}
    {canEdit && <div className="form-actions"><button className="button button-secondary button-small" disabled={busy} onClick={() => onApply(finding)}><Check size={13} />Apply fix</button></div>}
  </article>;
}

function DraftComments({ draftId, role }: { draftId: number; role: Role }) {
  const [comments, setComments] = useState<DraftComment[]>([]);
  const [message, setMessage] = useState('');
  const [loading, setLoading] = useState(true);
  const [posting, setPosting] = useState(false);
  const [error, setError] = useState('');
  const loadComments = useCallback(async () => {
    setLoading(true);
    try { setComments(await api.comments(draftId)); setError(''); }
    catch (cause) { setError(messageFrom(cause)); }
    finally { setLoading(false); }
  }, [draftId]);
  useEffect(() => { void loadComments(); }, [loadComments]);
  const postComment = async (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (!message.trim()) return;
    setPosting(true); setError('');
    try {
      const added = await api.addComment(draftId, message.trim(), role);
      setComments((existing) => [...existing, added]);
      setMessage('');
    } catch (cause) { setError(messageFrom(cause)); }
    finally { setPosting(false); }
  };
  return <section className="card panel comment-thread" aria-labelledby={`comments-title-${draftId}`}>
    <div className="card-heading"><div><h2 id={`comments-title-${draftId}`}><MessageSquare size={15} style={{ verticalAlign: 'middle', marginRight: 6 }} />Draft discussion</h2><div className="small-copy" style={{ marginTop: 4 }}>Comments are saved to this draft and appear in its history and PDF report.</div></div></div>
    {error && <div className="notice-banner" role="alert">{error}</div>}
    {loading ? <div className="small-copy" aria-live="polite">Loading comments…</div> : comments.length ? <ol className="comment-list">{comments.map((comment) => <li className="comment-item" key={comment.id}><div className="comment-item-head"><strong>{comment.actor_role}</strong><time dateTime={comment.created_at}>{dateLabel(comment.created_at)}</time></div><p>{comment.message}</p></li>)}</ol> : <div className="empty-state" style={{ padding: 15 }}><strong>No comments yet.</strong><p>Leave a note for the next person reviewing this draft.</p></div>}
    <form className="comment-compose" onSubmit={postComment}><label htmlFor={`comment-${draftId}`}>Add a comment as {role}</label><textarea id={`comment-${draftId}`} maxLength={2000} value={message} onChange={(event) => setMessage(event.target.value)} placeholder="Add context, a question, or a review note…" /><div className="form-actions"><button className="button button-primary button-small" type="submit" disabled={posting || !message.trim()}>{posting ? <LoaderCircle size={13} className="spin" /> : <MessageSquare size={13} />}Add comment</button><span className="field-hint">{message.length} / 2,000</span></div></form>
  </section>;
}

function GuidelineRows({ rows, highlighted, onEdit, onDelete, canManage }: {
  rows: { id: number; guideline_ref: string; title: string; subtitle: string }[]; highlighted: string | null;
  onEdit: (row: { id: number; guideline_ref: string }) => void; onDelete: (id: number) => void;
  canManage: boolean;
}) {
  if (!rows.length) return <div className="small-copy">No records yet.</div>;
  return <div className="guideline-list">{rows.map((row) => <div className="guideline-row" key={row.id} data-guideline-ref={row.guideline_ref} style={highlighted === row.guideline_ref ? { background: '#f5f8e9', borderRadius: 8, paddingLeft: 8, paddingRight: 6 } : undefined}>
    <div><strong>{row.title}</strong><small>{row.subtitle}</small></div>{canManage && <div className="row-actions"><button className="icon-button" aria-label={`Edit ${row.title}`} title="Edit" onClick={() => onEdit(row)}><FileText size={14} /></button><button className="icon-button" aria-label={`Delete ${row.title}`} title="Delete" onClick={() => onDelete(row.id)}><Trash2 size={14} /></button></div>}
  </div>)}</div>;
}

function EditorModal({ editor, setEditor, onSave, busy }: { editor: Editor | null; setEditor: (value: Editor | null) => void; onSave: () => void; busy: boolean }) {
  if (!editor) return null;
  const fieldConfig: Record<EditorKind, { key: string; label: string; type?: string }[]> = {
    product: [{ key: 'name', label: 'Product name' }, { key: 'approved_price', label: 'Approved price (₹)', type: 'number' }, { key: 'material', label: 'Material' }],
    term: [{ key: 'term', label: 'Banned term' }],
    preferred: [{ key: 'term', label: 'Wording to replace' }, { key: 'preferred', label: 'Preferred wording' }],
    claim: [{ key: 'claim', label: 'Approved claim' }, { key: 'evidence', label: 'Evidence record' }],
    tone: [{ key: 'name', label: 'Rule name' }, { key: 'description', label: 'Guidance' }, { key: 'threshold', label: 'Numeric threshold (optional)', type: 'number' }, { key: 'enabled', label: 'Enabled (true/false)' }],
    disclaimer: [{ key: 'phrase', label: 'Required phrase' }, { key: 'applies_to', label: 'Applies to' }],
    logo: [{ key: 'version', label: 'Approved logo version' }, { key: 'approved', label: 'Approved (true/false)' }],
  };
  return <div className="modal-backdrop" role="presentation" onMouseDown={(event) => { if (event.target === event.currentTarget) setEditor(null); }}><section className="modal" role="dialog" aria-modal="true" aria-labelledby="editor-title"><div className="modal-header"><h2 id="editor-title">{editor.title}</h2><button className="icon-button" onClick={() => setEditor(null)} aria-label="Close"><X size={18} /></button></div><div className="form-grid">{fieldConfig[editor.kind].map((field) => <div className="field" key={field.key}><label htmlFor={`edit-${field.key}`}>{field.label}</label><input id={`edit-${field.key}`} type={field.type || 'text'} step={field.type === 'number' ? '0.01' : undefined} value={String(editor.values[field.key] ?? '')} onChange={(event) => setEditor({ ...editor, values: { ...editor.values, [field.key]: field.type === 'number' ? event.target.value : event.target.value } })} /></div>)}</div><div className="form-actions"><LoadingButton className="button-primary" onClick={onSave} busy={busy}>Save guideline</LoadingButton><button className="button button-secondary" onClick={() => setEditor(null)}>Cancel</button></div></section></div>;
}

function App() {
  const [view, setView] = useState<View>(() => viewFromPath(window.location.pathname));
  const [role, setRole] = useState<Role>(() => (localStorage.getItem('inkloom-role') as Role) || 'Creator');
  const [guidelines, setGuidelines] = useState<Guidelines | null>(null);
  const [evidenceTitle, setEvidenceTitle] = useState('');
  const [evidenceFile, setEvidenceFile] = useState<File | null>(null);
  const [creativeFile, setCreativeFile] = useState<File | null>(null);
  const [logoImageFile, setLogoImageFile] = useState<File | null>(null);
  const checkInFlight = useRef(false);
  const evaluationInFlight = useRef(false);
  const evidenceUploadInFlight = useRef(false);
  const logoUploadInFlight = useRef(false);
  const [samples, setSamples] = useState<SampleDraft[]>([]);
  const [drafts, setDrafts] = useState<Draft[]>([]);
  const [dashboard, setDashboard] = useState<DashboardData | null>(null);
  const [evaluationInfo, setEvaluationInfo] = useState<EvaluationInfo | null>(null);
  const [evaluationRun, setEvaluationRun] = useState<EvaluationRun | null>(null);
  const [evaluationInfoLoading, setEvaluationInfoLoading] = useState(false);
  const [auditEntries, setAuditEntries] = useState<AuditEntry[]>([]);
  const [auditTotal, setAuditTotal] = useState(0);
  const [auditLoading, setAuditLoading] = useState(false);
  const [serviceStatus, setServiceStatus] = useState<ServiceStatus | null>(null);
  const [serviceStatusLoading, setServiceStatusLoading] = useState(false);
  const [health, setHealth] = useState<{ ai_configured?: boolean; ai_notice?: string | null } | null>(null);
  const [currentDraft, setCurrentDraft] = useState<Draft | null>(null);
  const [busy, setBusy] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [toast, setToast] = useState<{ message: string; error?: boolean } | null>(null);
  const [text, setText] = useState('');
  const [channel, setChannel] = useState<Channel>('Instagram');
  const [productId, setProductId] = useState<number>(0);
  const [selectedSample, setSelectedSample] = useState<number | null>(null);
  const [pdfFile, setPdfFile] = useState<File | null>(null);
  const [reviewDraft, setReviewDraft] = useState<Draft | null>(null);
  const [reviewComment, setReviewComment] = useState('');
  const [historyDraft, setHistoryDraft] = useState<Draft | null>(null);
  const [history, setHistory] = useState<DraftHistory | null>(null);
  const [batchText, setBatchText] = useState('');
  const [batchCsv, setBatchCsv] = useState<File | null>(null);
  const [batchItems, setBatchItems] = useState<BatchCheckItem[]>([]);
  const [compareLeft, setCompareLeft] = useState<number | null>(null);
  const [compareRight, setCompareRight] = useState<number | null>(null);
  const [revisionComparison, setRevisionComparison] = useState<RevisionComparison | null>(null);
  const [editor, setEditor] = useState<Editor | null>(null);
  const [highlightedGuideline, setHighlightedGuideline] = useState<string | null>(null);
  const notify = useCallback((message: string, error = false) => setToast({ message, error }), []);
  const refreshData = useCallback(async () => {
    const results = await Promise.allSettled([api.guidelines(), api.samples(), api.drafts(), api.dashboard(), api.health()]);
    if (results[0].status === 'fulfilled') {
      setGuidelines(results[0].value);
      if (!productId && results[0].value.products[0]) setProductId(results[0].value.products[0].id);
    }
    if (results[1].status === 'fulfilled') setSamples(results[1].value);
    if (results[2].status === 'fulfilled') setDrafts(results[2].value);
    if (results[3].status === 'fulfilled') setDashboard(results[3].value);
    if (results[4].status === 'fulfilled') setHealth(results[4].value);
    const failed = results.find((result) => result.status === 'rejected');
    if (failed?.status === 'rejected') notify(messageFrom(failed.reason), true);
    setLoading(false);
  }, [notify, productId]);

  const loadAuditLog = useCallback(async () => {
    setAuditLoading(true);
    try {
      const result = await api.auditLog('Admin');
      setAuditEntries(result.items);
      setAuditTotal(result.total);
    } catch (error) { notify(messageFrom(error), true); }
    finally { setAuditLoading(false); }
  }, [notify]);
  const loadServiceStatus = useCallback(async () => {
    setServiceStatusLoading(true);
    try { setServiceStatus(await api.status()); }
    catch (error) { notify(messageFrom(error), true); }
    finally { setServiceStatusLoading(false); }
  }, [notify]);

  useEffect(() => { void refreshData(); }, [refreshData]);
  useEffect(() => {
    const targetPath = ROUTE_PATHS[view];
    if (window.location.pathname !== targetPath) window.history.pushState({ inkloom: true }, '', targetPath);
  }, [view]);
  useEffect(() => {
    const syncViewFromLocation = () => {
      const nextView = viewFromPath(window.location.pathname);
      const navItem = NAV_ITEMS.find((item) => item.id === nextView);
      setView(navItem?.roles && !navItem.roles.includes(role) ? 'home' : nextView);
    };
    window.addEventListener('popstate', syncViewFromLocation);
    return () => window.removeEventListener('popstate', syncViewFromLocation);
  }, [role]);
  useEffect(() => {
    const navItem = NAV_ITEMS.find((item) => item.id === view);
    if (navItem?.roles && !navItem.roles.includes(role)) setView('home');
  }, [role, view]);
  useEffect(() => { localStorage.setItem('inkloom-role', role); }, [role]);
  useEffect(() => {
    if (view !== 'evaluation' || evaluationInfo) return undefined;
    let current = true;
    setEvaluationInfoLoading(true);
    api.evaluationInfo().then((info) => { if (current) setEvaluationInfo(info); })
      .catch((error) => { if (current) notify(messageFrom(error), true); })
      .finally(() => { if (current) setEvaluationInfoLoading(false); });
    return () => { current = false; };
  }, [evaluationInfo, notify, view]);
  useEffect(() => { if (view === 'audit-log' && role === 'Admin') void loadAuditLog(); }, [loadAuditLog, role, view]);
  useEffect(() => { if (view === 'status') void loadServiceStatus(); }, [loadServiceStatus, view]);
  useEffect(() => { if (toast) { const timeout = window.setTimeout(() => setToast(null), 3800); return () => window.clearTimeout(timeout); } return undefined; }, [toast]);
  useEffect(() => { if (view === 'guidelines' && highlightedGuideline) { const timeout = window.setTimeout(() => document.querySelector(`[data-guideline-ref="${highlightedGuideline}"]`)?.scrollIntoView({ behavior: 'smooth', block: 'center' }), 180); return () => window.clearTimeout(timeout); } return undefined; }, [view, highlightedGuideline, guidelines]);

  const changeRole = (value: string) => {
    setRole(value as Role);
    if (value === 'Reviewer' && view === 'new') setView('review');
    else if (value === 'Admin' && view === 'new') setView('guidelines');
    else if (value !== 'Creator' && view === 'batch') setView('home');
    else if (value !== 'Admin' && view === 'evidence') setView('home');
    else if (value === 'Creator' && view === 'review') setView('home');
  };
  const beginSample = (sample?: SampleDraft) => {
    setPdfFile(null);
    setCreativeFile(null);
    const pdfInput = document.getElementById('pdf-file') as HTMLInputElement | null;
    const creativeInput = document.getElementById('creative-file') as HTMLInputElement | null;
    if (pdfInput) pdfInput.value = '';
    if (creativeInput) creativeInput.value = '';
    setView('new');
    setRole('Creator');
    if (sample) {
      setText(sample.text);
      setChannel(sample.channel);
      setSelectedSample(sample.id);
    } else {
      setText('');
      setChannel('Instagram');
      setSelectedSample(null);
    }
  };
  const chooseCreativeFile = (event: React.ChangeEvent<HTMLInputElement>) => {
    const selected = event.target.files?.[0] ?? null;
    if (!selected) { setCreativeFile(null); return; }
    if (selected.size > 5 * 1024 * 1024) { notify('Image is too large. Maximum upload size is 5 MB.', true); event.target.value = ''; setCreativeFile(null); return; }
    if (!/\.(png|jpe?g)$/i.test(selected.name)) { notify('Choose a PNG or JPG/JPEG ad creative.', true); event.target.value = ''; setCreativeFile(null); return; }
    setCreativeFile(selected);
    setPdfFile(null);
    setText('');
    setChannel('Ad');
    setSelectedSample(null);
    const pdfInput = document.getElementById('pdf-file') as HTMLInputElement | null;
    if (pdfInput) pdfInput.value = '';
  };
  const runCheck = async () => {
    if (checkInFlight.current) return;
    if (role !== 'Creator') { notify('Switch to Creator to check a draft.', true); return; }
    if (!pdfFile && !creativeFile && !text.trim()) { notify('Paste draft text or choose a text-based PDF or ad creative image first.', true); return; }
    if (pdfFile && pdfFile.size > 2 * 1024 * 1024) { notify('PDF is too large. Maximum upload size is 2 MB.', true); return; }
    if (creativeFile && creativeFile.size > 5 * 1024 * 1024) { notify('Image is too large. Maximum upload size is 5 MB.', true); return; }
    checkInFlight.current = true;
    setBusy('check');
    try {
      const result = creativeFile
        ? await api.checkCreative(creativeFile, productId, role)
        : pdfFile ? await api.checkPdf(pdfFile, channel, productId, role) : await api.createAndCheck({ text, channel, product_id: productId, role });
      const draft = result.draft;
      setCurrentDraft(draft);
      setText(draft.text);
      setCreativeFile(null);
      setPdfFile(null);
      const creativeInput = document.getElementById('creative-file') as HTMLInputElement | null;
      const pdfInput = document.getElementById('pdf-file') as HTMLInputElement | null;
      if (creativeInput) creativeInput.value = '';
      if (pdfInput) pdfInput.value = '';
      setView('report');
      await refreshData();
      notify(`Brand check complete · ${draft.latest_revision?.findings.length ?? result.revision?.findings.length ?? 0} finding(s)`);
    } catch (error) { notify(messageFrom(error), true); }
    finally { checkInFlight.current = false; setBusy(null); }
  };
  const runEvaluation = async () => {
    if (role !== 'Admin') { notify('Switch to Admin to run the evaluation.', true); return; }
    if (evaluationInFlight.current) return;
    evaluationInFlight.current = true;
    setBusy('evaluation');
    try {
      const result = await api.runEvaluation(role);
      setEvaluationRun(result);
      notify(result.ai_available ? 'Evaluation complete. Metrics are measured on the labeled synthetic set.' : 'Rules-only evaluation complete. AI metrics were not available.');
    } catch (error) { notify(messageFrom(error), true); }
    finally { evaluationInFlight.current = false; setBusy(null); }
  };
  const runBatch = async () => {
    if (role !== 'Creator') { notify('Switch to Creator to run a batch check.', true); return; }
    const texts = batchText.split(/^[\t ]*---+[\t ]*$/m).map((item) => item.trim()).filter(Boolean);
    if (!batchCsv && !texts.length) { notify('Paste drafts separated by a line containing --- or choose a CSV file.', true); return; }
    if (!batchCsv && texts.length > 12) { notify('A batch can contain at most 12 drafts.', true); return; }
    if (!batchCsv && texts.some((item) => item.length > 25000)) { notify('Each draft must be 25,000 characters or fewer.', true); return; }
    if (batchCsv && batchCsv.size > 2 * 1024 * 1024) { notify('CSV is too large. Maximum upload size is 2 MB.', true); return; }
    setBatchItems([]);
    setBusy('batch');
    try {
      const result = batchCsv
        ? await api.batchCheckCsv(batchCsv, channel, productId, role)
        : await api.batchCheck(texts, channel, productId, role);
      setBatchItems(result.items);
      await refreshData();
      notify(`${result.count} draft(s) checked. Open any row for its full review report.`);
    } catch (error) { notify(messageFrom(error), true); }
    finally { setBusy(null); }
  };
  const openBatchResult = (item: BatchCheckItem) => {
    setCurrentDraft(item.draft);
    setText(item.draft.text);
    setView('report');
  };

  const applyFix = async (finding: Finding) => {
    if (!currentDraft || role !== 'Creator') return;
    let next = currentDraft.text;
    if (finding.start >= 0 && finding.end > finding.start && finding.end <= next.length) {
      next = next.slice(0, finding.start) + (finding.replacement ?? '') + next.slice(finding.end);
    } else if (finding.type === 'missing_disclaimer') {
      next = `${next.trim()}${next.trim() ? ' ' : ''}${finding.replacement || 'T&C apply'}`;
    } else if (finding.replacement) {
      next = `${next.trim()} ${finding.replacement}`.trim();
    }
    setBusy(`fix-${finding.type}`);
    try {
      const updated = await api.updateDraft(currentDraft.id, next, role);
      setCurrentDraft(updated);
      setText(updated.text);
      notify('Suggestion applied. Re-run the check to create a new revision.');
    } catch (error) { notify(messageFrom(error), true); }
    finally { setBusy(null); }
  };
  const rerun = async () => {
    if (!currentDraft) return;
    setBusy('rerun');
    try {
      const result = await api.rerunCheck(currentDraft.id, currentDraft.text, role);
      setCurrentDraft(result.draft);
      await refreshData();
      notify(`Revision ${result.revision?.number ?? ''} saved.`);
    } catch (error) { notify(messageFrom(error), true); }
    finally { setBusy(null); }
  };
  const submitDraft = async () => {
    if (!currentDraft) return;
    setBusy('submit');
    try {
      const updated = await api.submit(currentDraft.id, role);
      setCurrentDraft(updated);
      await refreshData();
      notify('Draft sent to the reviewer. Nothing is auto-published.');
    } catch (error) { notify(messageFrom(error), true); }
    finally { setBusy(null); }
  };
  const openEvidence = (evidence: Evidence) => {
    if (evidence.guideline_ref.startsWith('evidence_document:')) { setView('evidence'); return; }
    if (evidence.guideline_ref === 'claim:evidence_missing') {
      setHighlightedGuideline(null);
      setView('guidelines');
      notify('No approved claim supports this wording yet. Add a supported statement and its evidence under Approved claims.');
      return;
    }
    setHighlightedGuideline(evidence.guideline_ref);
    setView('guidelines');
  };
  const exportReport = async () => {
    if (!currentDraft) return;
    setBusy('export');
    try {
      const blob = await api.report(currentDraft.id);
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `inkloom-review-${currentDraft.id}.pdf`;
      link.click();
      URL.revokeObjectURL(url);
    } catch (error) { notify(messageFrom(error), true); }
    finally { setBusy(null); }
  };
  const downloadAuditCsv = async () => {
    if (role !== 'Admin') { notify('Switch to Admin to export the audit log.', true); return; }
    setBusy('audit-export');
    try {
      const blob = await api.auditCsv(role);
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = 'inkloom-audit-log.csv';
      link.click();
      URL.revokeObjectURL(url);
    } catch (error) { notify(messageFrom(error), true); }
    finally { setBusy(null); }
  };
  const resetDemo = async () => {
    if (!window.confirm('Reset demo data? This removes saved drafts, revisions, decisions, and edited guidelines.')) return;
    setBusy('reset');
    try {
      await api.reset();
      setCurrentDraft(null); setReviewDraft(null); setHistoryDraft(null); setHistory(null); setRevisionComparison(null);
      await refreshData();
      notify('DemoWear demo data reset. Ready for a fresh review.');
    } catch (error) { notify(messageFrom(error), true); }
    finally { setBusy(null); }
  };
  const loadDemo = async () => {
    setBusy('load-demo');
    try {
      await api.loadDemo(role);
      await refreshData();
      notify('Demo data is ready. Existing drafts were kept.');
    } catch (error) { notify(messageFrom(error), true); }
    finally { setBusy(null); }
  };
  const uploadEvidence = async (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (role !== 'Admin') { notify('Switch to Admin to manage evidence documents.', true); return; }
    if (!evidenceTitle.trim() || !evidenceFile) { notify('Enter a document title and choose a .txt, .md, or text-based PDF file.', true); return; }
    if (evidenceFile.size > 2 * 1024 * 1024) { notify('Evidence upload is too large. Maximum size is 2 MB.', true); return; }
    if (!/\.(txt|md|pdf)$/i.test(evidenceFile.name)) { notify('Choose a .txt, .md, or text-based PDF file.', true); return; }
    if (evidenceUploadInFlight.current) return;
    evidenceUploadInFlight.current = true;
    setBusy('evidence-upload');
    try {
      await api.uploadEvidenceDocument(evidenceTitle.trim(), evidenceFile);
      setEvidenceTitle(''); setEvidenceFile(null);
      const input = document.getElementById('evidence-file') as HTMLInputElement | null;
      if (input) input.value = '';
      await refreshData();
      notify('Evidence document extracted and saved. Future checks will search its text.');
    } catch (error) { notify(messageFrom(error), true); }
    finally { evidenceUploadInFlight.current = false; setBusy(null); }
  };
  const uploadApprovedLogo = async (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (role !== 'Admin') { notify('Switch to Admin to manage the approved logo image.', true); return; }
    if (!logoImageFile) { notify('Choose a PNG or JPG/JPEG approved logo image.', true); return; }
    if (logoImageFile.size > 5 * 1024 * 1024) { notify('Logo image is too large. Maximum upload size is 5 MB.', true); return; }
    if (!/\.(png|jpe?g)$/i.test(logoImageFile.name)) { notify('Choose a PNG or JPG/JPEG approved logo image.', true); return; }
    if (logoUploadInFlight.current) return;
    logoUploadInFlight.current = true;
    setBusy('logo-image');
    try {
      await api.uploadApprovedLogo(logoImageFile);
      setLogoImageFile(null);
      const input = document.getElementById('approved-logo-image-file') as HTMLInputElement | null;
      if (input) input.value = '';
      await refreshData();
      notify('Approved logo image saved. Future ad creatives will use this image for matching.');
    } catch (error) { notify(messageFrom(error), true); }
    finally { logoUploadInFlight.current = false; setBusy(null); }
  };
  const deleteEvidence = async (document: EvidenceDocument) => {
    if (!window.confirm(`Remove “${document.title}”? Documents referenced by a saved check cannot be removed.`)) return;
    setBusy(`evidence-delete-${document.id}`);
    try { await api.deleteEvidenceDocument(document.id); await refreshData(); notify('Evidence document removed.'); }
    catch (error) { notify(messageFrom(error), true); }
    finally { setBusy(null); }
  };

  const loadReviewDraft = async (draft: Draft) => {
    setReviewDraft(draft);
    setReviewComment('');
    try { setReviewDraft(await fetchDraft(draft.id)); } catch (error) { notify(messageFrom(error), true); }
  };
  const fetchDraft = async (id: number) => {
    const response = await fetch(`/api/drafts/${id}`);
    if (!response.ok) throw new Error('Could not load this draft.');
    return response.json() as Promise<Draft>;
  };
  const decide = async (action: 'approve' | 'request_changes') => {
    if (!reviewDraft) return;
    if (action === 'request_changes' && !reviewComment.trim()) { notify('Add a short comment when requesting changes.', true); return; }
    setBusy(action);
    try {
      const updated = await api.decide(reviewDraft.id, action, reviewComment);
      setReviewDraft(updated);
      await refreshData();
      notify(action === 'approve' ? 'Draft approved. Nothing was published.' : 'Changes requested and comment saved.');
      setReviewComment('');
    } catch (error) { notify(messageFrom(error), true); }
    finally { setBusy(null); }
  };
  const openHistory = async (draft: Draft) => {
    setHistoryDraft(draft);
    setHistory(null);
    setRevisionComparison(null);
    try {
      const loaded = await api.history(draft.id);
      setHistory(loaded);
      setCompareLeft(loaded.revisions.length > 1 ? loaded.revisions[0].number : null);
      setCompareRight(loaded.revisions.length > 1 ? loaded.revisions[loaded.revisions.length - 1].number : null);
    } catch (error) { notify(messageFrom(error), true); }
  };
  const compareSelectedRevisions = async () => {
    if (!historyDraft || compareLeft === null || compareRight === null) return;
    if (compareLeft === compareRight) { notify('Choose two different revisions to compare.', true); return; }
    setBusy('compare');
    try { setRevisionComparison(await api.compareRevisions(historyDraft.id, compareLeft, compareRight)); }
    catch (error) { notify(messageFrom(error), true); }
    finally { setBusy(null); }
  };
  const openEditor = (kind: EditorKind, row?: Product | BannedTerm | PreferredTerm | ApprovedClaim | ToneRule | Disclaimer) => {
    if (kind === 'logo') {
      setEditor({ kind, id: guidelines?.logo?.id ?? null, title: 'Edit approved logo version', values: { version: guidelines?.logo?.version ?? 'v3', approved: guidelines?.logo?.approved ?? true } }); return;
    }
    if (!row) return;
    let values: Editor['values'] = {};
    if (kind === 'product') { const item = row as Product; values = { name: item.name, approved_price: item.approved_price, material: item.material }; }
    if (kind === 'term') values = { term: (row as BannedTerm).term };
    if (kind === 'preferred') { const item = row as PreferredTerm; values = { term: item.term, preferred: item.preferred }; }
    if (kind === 'claim') { const item = row as ApprovedClaim; values = { claim: item.claim, evidence: item.evidence }; }
    if (kind === 'tone') { const item = row as ToneRule; values = { name: item.name, description: item.description, threshold: item.threshold, enabled: item.enabled }; }
    if (kind === 'disclaimer') { const item = row as Disclaimer; values = { phrase: item.phrase, applies_to: item.applies_to }; }
    setEditor({ kind, id: row.id, title: `Edit ${kind === 'term' ? 'banned term' : kind === 'preferred' ? 'preferred wording' : kind === 'claim' ? 'approved claim' : kind === 'tone' ? 'tone rule' : kind}`, values });
  };
  const saveEditor = async () => {
    if (!editor) return;
    setBusy('guideline-save');
    const value = editor.values;
    try {
      if (editor.kind === 'product') {
        const data = { name: String(value.name || ''), approved_price: Number(value.approved_price), material: String(value.material || '') };
        if (editor.id) await api.updateProduct(editor.id, data); else await api.createProduct(data);
      } else if (editor.kind === 'term') {
        if (editor.id) await api.updateTerm(editor.id, String(value.term || '')); else await api.createTerm(String(value.term || ''));
      } else if (editor.kind === 'preferred') {
        if (editor.id) await api.updatePreferredTerm(editor.id, String(value.term || ''), String(value.preferred || '')); else await api.createPreferredTerm(String(value.term || ''), String(value.preferred || ''));
      } else if (editor.kind === 'claim') {
        if (editor.id) await api.updateClaim(editor.id, String(value.claim || ''), String(value.evidence || '')); else await api.createClaim(String(value.claim || ''), String(value.evidence || ''));
      } else if (editor.kind === 'tone') {
        const threshold = value.threshold === '' || value.threshold === null ? null : Number(value.threshold);
        if (editor.id) await api.updateTone(editor.id, String(value.name || ''), String(value.description || ''), threshold, String(value.enabled).toLowerCase() !== 'false');
        else await api.createTone(String(value.name || ''), String(value.description || ''), threshold, String(value.enabled).toLowerCase() !== 'false');
      } else if (editor.kind === 'disclaimer') {
        if (editor.id) await api.updateDisclaimer(editor.id, String(value.phrase || ''), String(value.applies_to || '')); else await api.createDisclaimer(String(value.phrase || ''), String(value.applies_to || ''));
      } else {
        await api.updateLogo(String(value.version || ''), String(value.approved).toLowerCase() !== 'false');
      }
      setEditor(null); setHighlightedGuideline(null); await refreshData(); notify('Guideline saved.');
    } catch (error) { notify(messageFrom(error), true); }
    finally { setBusy(null); }
  };
  const deleteGuideline = async (kind: EditorKind, id: number) => {
    if (!window.confirm('Remove this guideline record? Existing revision evidence remains saved.')) return;
    setBusy('guideline-delete');
    try {
      if (kind === 'product') await api.deleteProduct(id);
      if (kind === 'term') await api.deleteTerm(id);
      if (kind === 'preferred') await api.deletePreferredTerm(id);
      if (kind === 'claim') await api.deleteClaim(id);
      if (kind === 'tone') await api.deleteTone(id);
      if (kind === 'disclaimer') await api.deleteDisclaimer(id);
      await refreshData(); notify('Guideline removed.');
    } catch (error) { notify(messageFrom(error), true); }
    finally { setBusy(null); }
  };
  const updateFindingLabel = async (findingIndex: number, reviewerLabel: 'valid' | 'false_positive' | null) => {
    if (!currentDraft || !currentRevision || role !== 'Reviewer') return;
    const draftId = currentDraft.id;
    setBusy('finding-review');
    try {
      const updatedRevision = await api.setFindingLabel(draftId, currentRevision.number, findingIndex, reviewerLabel);
      setCurrentDraft((draft) => draft?.id === draftId ? { ...draft, latest_revision: updatedRevision } : draft);
      setReviewDraft((draft) => draft?.id === draftId ? { ...draft, latest_revision: updatedRevision } : draft);
      await refreshData();
      notify(reviewerLabel ? `Finding labeled ${reviewerLabel.replaceAll('_', ' ')}.` : 'Reviewer label cleared.');
    } catch (error) { notify(messageFrom(error), true); }
    finally { setBusy(null); }
  };
  const dismissFinding = async (findingIndex: number, reason: string) => {
    if (!currentDraft || !currentRevision || role !== 'Reviewer') return;
    const draftId = currentDraft.id;
    setBusy('finding-review');
    try {
      const updatedRevision = await api.dismissFinding(draftId, currentRevision.number, findingIndex, reason);
      setCurrentDraft((draft) => draft?.id === draftId ? { ...draft, latest_revision: updatedRevision } : draft);
      setReviewDraft((draft) => draft?.id === draftId ? { ...draft, latest_revision: updatedRevision } : draft);
      await refreshData();
      notify('Finding dismissed with reason. The check result remains unchanged.');
    } catch (error) { notify(messageFrom(error), true); }
    finally { setBusy(null); }
  };
  const currentRevision = currentDraft?.latest_revision;
  const findingCount = drafts.reduce((sum, draft) => sum + (draft.latest_revision?.findings.length ?? 0), 0);
  const navItems = NAV_ITEMS.filter((item) => !item.roles || item.roles.includes(role));
  const setRoleFromSelect = (event: React.ChangeEvent<HTMLSelectElement>) => changeRole(event.target.value);

  const renderEvaluation = () => {
    const metricPanel = (title: string, metric: EvaluationRun['metrics']['rules_only'] | null, note: string) => <section className="card panel evaluation-metric" key={title} aria-label={`${title} evaluation metrics`}>
      <div className="card-heading"><h2>{title}</h2>{metric && <span className="sample-tag">n = {metric.cases}</span>}</div>
      {metric ? <><div className="evaluation-score-row"><div><small>Precision</small><strong>{metric.precision === null ? '—' : `${(metric.precision * 100).toFixed(1)}%`}</strong></div><div><small>Recall</small><strong>{metric.recall === null ? '—' : `${(metric.recall * 100).toFixed(1)}%`}</strong></div></div><div className="evaluation-counts"><span>False positives <b>{metric.false_positive_count}</b></span><span>True positives <b>{metric.true_positives}</b></span><span>False negatives <b>{metric.false_negatives}</b></span></div></> : <div className="empty-state"><strong>Not measured</strong><p>{note}</p></div>}
    </section>;
    return <>
      <PageHeading eyebrow="Quality & reliability" title="Measure the check engine." subtitle="A versioned, labeled synthetic set reports observed finding-type precision, recall, and errors—not a promise of real-world accuracy." action={<LoadingButton className="button-primary" onClick={runEvaluation} busy={busy === 'evaluation'} disabled={role !== 'Admin'}><RefreshCw size={13} />Run Evaluation</LoadingButton>} />
      <div className="rule-banner" role="note"><Info size={15} />AI evaluation only runs when you click. If configured, the run can use up to 30 provider calls (cache and daily cap apply); no background probe is sent.</div>
      {evaluationInfoLoading ? <div className="card empty-state" role="status" aria-live="polite"><LoaderCircle className="spin" size={18} /> Loading labeled cases…</div> : evaluationInfo ? <>
        <section className="card panel evaluation-summary"><div><div className="eyebrow">{evaluationInfo.dataset_id} · version {evaluationInfo.dataset_version}</div><strong>{evaluationInfo.case_count} labeled cases</strong><p className="small-copy">Each case is synthetic and includes expected finding types. The results are a regression signal for this set only.</p></div><details className="evaluation-cases"><summary>Inspect cases and labels</summary><div className="evaluation-case-list">{evaluationInfo.cases.map((item) => <article className="evaluation-case" key={item.id}><div><strong>{item.id} · {item.title}</strong><span>{item.text}</span><small>Expected: {item.expected_types.length ? item.expected_types.map(humanize).join(', ') : 'No findings'}</small></div></article>)}</div></details></section>
        {evaluationRun && <>
          {evaluationRun.ai_notice && <div className="notice-banner" role="status"><Info size={15} />{evaluationRun.ai_notice}</div>}
          {evaluationRun.combined_uses_rules_only_fallback && <div className="rule-banner"><Info size={15} /><strong>Combined result is rules-only fallback.</strong> AI-only metrics are not reported as zero; they were not measured.</div>}
          <div className="chart-grid evaluation-results">{metricPanel('Rules only', evaluationRun.metrics.rules_only, 'Rules were not measured.')}{metricPanel('AI only', evaluationRun.metrics.ai_only, 'AI was unavailable or the AI evaluation was incomplete; no score is fabricated.')}{metricPanel('Combined', evaluationRun.metrics.combined, evaluationRun.combined_uses_rules_only_fallback ? 'This is the rules-only fallback, not an AI result.' : 'Merged rule and AI predictions.')}</div>
        </>}
      </> : <div className="card empty-state"><strong>Evaluation set unavailable.</strong><p>Try again after the server is ready.</p></div>}
    </>;
  };

  const renderAuditLog = () => <>
    <PageHeading eyebrow="Governance trail" title="Audit Log" subtitle="A metadata-only record of checks, review actions, guideline updates, and demo operations." action={<div className="form-actions"><LoadingButton className="button-secondary" onClick={loadAuditLog} busy={auditLoading}><RefreshCw size={13} />Refresh</LoadingButton><button className="button button-secondary" onClick={downloadAuditCsv} disabled={!!busy || auditTotal === 0}><ArrowDownToLine size={13} />Export CSV</button></div>} />
    <div className="rule-banner"><Info size={15} />This view and CSV contain role, action, draft identifier/title, and time only. They omit comment bodies, evidence text, uploaded file bytes, and provider credentials.</div>
    {auditLoading && !auditEntries.length ? <div className="card empty-state" role="status" aria-live="polite"><LoaderCircle className="spin" size={18} /> Loading audit records…</div> : auditEntries.length ? <section className="card panel audit-panel"><div className="card-heading"><div><h2>Recent activity</h2><div className="small-copy" style={{ marginTop: 4 }}>Showing {auditEntries.length} of {auditTotal} record(s)</div></div></div><div className="audit-list" role="list">{auditEntries.map((entry) => <article className="audit-row" role="listitem" key={entry.id}><div><span className="role-pill">{entry.actor_role}</span><strong>{humanize(entry.action)}</strong><span className="audit-draft">{entry.draft_id ? `${entry.draft_title || 'Draft'} · #${entry.draft_id}` : 'Workspace action'}</span></div><time dateTime={entry.created_at}>{dateLabel(entry.created_at)}</time></article>)}</div></section> : <div className="card empty-state"><ClipboardCheck size={24} color="#72917e" /><strong>No audit actions yet.</strong><p>Checks and review decisions will appear here. No comment text is exported.</p></div>}
  </>;

  const renderStatus = () => {
    const status = serviceStatus;
    const usageMax = Math.max(status?.ai_daily_cap ?? 0, 1);
    const usageValue = Math.min(status?.ai_calls_used_today ?? 0, usageMax);
    return <>
      <PageHeading eyebrow="Operations" title="Service Status" subtitle="A read-only snapshot of local readiness and configured limits." action={<LoadingButton className="button-secondary" onClick={loadServiceStatus} busy={serviceStatusLoading}><RefreshCw size={13} />Refresh status</LoadingButton>} />
      <div className="rule-banner"><Info size={15} />AI provider reachability is deliberately not probed here. A configured key does not guarantee the provider is currently reachable, and this page never makes a paid request.</div>
      {serviceStatusLoading && !status ? <div className="card empty-state" role="status" aria-live="polite"><LoaderCircle className="spin" size={18} /> Loading service status…</div> : status ? <div className="chart-grid status-grid">
        <section className="card panel"><div className="eyebrow">Storage</div><h2>Database</h2><strong className={`status-value ${status.database_health}`}>{status.database_health === 'ok' ? 'Healthy' : 'Unavailable'}</strong><p className="small-copy">A lightweight connectivity query was used. No records were changed.</p></section>
        <section className="card panel"><div className="eyebrow">Optional integration</div><h2>AI provider</h2><strong className="status-value">{status.ai_configured ? 'Key configured' : 'Not configured'}</strong><p className="small-copy">Reachability: {status.ai_reachability === 'not_configured' ? 'not configured' : 'unknown · not probed'}.</p><div className="usage-row"><label htmlFor="ai-usage">Daily calls used / cap</label><span>{status.ai_calls_used_today} / {status.ai_daily_cap}</span></div><progress id="ai-usage" max={usageMax} value={usageValue} aria-label={`AI calls used today: ${status.ai_calls_used_today} of ${status.ai_daily_cap}`} /></section>
        <section className="card panel"><div className="eyebrow">Active policy</div><h2>Guidelines</h2><strong className="status-value">{status.guideline_version === null ? 'Unavailable' : `Version ${status.guideline_version}`}</strong><p className="small-copy">Each saved check captures the guideline version it used.</p></section>
        <section className="card panel"><div className="eyebrow">Build</div><h2>Application</h2><strong className="status-value">{status.app_version}</strong><p className="small-copy">App version exposed by the running FastAPI service.</p></section>
      </div> : <div className="card empty-state"><strong>Status unavailable.</strong><p>Refresh after the server responds.</p></div>}
    </>;
  };

  const renderHome = () => <>
    <PageHeading eyebrow="Brand governance · DemoWear" title="Make every claim earn its place." subtitle="Check campaign copy against approved facts, understand the evidence, and route the draft to a human before it goes live." />
    {!health?.ai_configured && <div className="notice-banner"><Info size={15} />{health?.ai_notice || 'AI analysis unavailable. Showing rule-based checks only.'} <span style={{ color: '#887342' }}>· The demo works without a key.</span></div>}
    <section className="home-hero"><div className="hero-copy"><div className="eyebrow">The brand review desk</div><h2 className="hero-title">From first draft to confident sign-off.</h2><p>Evidence-backed checks for price, claims, and tone. A person makes the final call. Nothing publishes itself.</p><div className="hero-actions"><button className="button button-primary" onClick={loadDemo} disabled={!!busy}><RotateCcw size={14} />Load demo data</button><button className="button button-secondary" onClick={() => beginSample(samples[0])}><ScanText size={14} />Try a sample draft <ArrowRight size={14} /></button></div></div><div className="hero-badge"><span>Active brand</span><strong>{guidelines?.brand.name || 'DemoWear'}</strong><span style={{ marginTop: 8 }}>Approved logo · {guidelines?.logo?.version || 'v3'}</span></div></section>
    <div className="steps-row">{[{ n: '01', title: 'Write or load a draft', detail: 'Paste copy or choose one of four samples.' }, { n: '02', title: 'Check against evidence', detail: 'Rules catch exact facts; AI is optional.' }, { n: '03', title: 'A person decides', detail: 'Review, request changes, or approve.' }].map((step) => <div className="card step-card" key={step.n}><div className="step-no">{step.n}</div><div><strong>{step.title}</strong><span>{step.detail}</span></div></div>)}</div>
    <div className="home-grid"><section className="card panel"><div className="card-heading"><div><h2>Sample drafts</h2><div className="small-copy" style={{ marginTop: 5 }}>Start with a realistic brand scenario.</div></div><button className="button button-quiet button-small" onClick={() => beginSample()}>Write from scratch</button></div><div className="sample-list">{samples.map((sample) => <div className="sample-card" key={sample.id}><div><strong>{sample.title}</strong><p>{sample.text}</p><span className="sample-tag" style={{ display: 'inline-block', marginTop: 8 }}>{sample.channel}</span></div><button className="button button-secondary button-small" onClick={() => beginSample(sample)}>Use draft</button></div>)}</div></section><div className="stats-rail"><div className="card stat-card"><div><small>Drafts checked</small><strong>{dashboard?.drafts_total ?? 0}</strong></div><div className="stat-icon"><ScanText size={17} /></div></div><div className="card stat-card"><div><small>Findings in latest checks</small><strong>{findingCount}</strong></div><div className="stat-icon"><AlertCircle size={17} /></div></div><div className="card stat-card"><div><small>Human decisions</small><strong>{dashboard?.decisions ?? 0}</strong></div><div className="stat-icon"><BadgeCheck size={17} /></div></div><div className="card panel"><div className="card-heading"><h2>Review promise</h2><ShieldCheck size={17} color="#47755d" /></div><p className="small-copy" style={{ margin: 0 }}>AI suggestions are advisory. The exact checks point to their source records. Every approval is human, and nothing is auto-published.</p></div></div></div>
  </>;

  const renderNew = () => <>
    <PageHeading eyebrow="Creator workspace" title="Start with the words." subtitle="Paste copy or extract text from a PDF, choose its channel and product, then check it against DemoWear’s approved guidance." />
    <div className="new-content-layout"><section className="card panel"><div className="card-heading"><div><h2>Draft details</h2><div className="small-copy" style={{ marginTop: 5 }}>A draft is stored when the check starts.</div></div><span className="role-pill">Creator</span></div>
      <div className="form-grid"><div className="field"><label htmlFor="channel">Channel</label><select id="channel" value={channel} onChange={(event) => setChannel(event.target.value as Channel)}><option>Instagram</option><option>LinkedIn</option><option>Ad</option><option>Website</option></select></div><div className="field"><label htmlFor="product">Product</label><select id="product" value={productId} onChange={(event) => setProductId(Number(event.target.value))}>{guidelines?.products.map((product) => <option key={product.id} value={product.id}>{product.name} · ₹{product.approved_price.toLocaleString('en-IN')}</option>)}</select></div><div className="field full"><label htmlFor="draft-text">Draft text</label><textarea id="draft-text" maxLength={25000} value={text} onChange={(event) => { setText(event.target.value); setPdfFile(null); setCreativeFile(null); setSelectedSample(null); }} onKeyDown={(event) => { if ((event.ctrlKey || event.metaKey) && event.key === 'Enter') { event.preventDefault(); void runCheck(); } }} placeholder="Paste your caption, ad copy, or website text here…" /><span className="field-hint">{text.length.toLocaleString()} / 25,000 characters · Ctrl/⌘+Enter to check</span></div><div className="field full"><label htmlFor="pdf-file">Or upload a text-based PDF</label><div className="file-drop"><Upload size={17} /><div className="small-copy">PDF text is extracted before the same brand check.</div><input id="pdf-file" type="file" accept="application/pdf,.pdf" onChange={(event) => { setPdfFile(event.target.files?.[0] || null); if (event.target.files?.[0]) { setCreativeFile(null); setText(''); setSelectedSample(null); const creativeInput = document.getElementById('creative-file') as HTMLInputElement | null; if (creativeInput) creativeInput.value = ''; } }} /><div className="field-hint">Max 2 MB · scanned PDFs / OCR not supported</div>{pdfFile && <div className="small-copy" style={{ marginTop: 8 }}>{pdfFile.name} · {(pdfFile.size / 1024).toFixed(0)} KB</div>}</div></div><div className="field full"><label htmlFor="creative-file">Or upload a PNG/JPG ad creative</label><div className="file-drop"><ScanText size={17} /><div className="small-copy">OCR text joins the existing rule/AI checks; logo matching is advisory.</div><input id="creative-file" type="file" accept="image/png,image/jpeg,.png,.jpg,.jpeg" onChange={chooseCreativeFile} /><div className="field-hint">Max 5 MB · channel switches to Ad · verified by image contents{creativeFile ? ` · ${creativeFile.name} · ${(creativeFile.size / 1024).toFixed(0)} KB` : ''}</div></div></div></div>
      <div className="form-actions"><LoadingButton className="button-primary" onClick={runCheck} busy={busy === 'check'}><ScanText size={14} />Run Brand Check</LoadingButton><button className="button button-secondary" onClick={() => { setText(''); setPdfFile(null); setCreativeFile(null); setSelectedSample(null); const pdfInput = document.getElementById('pdf-file') as HTMLInputElement | null; const creativeInput = document.getElementById('creative-file') as HTMLInputElement | null; if (pdfInput) pdfInput.value = ''; if (creativeInput) creativeInput.value = ''; }}>Clear draft</button></div>
    </section><aside className="card panel"><div className="card-heading"><div><h2>Load a sample</h2><div className="small-copy" style={{ marginTop: 5 }}>Choose a prepared scenario.</div></div></div><div className="sample-picker">{samples.map((sample) => <button className={`sample-choice ${selectedSample === sample.id ? 'selected' : ''}`} key={sample.id} onClick={() => beginSample(sample)}><strong>{sample.title}</strong><span>{sample.text}</span></button>)}</div><div className="divider" /><div className="small-copy"><strong>Checks included</strong><br />Approved price · banned terms · required disclaimer · tone guidance · optional unsupported-claim review.</div></aside></div>
  </>;

  const renderReport = () => {
    if (!currentDraft) return <><PageHeading title="Review report" subtitle="Run a brand check to see its evidence-backed findings." /><div className="card empty-state"><strong>No report selected yet</strong><p>Choose a sample or start a new content check.</p><button className="button button-primary" onClick={() => beginSample(samples[0])}>Start a brand check</button></div></>;
    const findings = currentRevision?.findings || [];
    const canEdit = role === 'Creator' && ['draft', 'changes_requested'].includes(currentDraft.status);
    const canReview = role === 'Reviewer';
    const checkIsCurrent = Boolean(currentRevision && currentRevision.text === currentDraft.text && (!guidelines || currentRevision.guideline_version === guidelines.version));
    return <><PageHeading eyebrow={`${currentDraft.channel} · ${currentDraft.product_name}`} title="Review the evidence." subtitle={`Draft #${currentDraft.id} · Revision ${currentRevision?.number ?? 0} · Guidelines v${currentRevision?.guideline_version ?? '—'} · Checked ${dateLabel(currentRevision?.created_at)}`} action={<div className="report-toolbar"><StatusBadge status={currentDraft.status} /><button className="button button-secondary button-small" onClick={exportReport} disabled={!!busy}><ArrowDownToLine size={13} />PDF report</button></div>} />
      {currentRevision?.ai_notice && <div className="notice-banner"><Info size={15} />{currentRevision.ai_notice}</div>}
      <CreativeAssetPanel draft={currentDraft} />
      {currentRevision && guidelines && currentRevision.guideline_version !== guidelines.version && <div className="notice-banner" role="status" aria-live="polite"><Info size={15} /><span>Guidelines changed since this check. Re-run?</span>{role === 'Creator' && ['draft', 'changes_requested'].includes(currentDraft.status) ? <button className="button button-secondary button-small" onClick={rerun} disabled={!!busy}><RefreshCw size={13} />Re-run check</button> : <span className="small-copy">Switch to Creator to re-run when this draft is editable.</span>}</div>}
      {currentRevision?.verified_claims?.map((claim) => <div className="verified-claim" key={claim.guideline_ref}><strong><CheckCircle2 size={13} style={{ verticalAlign: 'middle', marginRight: 6 }} />{claim.document_title ? `Supported by: ${claim.document_title}` : `Approved claim with evidence: “${claim.claim}”`}</strong><small>{claim.document_title ? `Matching excerpt: ${claim.evidence}` : <>{claim.evidence} · <button className="button-quiet" style={{ border: 0, padding: 0, background: 'transparent', fontSize: 10, color: '#386450', textDecoration: 'underline' }} onClick={() => openEvidence({ label: claim.claim, detail: claim.evidence, guideline_ref: claim.guideline_ref })}>View record</button></>}</small></div>)}
      <div className="rule-banner"><ShieldCheck size={15} /><strong>Nothing is auto-published.</strong> This report supports a human review; it never posts content.</div>
      {currentRevision?.health_score_breakdown && <HealthScorePanel breakdown={currentRevision.health_score_breakdown} />}
      <div className="report-layout"><section className="card report-card"><div className="card-heading"><div><h2>Draft text</h2><div className="small-copy" style={{ marginTop: 4 }}>Flagged passages are highlighted.</div></div></div><HighlightedDraft text={currentDraft.text} findings={findings} />{canEdit && (!currentRevision || currentRevision.text !== currentDraft.text) && <div className="notice-banner" style={{ marginTop: 12 }}><Info size={14} />This draft text has changed since its last check. Re-run the check before sending it for review.</div>}{canEdit && <div className="form-actions"><LoadingButton className="button-secondary" onClick={rerun} busy={busy === 'rerun'}><RefreshCw size={13} />Re-run check</LoadingButton><LoadingButton className="button-primary" onClick={submitDraft} busy={busy === 'submit'} disabled={!checkIsCurrent}><ClipboardCheck size={13} />Submit for review</LoadingButton></div>}{currentDraft.status === 'in_review' && <div className="small-copy" style={{ marginTop: 12 }}>This draft is with a reviewer. Switch to Reviewer to make a decision.</div>}{currentDraft.status === 'approved' && <div className="verified-claim" style={{ marginTop: 12 }}><strong><BadgeCheck size={13} style={{ verticalAlign: 'middle', marginRight: 5 }} />Human approved · no publishing action was taken.</strong></div>}</section>
      <aside className="card report-card"><div className="card-heading"><div><h2>Findings</h2><div className="small-copy" style={{ marginTop: 4 }}>{findings.length ? `${findings.length} item${findings.length === 1 ? '' : 's'} to review` : 'No rule or AI findings.'}</div></div><span className="role-pill">{findings.length ? `${findings.filter((f) => f.severity === 'High').length} high` : 'Clear'}</span></div>{findings.length ? <div className="finding-list">{findings.map((finding, index) => <FindingCard key={`${finding.type}-${finding.start}-${index}`} finding={finding} findingIndex={index} onApply={applyFix} onEvidence={openEvidence} onDismiss={dismissFinding} onLabel={updateFindingLabel} canEdit={canEdit && checkIsCurrent} canReview={canReview} busy={busy === `fix-${finding.type}`} reviewerBusy={busy === 'finding-review'} />)}</div> : <div className="empty-state"><CheckCircle2 size={24} color="#5b8967" /><strong>Nothing flagged by the active checks.</strong><p>Approved claims with supporting records are shown above. AI results are advisory when enabled.</p></div>}</aside></div><DraftComments draftId={currentDraft.id} role={role} />
    </>;
  };

  const renderReview = () => {
    const queue = drafts.filter((draft) => draft.status === 'in_review');
    return <><PageHeading eyebrow="Human decision" title="Review before it goes live." subtitle="Approve a draft or request changes with a comment. Nothing is ever auto-published." /><div className="rule-banner"><ShieldCheck size={15} /><strong>Nothing is auto-published.</strong> A decision is recorded for the draft only.</div><div className="review-layout"><section className="card panel"><div className="card-heading"><div><h2>Waiting for review</h2><div className="small-copy" style={{ marginTop: 4 }}>{queue.length} draft(s) in the queue</div></div><button className="icon-button" aria-label="Refresh queue" onClick={refreshData}><RefreshCw size={15} /></button></div>{queue.length ? <div className="review-list">{queue.map((draft) => <button key={draft.id} className={`review-row ${reviewDraft?.id === draft.id ? 'selected' : ''}`} onClick={() => loadReviewDraft(draft)}><div className="review-row-main"><strong>{draft.product_name} · {draft.channel}</strong><small>Draft #{draft.id} · {draft.latest_revision?.findings.length ?? 0} finding(s) · {dateLabel(draft.updated_at)}</small></div><StatusBadge status={draft.status} /></button>)}</div> : <div className="empty-state"><ClipboardCheck size={24} color="#72917e" /><strong>The queue is clear.</strong><p>Submit a checked draft as Creator to send it here.</p><button className="button button-secondary" onClick={() => beginSample(samples[0])}>Try a sample</button></div>}</section><section className="card panel">{reviewDraft ? <><div className="card-heading"><div><h2>Reviewer decision</h2><div className="small-copy" style={{ marginTop: 4 }}>Draft #{reviewDraft.id} · {reviewDraft.product_name}</div></div><StatusBadge status={reviewDraft.status} /></div><div className="draft-paper" style={{ minHeight: 95, maxHeight: 190, overflow: 'auto' }}>{reviewDraft.text}</div><CreativeAssetPanel draft={reviewDraft} /><div className="small-copy" style={{ marginTop: 10 }}>Latest check: {reviewDraft.latest_revision?.findings.length ?? 0} finding(s) · <button className="button-quiet" style={{ background: 'none', border: 0, padding: 0, textDecoration: 'underline' }} onClick={() => { setCurrentDraft(reviewDraft); setView('report'); }}>Open full report</button></div>{reviewDraft.status === 'in_review' ? <div className="decision-box"><div className="field"><label htmlFor="review-comment">Comment (required for changes requested)</label><textarea id="review-comment" value={reviewComment} onChange={(event) => setReviewComment(event.target.value)} placeholder="What should the creator review or change?" /></div><div className="form-actions"><LoadingButton className="button-primary" onClick={() => decide('approve')} busy={busy === 'approve'}><Check size={13} />Approve</LoadingButton><LoadingButton className="button-danger" onClick={() => decide('request_changes')} busy={busy === 'request_changes'}><RefreshCw size={13} />Request changes</LoadingButton></div></div> : <div className="verified-claim" style={{ marginTop: 13 }}><strong>{reviewDraft.status === 'approved' ? 'Approved by human reviewer.' : 'Changes requested.'}</strong><small>Nothing was published.</small></div>}</> : <div className="empty-state"><FileCheck2 size={24} color="#72917e" /><strong>Select a draft to review.</strong><p>Its report, evidence, and available decisions will appear here.</p></div>}</section></div>{reviewDraft && <DraftComments draftId={reviewDraft.id} role={role} />}</>;
  };

  const renderBatch = () => <>
    <PageHeading eyebrow="Creator · multi-draft review" title="Check a batch in one pass." subtitle="Paste drafts separated by a line containing --- or upload a CSV with a text column. Every row is saved as a normal draft and can be opened for a full report." />
    <div className="new-content-layout">
      <section className="card panel">
        <div className="field full"><label htmlFor="batch-text">Paste drafts (separate each with a line containing ---)</label><textarea id="batch-text" rows={11} value={batchText} onChange={(event) => { setBatchText(event.target.value); setBatchCsv(null); }} placeholder={'Caption one\n---\nCaption two\n---\nCaption three'} /><small className="small-copy">Up to 12 drafts · 25,000 characters per draft. Each is checked and stored separately.</small></div>
        <div className="form-grid batch-options">
          <div className="field"><label htmlFor="batch-channel">Channel (applies to every row)</label><select id="batch-channel" value={channel} onChange={(event) => setChannel(event.target.value as Channel)}><option>Instagram</option><option>LinkedIn</option><option>Ad</option><option>Website</option></select></div>
          <div className="field"><label htmlFor="batch-product">Product (applies to every row)</label><select id="batch-product" value={productId} onChange={(event) => setProductId(Number(event.target.value))}>{guidelines?.products.map((product) => <option key={product.id} value={product.id}>{product.name} · ₹{product.approved_price.toLocaleString('en-IN')}</option>)}</select></div>
          <div className="field full"><label htmlFor="batch-csv">Or choose CSV file</label><input id="batch-csv" type="file" accept=".csv,text/csv" onChange={(event) => { setBatchCsv(event.target.files?.[0] ?? null); setBatchItems([]); }} /><small className="small-copy">UTF-8 CSV · required header: <code>text</code> · maximum file size 2 MB and 12 non-empty rows{batchCsv ? ` · selected: ${batchCsv.name}` : ''}</small></div>
        </div>
        {role !== 'Creator' && <div className="notice-banner">Switch to Creator before running batch checks. No check is run under this role.</div>}
        <div className="form-actions"><LoadingButton className="button-primary" onClick={runBatch} busy={busy === 'batch'} disabled={role !== 'Creator'}><Files size={14} />Run batch check</LoadingButton></div>
      </section>
      <aside className="card panel"><h2>One checker, many drafts</h2><p className="small-copy">Each item receives the same evidence-linked rule/AI checks, health score, and human-review workflow as a single draft.</p><div className="step-card"><strong>Nothing auto-publishes</strong><span>Batch checking creates draft reports only. Submit each item separately for human approval.</span></div><div className="step-card" style={{ marginTop: 9 }}><strong>Rate-limit aware</strong><span>Each draft counts toward the per-IP check limit. The full batch reserves check capacity before processing, so it cannot exceed the per-IP limit midway.</span></div></aside>
    </div>
    {batchItems.length > 0 && <section className="card panel batch-results"><div className="card-heading"><div><h2>Batch results</h2><div className="small-copy">{batchItems.length} draft(s) saved · open a row to view its full report</div></div></div><div className="batch-table-wrap"><table className="batch-table"><thead><tr><th>Draft</th><th>Health</th><th>Top issue</th><th>Status</th><th>Report</th></tr></thead><tbody>{batchItems.map((item) => <tr key={item.draft.id}><td><strong>Draft #{item.draft.id}</strong><small>{item.draft.text.slice(0, 86)}{item.draft.text.length > 86 ? '…' : ''}</small></td><td><strong>{item.revision.health_score}/100</strong></td><td>{item.top_issue ? humanize(item.top_issue) : 'No findings'}</td><td><StatusBadge status={item.draft.status} /></td><td><button className="button button-secondary button-small" onClick={() => openBatchResult(item)}><FileCheck2 size={13} />Open report</button></td></tr>)}</tbody></table></div></section>}
  </>;

  const renderDashboard = () => {
    const data = dashboard;
    const formula = 'Brand Health Score = max(0, 100 − 25×High − 12×Medium − 5×Low)';
    return <>
      <PageHeading eyebrow="Measured signals" title="See where reviews spend time." subtitle="Average health score uses each draft’s latest saved revision. Reviewer labels tune future finding severity; creator IDs are pseudonymous browser identifiers, not verified identities." />
      <div className="dashboard-stats">
        <div className="card metric"><span>Drafts tracked</span><strong>{data?.drafts_total ?? 0}</strong></div>
        <div className="card metric"><span>In review</span><strong>{data?.in_review ?? 0}</strong></div>
        <div className="card metric"><span>Approved</span><strong>{data?.approved ?? 0}</strong></div>
        <div className="card metric"><span>Human decisions</span><strong>{data?.decisions ?? 0}</strong></div>
        <div className="card metric" title={formula}><span>Average health score</span><strong>{data?.average_health_score ?? '—'}<small> / 100</small></strong></div>
      </div>
      <div className="chart-grid">
        <section className="card chart-card"><div className="card-heading"><div><h2>Findings by type</h2><div className="small-copy" style={{ marginTop: 4 }}>Across all saved check revisions</div></div></div><div className="chart-area">{data?.by_type.length ? <ResponsiveContainer width="100%" height="100%"><BarChart data={data.by_type} margin={{ top: 5, right: 8, left: -20, bottom: 42 }}><CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#edf0ec" /><XAxis dataKey="type" tick={{ fontSize: 9, fill: '#77827b' }} angle={-20} textAnchor="end" interval={0} /><YAxis allowDecimals={false} tick={{ fontSize: 10, fill: '#77827b' }} /><Tooltip /><Bar dataKey="count" name="Findings" fill="#4f826b" radius={[5, 5, 0, 0]} /></BarChart></ResponsiveContainer> : <div className="empty-state"><strong>No findings yet</strong><p>Check a sample to populate issue trends.</p></div>}</div></section>
        <section className="card chart-card"><div className="card-heading"><div><h2>Findings by severity</h2><div className="small-copy" style={{ marginTop: 4 }}>Rule and AI items from saved revisions</div></div></div><div className="chart-area">{data && data.by_severity.some((item) => item.count > 0) ? <ResponsiveContainer width="100%" height="100%"><PieChart><Pie data={data.by_severity} dataKey="count" nameKey="severity" cx="50%" cy="46%" innerRadius={55} outerRadius={82} paddingAngle={3}>{data.by_severity.map((item) => <Cell key={item.severity} fill={SEVERITY_COLORS[item.severity]} />)}</Pie><Tooltip /><text x="50%" y="47%" textAnchor="middle" dominantBaseline="middle" fill="#203b31" fontSize="17" fontWeight="700">{data.by_severity.reduce((sum, item) => sum + item.count, 0)}</text><text x="50%" y="55%" textAnchor="middle" dominantBaseline="middle" fill="#77827b" fontSize="10">findings</text></PieChart></ResponsiveContainer> : <div className="empty-state"><strong>No severity data yet</strong><p>Check a sample to populate the breakdown.</p></div>}</div><div className="chart-legend">{data?.by_severity.map((item) => <span key={item.severity}><i style={{ display: 'inline-block', width: 7, height: 7, borderRadius: 99, background: SEVERITY_COLORS[item.severity], marginRight: 5 }} />{item.severity} · {item.count}</span>)}</div></section>
        <section className="card chart-card"><div className="card-heading"><div><h2>Brand health by draft</h2><div className="small-copy" style={{ marginTop: 4 }}>Latest checked revision · formula: 100 − 25×High − 12×Medium − 5×Low, minimum 0</div></div></div><div className="chart-area">{data?.draft_health.length ? <ResponsiveContainer width="100%" height="100%"><BarChart data={data.draft_health} layout="vertical" margin={{ top: 5, right: 16, left: 4, bottom: 5 }}><CartesianGrid horizontal={false} strokeDasharray="3 3" stroke="#edf0ec" /><XAxis type="number" domain={[0, 100]} tick={{ fontSize: 9, fill: '#77827b' }} /><YAxis type="category" dataKey="label" width={74} tick={{ fontSize: 9, fill: '#77827b' }} /><Tooltip formatter={(value) => [`${value}/100`, 'Health score']} /><Bar dataKey="score" name="Health score" fill="#4f826b" radius={[0, 5, 5, 0]} /></BarChart></ResponsiveContainer> : <div className="empty-state"><strong>No checked drafts yet</strong><p>Health scores appear after the first brand check.</p></div>}</div></section>
        <section className="card chart-card"><div className="card-heading"><div><h2>Top recurring issues</h2><div className="small-copy" style={{ marginTop: 4 }}>Issues seen most often in a saved revision</div></div></div>{data?.top_issues.length ? <div className="guideline-list">{data.top_issues.map((item, index) => <div className="guideline-row" key={item.type}><div><strong>{index + 1}. {humanize(item.type)}</strong><small>Across revisions</small></div><span className="role-pill">{item.count}</span></div>)}</div> : <div className="empty-state"><strong>No recurring issues</strong><p>Issue patterns appear after the first checks.</p></div>}</section>
        <section className="card chart-card"><div className="card-heading"><div><h2>Human review outcomes</h2><div className="small-copy" style={{ marginTop: 4 }}>Approval vs. changes requested</div></div></div><div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}><div className="verified-claim"><strong>{data?.approval_rate ?? 0}% approved</strong><small>Of {data?.decisions ?? 0} completed decision(s)</small></div><div className="finding-suggestion"><strong>{data?.changes_requested_rate ?? 0}% changes requested</strong><br />Reviewer follow-up rate</div></div>{!data?.decisions && <p className="small-copy">Rates will update when the Reviewer records a decision.</p>}</section>
        <section className="card chart-card feedback-panel"><div className="card-heading"><div><h2>False-positive rate by rule</h2><div className="small-copy" style={{ marginTop: 4 }}>Reviewer labels · downgrade at 3+ labels and over 50%</div></div></div>{data?.false_positive_by_rule.length ? data.false_positive_by_rule.map((item) => <div className="feedback-row" key={item.rule}><div><strong>{humanize(item.rule)}</strong><small>{item.false_positives} false positive(s) / {item.labelled_findings} labelled</small></div><span className="feedback-rate">{Math.round(item.false_positive_rate * 100)}%{item.downgrade_active ? ' · active' : ''}</span></div>) : <div className="empty-state"><strong>No reviewer labels yet</strong><p>Mark findings valid or false positive to measure a rule.</p></div>}<div className="feedback-demo-note">Includes clearly seeded demo feedback examples.</div></section>
        <section className="card chart-card feedback-panel"><div className="card-heading"><div><h2>Recurring mistakes by rule</h2><div className="small-copy" style={{ marginTop: 4 }}>Latest check per draft plus seeded demo examples</div></div></div>{data?.recurring_by_rule.length ? data.recurring_by_rule.slice(0, 8).map((item) => <div className="feedback-row" key={item.rule}><div><strong>{humanize(item.rule)}</strong></div><span className="role-pill">{item.count}</span></div>) : <div className="empty-state"><strong>No recurring mistakes yet</strong><p>Checked drafts appear here as findings accumulate.</p></div>}</section>
        <section className="card chart-card feedback-panel"><div className="card-heading"><div><h2>Recurring mistakes by creator</h2><div className="small-copy" style={{ marginTop: 4 }}>Pseudonymous browser ID · seeded examples are labeled</div></div></div>{data?.recurring_by_creator.length ? data.recurring_by_creator.slice(0, 10).map((item, index) => <div className="feedback-row" key={`${item.creator_id}-${item.rule}-${index}`}><div><strong>{item.demo_example ? `Demo creator ${item.creator_id.slice(-1).toUpperCase()}` : `Creator ${item.creator_id.slice(0, 8)}`}</strong><small>{humanize(item.rule)} · {item.count} finding(s){item.demo_example ? ' · seeded demo example' : ''}</small></div></div>) : <div className="empty-state"><strong>No creator-level patterns yet</strong><p>New checks are grouped by browser-scoped pseudonymous ID.</p></div>}</section>
      </div>
    </>;
  };

  const renderHistory = () => <>
    <PageHeading eyebrow="Record of review" title="Every revision leaves a trail." subtitle="Inspect check versions, health scores, finding counts, decisions, comments, role labels, and timestamps." />
    {drafts.length ? <div className="review-layout">
      <section className="card panel"><div className="card-heading"><h2>Drafts</h2><span className="small-copy">{drafts.length} total</span></div><div className="review-list">{drafts.map((draft) => <button key={draft.id} className={`review-row ${historyDraft?.id === draft.id ? 'selected' : ''}`} onClick={() => openHistory(draft)} title={draft.latest_revision?.health_score_breakdown.formula}><div className="review-row-main"><strong>Draft #{draft.id} · {draft.product_name}</strong><small>{draft.channel} · {draft.latest_revision?.findings.length ?? 0} finding(s) · Health {draft.latest_revision ? `${draft.latest_revision.health_score}/100` : 'not checked'}</small></div><StatusBadge status={draft.status} /></button>)}</div></section>
      <section className="card panel">{historyDraft ? <><div className="card-heading"><div><h2>Draft #{historyDraft.id}</h2><div className="small-copy" style={{ marginTop: 4 }}>{historyDraft.channel} · {historyDraft.product_name}</div></div><StatusBadge status={historyDraft.status} /></div>{history ? <>
        {history.revisions.length >= 2 && <section className="revision-compare">
          <div className="card-heading"><div><h3 className="section-title">Compare revisions</h3><div className="small-copy">Choose any two saved checks. Findings are compared left → right.</div></div></div>
          <div className="compare-controls">
            <label>From revision<select value={compareLeft ?? ''} onChange={(event) => { setCompareLeft(event.target.value ? Number(event.target.value) : null); setRevisionComparison(null); }}>{history.revisions.map((revision) => <option key={revision.id} value={revision.number}>Revision {revision.number}</option>)}</select></label>
            <label>To revision<select value={compareRight ?? ''} onChange={(event) => { setCompareRight(event.target.value ? Number(event.target.value) : null); setRevisionComparison(null); }}>{history.revisions.map((revision) => <option key={revision.id} value={revision.number}>Revision {revision.number}</option>)}</select></label>
            <button className="button button-primary" onClick={compareSelectedRevisions} disabled={busy === 'compare' || compareLeft === null || compareRight === null || compareLeft === compareRight}>{busy === 'compare' ? 'Comparing…' : 'Compare'}</button>
          </div>
          {revisionComparison && <>
            <div className="compare-summary">
              <div><strong>Resolved findings · {revisionComparison.resolved_findings.length}</strong>{revisionComparison.resolved_findings.length ? <ul>{revisionComparison.resolved_findings.map((finding, index) => <li key={`${finding.type}-${finding.start}-${index}`}>{humanize(finding.type)} · {finding.severity}{finding.span ? ` · “${finding.span}”` : ''}</li>)}</ul> : <small>None resolved in this comparison.</small>}</div>
              <div><strong>New findings · {revisionComparison.new_findings.length}</strong>{revisionComparison.new_findings.length ? <ul>{revisionComparison.new_findings.map((finding, index) => <li key={`${finding.type}-${finding.start}-${index}`}>{humanize(finding.type)} · {finding.severity}{finding.span ? ` · “${finding.span}”` : ''}</li>)}</ul> : <small>No new findings in the later revision.</small>}</div>
            </div>
            <div className="inline-diff" role="region" aria-label={`Inline text diff from revision ${revisionComparison.left_revision.number} to ${revisionComparison.right_revision.number}`}>
              {revisionComparison.lines.map((line, index) => <div className={`diff-line ${line.kind}`} key={`${line.kind}-${index}`}><span className="diff-marker" aria-hidden="true">{line.kind === 'removed' ? '−' : line.kind === 'added' ? '+' : ' '}</span><code>{line.text || '\u00a0'}</code></div>)}
            </div>
          </>}
        </section>}
        <h3 className="section-title" style={{ margin: '12px 0' }}>Timeline</h3><div className="timeline">{[...history.revisions.map((item) => ({ type: 'revision', created_at: item.created_at, actor_role: item.actor_role, comment: `Revision ${item.number} · ${item.findings.length} finding(s) · Health ${item.health_score}/100 (${item.health_score_breakdown.counts.High} High, ${item.health_score_breakdown.counts.Medium} Medium, ${item.health_score_breakdown.counts.Low} Low)`, formula: item.health_score_breakdown.formula, key: `r-${item.id}`, status: undefined as string | undefined })), ...history.events.map((item) => ({ type: item.event_type, created_at: item.created_at, actor_role: item.actor_role, comment: item.comment, formula: undefined as string | undefined, key: `e-${item.id}`, status: item.status }))].sort((a, b) => new Date(a.created_at).getTime() - new Date(b.created_at).getTime()).map((item) => <div className="timeline-item" key={item.key} title={item.formula}><span className="timeline-dot" /><strong>{humanize(item.type)}{item.status ? ` · ${statusLabel(item.status)}` : ''}</strong><small>{item.actor_role} · {dateLabel(item.created_at)}</small><p>{item.comment}</p></div>)}</div></> : <div className="empty-state"><LoaderCircle size={20} /><p>Loading timeline…</p></div>}</> : <div className="empty-state"><Clock3 size={24} /><strong>Select a draft.</strong><p>Its revisions and decisions will appear here.</p></div>}</section>
    </div> : <div className="card empty-state"><strong>No drafts in history yet.</strong><p>Check a sample to create the first revision record.</p><button className="button button-primary" onClick={() => beginSample(samples[0])}>Try a sample</button></div>}
  </>;

  const renderEvidence = () => {
    if (role !== 'Admin') return <><PageHeading eyebrow="Admin workspace" title="Evidence library" subtitle="Switch to Admin to manage supporting documents." /><div className="card empty-state"><strong>Admin role required</strong><p>The role switcher is a demo workflow control, not real authentication.</p></div></>;
    const documents = guidelines?.evidence_documents ?? [];
    return <>
      <PageHeading eyebrow="Admin · source documents" title="Put evidence behind the claim." subtitle="Upload a titled UTF-8 text file or text-based PDF. The extracted text is searched locally when a draft contains a claim needing evidence; documents are not sent to the AI provider." />
      <div className="new-content-layout">
        <section className="card panel">
          <div className="card-heading"><div><h2>Add an evidence document</h2><div className="small-copy" style={{ marginTop: 4 }}>Maximum 2 MB · selectable PDF text only · no OCR</div></div><span className="role-pill">Admin</span></div>
          <form onSubmit={uploadEvidence}>
            <div className="form-grid">
              <div className="field full"><label htmlFor="evidence-title">Document title</label><input id="evidence-title" maxLength={200} value={evidenceTitle} onChange={(event) => setEvidenceTitle(event.target.value)} placeholder="e.g. Cotton test report 2026" required /></div>
              <div className="field full"><label htmlFor="evidence-file">Text or PDF file</label><input id="evidence-file" type="file" accept=".txt,.md,.pdf,text/plain,text/markdown,application/pdf" onChange={(event) => setEvidenceFile(event.target.files?.[0] ?? null)} required /><span className="field-hint">Accepted: .txt, .md, .pdf · maximum 2 MB{evidenceFile ? ` · ${evidenceFile.name} · ${(evidenceFile.size / 1024).toFixed(0)} KB` : ''}</span></div>
            </div>
            <div className="form-actions"><LoadingButton type="submit" className="button-primary" busy={busy === 'evidence-upload'} disabled={role !== 'Admin'}><Upload size={13} />Extract and save document</LoadingButton></div>
          </form>
        </section>
        <aside className="card panel"><div className="card-heading"><div><h2>Retrieval safeguards</h2><div className="small-copy" style={{ marginTop: 4 }}>Evidence is not a general truth verifier.</div></div></div><p className="small-copy">The checker uses exact or high-overlap text matching against extracted sentences. A match suppresses the “needs evidence” finding and shows the document title and excerpt. No match keeps the finding and says “No evidence found”.</p><div className="step-card"><strong>Seeded example</strong><span>Cotton Certificate CC-2026-14 (demo sample; not a real-world certificate).</span></div></aside>
      </div>
      <section className="card panel batch-results"><div className="card-heading"><div><h2>Evidence documents</h2><div className="small-copy">{documents.length} document(s) · a saved review keeps its original evidence snapshot</div></div></div>{documents.length ? <div className="guideline-list">{documents.map((document) => <div className="guideline-row" key={document.id}><div><strong>{document.title}</strong><small>{document.source_filename} · added {dateLabel(document.created_at)}</small></div><button className="button button-danger button-small" disabled={!!busy} onClick={() => deleteEvidence(document)} aria-label={`Delete evidence document ${document.title}`}>Remove</button></div>)}</div> : <div className="empty-state"><strong>No evidence documents yet.</strong><p>Upload a text or text-based PDF document to let future checks search it.</p></div>}</section>
    </>;
  };

  const renderGuidelines = () => {
    if (!guidelines) return <div className="card empty-state"><LoaderCircle size={20} /><p>Loading brand records…</p></div>;
    const canManage = role === 'Admin';
    const card = (title: string, rows: { id: number; guideline_ref: string; title: string; subtitle: string }[], kind: EditorKind, onAdd: () => void, empty = 'No records yet.') => <section className="card panel"><div className="card-heading"><div><h2>{title}</h2><div className="small-copy" style={{ marginTop: 4 }}>{rows.length} record(s) · changes affect future checks</div></div>{canManage && <button className="button button-secondary button-small" onClick={onAdd}><Plus size={13} />Add</button>}</div><GuidelineRows rows={rows} highlighted={highlightedGuideline} canManage={canManage} onEdit={(item) => { const source = kind === 'product' ? guidelines.products : kind === 'term' ? guidelines.banned_terms : kind === 'preferred' ? guidelines.preferred_terms : kind === 'claim' ? guidelines.approved_claims : kind === 'tone' ? guidelines.tone_rules : guidelines.disclaimers; const row = source.find((record) => record.id === item.id); if (row) openEditor(kind, row as Product | BannedTerm | PreferredTerm | ApprovedClaim | ToneRule | Disclaimer); }} onDelete={(id) => deleteGuideline(kind, id)} />{rows.length === 0 && <div className="small-copy">{empty}</div>}</section>;
    return <><PageHeading eyebrow={`${guidelines.brand.name} · ${canManage ? 'Admin' : 'Read only'}`} title="Keep the source of truth current." subtitle={canManage ? 'Edit approved facts, claims, tone, disclaimers, and logo metadata. New checks use the latest saved guidelines.' : 'Inspect the exact approved records behind this finding. Switch to Admin to make changes.'} />
      <div className="guideline-grid">
        {card('Products & approved price', guidelines.products.map((p) => ({ id: p.id, guideline_ref: p.guideline_ref, title: p.name, subtitle: `₹${p.approved_price.toLocaleString('en-IN')} · ${p.material}` })), 'product', () => setEditor({ kind: 'product', id: null, title: 'Add product', values: { name: '', approved_price: '', material: '' } }))}
        {card('Banned / unapproved terms', guidelines.banned_terms.map((p) => ({ id: p.id, guideline_ref: p.guideline_ref, title: p.term, subtitle: 'Do not use in public-facing copy.' })), 'term', () => setEditor({ kind: 'term', id: null, title: 'Add banned term', values: { term: '' } }))}
        {card('Preferred terminology', guidelines.preferred_terms.map((p) => ({ id: p.id, guideline_ref: p.guideline_ref, title: p.term, subtitle: `Use “${p.preferred}” instead.` })), 'preferred', () => setEditor({ kind: 'preferred', id: null, title: 'Add preferred wording', values: { term: '', preferred: '' } }))}
        {card('Approved claims & evidence', guidelines.approved_claims.map((p) => ({ id: p.id, guideline_ref: p.guideline_ref, title: p.claim, subtitle: p.evidence })), 'claim', () => setEditor({ kind: 'claim', id: null, title: 'Add approved claim', values: { claim: '', evidence: '' } }))}
        {card('Tone rules', guidelines.tone_rules.map((p) => ({ id: p.id, guideline_ref: p.guideline_ref, title: p.name, subtitle: `${p.description}${p.threshold !== null ? ` · Threshold ${p.threshold}` : ''}${p.enabled ? '' : ' · Disabled'}` })), 'tone', () => setEditor({ kind: 'tone', id: null, title: 'Add tone rule', values: { name: '', description: '', threshold: '', enabled: true } }))}
        {card('Required disclaimers', guidelines.disclaimers.map((p) => ({ id: p.id, guideline_ref: p.guideline_ref, title: p.phrase, subtitle: `Applies to ${p.applies_to}` })), 'disclaimer', () => setEditor({ kind: 'disclaimer', id: null, title: 'Add disclaimer', values: { phrase: '', applies_to: 'price or discount posts' } }))}
        <section className="card panel"><div className="card-heading"><div><h2>Approved logo</h2><div className="small-copy" style={{ marginTop: 4 }}>Metadata plus an image used by OpenCV template matching.</div></div>{canManage && <div className="row-actions"><button className="button button-secondary button-small" onClick={() => openEditor('logo')}><FileText size={13} />Edit metadata</button>{guidelines.logo && <button className="icon-button" aria-label="Delete logo metadata" onClick={async () => { try { await api.deleteLogo(); await refreshData(); notify('Logo metadata removed.'); } catch (error) { notify(messageFrom(error), true); } }}><Trash2 size={14} /></button>}</div>}</div>{guidelines.logo ? <div className="guideline-row" data-guideline-ref={guidelines.logo.guideline_ref}><div><strong>Version {guidelines.logo.version}</strong><small>{guidelines.logo.approved ? 'Approved' : 'Not approved'}</small></div><BadgeCheck size={16} color="#47755d" /></div> : <div className="small-copy">No logo metadata saved.</div>}<div className="guideline-row"><div><strong>{guidelines.approved_logo_image ? guidelines.approved_logo_image.source_filename : 'No approved logo image uploaded'}</strong><small>{guidelines.approved_logo_image ? `Image template · ${guidelines.approved_logo_image.content_type} · updated ${dateLabel(guidelines.approved_logo_image.updated_at)}` : 'Ad creatives will show a friendly skip notice until an image is uploaded.'}</small></div>{guidelines.approved_logo_image && <BadgeCheck size={16} color="#47755d" />}</div>{canManage && <form onSubmit={uploadApprovedLogo}><div className="field" style={{ marginTop: 12 }}><label htmlFor="approved-logo-image-file">Approved logo image (PNG/JPG)</label><input id="approved-logo-image-file" type="file" accept="image/png,image/jpeg,.png,.jpg,.jpeg" onChange={(event) => setLogoImageFile(event.target.files?.[0] ?? null)} /><span className="field-hint">Maximum 5 MB · tightly cropped, high-contrast logo works best{logoImageFile ? ` · ${logoImageFile.name}` : ''}</span></div><div className="form-actions"><LoadingButton type="submit" className="button-primary" busy={busy === 'logo-image'} disabled={!logoImageFile}><Upload size={13} />Save approved logo image</LoadingButton></div></form>}</section>
      </div>{canManage && <div className="form-actions"><LoadingButton className="button-danger" onClick={resetDemo} busy={busy === 'reset'}><RotateCcw size={13} />Reset demo data</LoadingButton></div>}<EditorModal editor={editor} setEditor={setEditor} onSave={saveEditor} busy={busy === 'guideline-save'} />
    </>;
  };

  if (loading) return <div className="app-shell"><div style={{ margin: 'auto', display: 'flex', alignItems: 'center', gap: 10, color: '#587266' }}><LoaderCircle className="spin" size={18} />Opening DemoWear review desk…</div></div>;

  return <div className="app-shell"><aside className="sidebar"><div className="brand-lockup"><IconMark /><div className="brand-word"><div className="brand-name">inkloom</div><div className="brand-caption">brand review desk</div></div></div><div className="nav-label">Workspace</div><nav className="nav-stack" aria-label="Main navigation">{navItems.map((item) => { const Icon = item.icon; return <button key={item.id} className={`nav-item ${view === item.id || (view === 'report' && item.id === 'new') ? 'active' : ''}`} onClick={() => setView(item.id)}><Icon size={16} /><span>{item.label}</span></button>; })}</nav><div className="sidebar-bottom"><div className="brand-card"><div className="brand-card-label">Active brand</div><strong>{guidelines?.brand.name || 'DemoWear'}</strong><small>Classic T-shirt · ₹599</small></div><div className="sidebar-role"><label htmlFor="role-switch">Viewing as</label><select id="role-switch" value={role} onChange={setRoleFromSelect}><option>Creator</option><option>Reviewer</option><option>Admin</option></select></div></div></aside><main className="main-shell"><header className="topbar"><div className="crumb">Inkloom <ChevronRight size={12} style={{ verticalAlign: 'middle', margin: '0 4px' }} /> {VIEW_NAMES[view]}</div><div className="topbar-right"><span className="topbar-brand">{guidelines?.brand.name || 'DemoWear'}</span><span className="role-pill">{role}</span><select aria-label="Switch role" className="mobile-role" value={role} onChange={setRoleFromSelect}><option>Creator</option><option>Reviewer</option><option>Admin</option></select></div></header><nav className="mobile-nav" aria-label="Mobile navigation">{navItems.map((item) => { const Icon = item.icon; return <button key={item.id} className={view === item.id || (view === "report" && item.id === "new") ? "active" : ""} onClick={() => setView(item.id)}><Icon size={14} /><span>{item.label}</span></button>; })}</nav><div className="page-wrap">{view === 'home' && renderHome()}{view === 'new' && renderNew()}{view === 'batch' && renderBatch()}{view === 'report' && renderReport()}{view === 'review' && renderReview()}{view === 'dashboard' && renderDashboard()}{view === 'history' && renderHistory()}{view === 'guidelines' && renderGuidelines()}{view === 'evidence' && renderEvidence()}{view === 'evaluation' && renderEvaluation()}{view === 'audit-log' && renderAuditLog()}{view === 'status' && renderStatus()}<footer className="page-footer">Inkloom AI · Evidence-backed checks · Human-approved · Nothing is auto-published.</footer></div></main>{toast && <div className={`toast ${toast.error ? 'error' : ''}`} role="status">{toast.error ? <AlertCircle size={14} style={{ verticalAlign: 'middle', marginRight: 7 }} /> : <CheckCircle2 size={14} style={{ verticalAlign: 'middle', marginRight: 7 }} />}{toast.message}</div>}</div>;
}

export default App;
