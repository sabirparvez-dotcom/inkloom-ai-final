export type Role = 'Creator' | 'Reviewer' | 'Admin';
export type Channel = 'Instagram' | 'LinkedIn' | 'Ad' | 'Website';
export type Severity = 'High' | 'Medium' | 'Low' | 'Info';

export interface Evidence {
  label: string;
  detail?: string;
  guideline_ref: string;
  href?: string;
}

export interface Finding {
  type: string;
  span: string;
  start: number;
  end: number;
  explanation: string;
  guideline_ref: string;
  evidence: Evidence[];
  severity: Severity;
  suggestion: string;
  source: 'Rule' | 'AI' | 'Visual';
  confidence?: number | null;
  confidence_label?: 'Low' | 'Moderate' | null;
  uncertainty?: string | null;
  replacement?: string | null;
  reviewer_label?: 'valid' | 'false_positive' | null;
  dismissal_reason?: string | null;
  dismissed_by_role?: Role | null;
  dismissed_at?: string | null;
  severity_before_feedback?: Severity;
  severity_downgraded_by_feedback?: boolean;
  severity_note?: string;
  feedback_false_positive_rate?: number;
  feedback_label_count?: number;
}

export interface DraftComment {
  id: number;
  draft_id: number;
  actor_role: Role;
  message: string;
  created_at: string;
}

export interface VerifiedClaim {
  claim: string;
  evidence: string;
  guideline_ref: string;
  href?: string;
  source?: 'Approved claim' | 'Evidence library';
  document_title?: string;
}

export interface EvidenceDocument {
  id: number;
  title: string;
  source_filename: string;
  created_at: string;
}

export interface Revision {
  id: number;
  draft_id: number;
  number: number;
  text: string;
  findings: Finding[];
  health_score: number;
  health_score_breakdown: HealthScoreBreakdown;
  verified_claims: VerifiedClaim[];
  ai_available: boolean;
  ai_notice?: string | null;
  actor_role: Role;
  guideline_version: number;
  created_at: string;
}

export interface HealthScoreBreakdown {
  score: number;
  base_score: number;
  counts: Record<Exclude<Severity, 'Info'>, number>;
  weights: Record<Exclude<Severity, 'Info'>, number>;
  deductions: Record<Exclude<Severity, 'Info'>, number>;
  formula: string;
}

export interface Draft {
  id: number;
  text: string;
  assets: string[];
  channel: Channel;
  product_id: number;
  creator_id: string;
  creative?: CreativeAssetSummary | null;
  product_name: string;
  status: string;
  created_at: string;
  updated_at: string;
  latest_revision?: Revision | null;
}

export interface CreativeAssetSummary {
  source_filename: string;
  content_type: 'image/png' | 'image/jpeg';
  ocr_notice: string | null;
  logo_notice: string | null;
}

export interface BatchCheckItem {
  draft: Draft;
  revision: Revision;
  top_issue: string | null;
}

export interface BatchCheckResponse {
  count: number;
  items: BatchCheckItem[];
}

export interface SampleDraft {
  id: number;
  title: string;
  text: string;
  channel: Channel;
}

export interface Product {
  id: number;
  name: string;
  approved_price: number;
  material: string;
  guideline_ref: string;
}

export interface BannedTerm {
  id: number;
  term: string;
  guideline_ref: string;
}

export interface PreferredTerm {
  id: number;
  term: string;
  preferred: string;
  guideline_ref: string;
}

export interface ApprovedClaim {
  id: number;
  claim: string;
  evidence: string;
  guideline_ref: string;
}

export interface ToneRule {
  id: number;
  name: string;
  description: string;
  threshold: number | null;
  enabled: boolean;
  guideline_ref: string;
}

export interface Disclaimer {
  id: number;
  phrase: string;
  applies_to: string;
  guideline_ref: string;
}

export interface LogoVersion {
  id: number;
  version: string;
  approved: boolean;
  guideline_ref: string;
}

export interface Guidelines {
  version: number;
  brand: { id: number; name: string };
  products: Product[];
  banned_terms: BannedTerm[];
  preferred_terms: PreferredTerm[];
  approved_claims: ApprovedClaim[];
  tone_rules: ToneRule[];
  disclaimers: Disclaimer[];
  logo: LogoVersion | null;
  approved_logo_image: { source_filename: string; content_type: 'image/png' | 'image/jpeg'; updated_at: string } | null;
  evidence_documents: EvidenceDocument[];
}

export interface HistoryEvent {
  id: number;
  event_type: string;
  status: string;
  comment: string;
  actor_role: Role;
  created_at: string;
}

export interface DraftHistory {
  revisions: Revision[];
  events: HistoryEvent[];
}

export interface InlineDiffLine {
  kind: 'unchanged' | 'added' | 'removed';
  text: string;
}

export interface RevisionComparison {
  left_revision: Revision;
  right_revision: Revision;
  lines: InlineDiffLine[];
  resolved_findings: Finding[];
  new_findings: Finding[];
}

export interface DashboardData {
  by_type: { type: string; count: number }[];
  by_severity: { severity: Severity; count: number }[];
  top_issues: { type: string; count: number }[];
  approval_rate: number;
  changes_requested_rate: number;
  decisions: number;
  drafts_total: number;
  in_review: number;
  approved: number;
  average_health_score: number | null;
  draft_health: { draft_id: number; label: string; score: number }[];
  false_positive_by_rule: { rule: string; labelled_findings: number; false_positives: number; false_positive_rate: number; downgrade_active: boolean }[];
  recurring_by_rule: { rule: string; count: number }[];
  recurring_by_creator: { creator_id: string; rule: string; count: number; demo_example: boolean }[];
}

export interface EvaluationMetric {
  cases: number;
  expected_findings: number;
  predicted_findings: number;
  true_positives: number;
  false_positive_count: number;
  false_negatives: number;
  precision: number | null;
  recall: number | null;
}

export interface EvaluationInfo {
  dataset_id: string;
  dataset_version: number;
  case_count: number;
  cases: { id: string; title: string; text: string; expected_types: string[] }[];
}

export interface EvaluationRun {
  dataset_id: string;
  dataset_version: number;
  case_count: number;
  ai_configured: boolean;
  ai_available: boolean;
  ai_notice: string | null;
  combined_uses_rules_only_fallback: boolean;
  metrics: { rules_only: EvaluationMetric; ai_only: EvaluationMetric | null; combined: EvaluationMetric };
}

export interface ServiceStatus {
  database_health: 'ok' | 'unavailable';
  ai_configured: boolean;
  ai_reachability: 'not_configured' | 'unknown_not_probed';
  ai_calls_used_today: number;
  ai_daily_cap: number;
  guideline_version: number | null;
  app_version: string;
}

export interface AuditEntry {
  id: string;
  actor_role: Role;
  action: string;
  draft_id: number | null;
  draft_title: string | null;
  created_at: string;
}
