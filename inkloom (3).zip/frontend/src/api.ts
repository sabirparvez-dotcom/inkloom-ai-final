import type { AuditEntry, BatchCheckResponse, Channel, Draft, DraftComment, EvidenceDocument, DraftHistory, Draft as DraftType, EvaluationInfo, EvaluationRun, Guidelines, DashboardData, Revision, RevisionComparison, Role, SampleDraft, ServiceStatus } from './types';

export class ApiError extends Error {
  status: number;
  constructor(message: string, status: number) {
    super(message);
    this.name = 'ApiError';
    this.status = status;
  }
}

async function request<T>(path: string, init?: RequestInit): Promise<T> {
  const response = await fetch(path, {
    ...init,
    headers: { ...(init?.body instanceof FormData ? {} : { 'Content-Type': 'application/json' }), ...init?.headers },
  });
  if (!response.ok) {
    let message = 'Something went wrong. Please try again.';
    try {
      const data = await response.json();
      message = typeof data.detail === 'string' ? data.detail : Array.isArray(data.detail) ? data.detail.map((item: { msg?: string }) => item.msg).join(' ') : message;
    } catch { /* response did not contain JSON */ }
    throw new ApiError(message, response.status);
  }
  return response.json() as Promise<T>;
}

const json = (value: unknown, method = 'POST'): RequestInit => ({ method, body: JSON.stringify(value) });

function creatorIdentifier(): string {
  if (typeof window === 'undefined') return 'unattributed-browser';
  try {
    const existing = window.localStorage.getItem('inkloom-creator-id');
    if (existing) return existing;
    const generated = window.crypto?.randomUUID?.() ?? `browser-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 10)}`;
    window.localStorage.setItem('inkloom-creator-id', generated);
    return generated;
  } catch { return 'unattributed-browser'; }
}

export const api = {
  health: () => request<{ status: string; ai_configured?: boolean; ai_notice?: string | null }>('/health'),
  guidelines: () => request<Guidelines>('/api/guidelines'),
  samples: () => request<SampleDraft[]>('/api/samples'),
  drafts: () => request<Draft[]>('/api/drafts'),
  createAndCheck: (data: { text: string; channel: Channel; product_id: number; role: Role }) => request<{ draft: Draft; revision: Draft['latest_revision'] }>('/api/check', json({ ...data, creator_id: creatorIdentifier() })),
  batchCheck: (texts: string[], channel: Channel, productId: number, role: Role) => request<BatchCheckResponse>('/api/batch-check', json({ texts, channel, product_id: productId, role, creator_id: creatorIdentifier() })),
  batchCheckCsv: (file: File, channel: Channel, productId: number, role: Role) => {
    const form = new FormData();
    form.append('file', file);
    form.append('channel', channel);
    form.append('product_id', String(productId));
    form.append('role', role);
    form.append('creator_id', creatorIdentifier());
    return request<BatchCheckResponse>('/api/batch-check/csv', { method: 'POST', body: form });
  },
  checkPdf: (file: File, channel: Channel, productId: number, role: Role) => {
    const form = new FormData();
    form.append('file', file);
    form.append('channel', channel);
    form.append('product_id', String(productId));
    form.append('role', role);
    form.append('creator_id', creatorIdentifier());
    return request<{ draft: Draft; revision: Draft['latest_revision'] }>('/api/check/pdf', { method: 'POST', body: form });
  },
  checkCreative: (file: File, productId: number, role: Role) => {
    const form = new FormData();
    form.append('file', file);
    form.append('channel', 'Ad');
    form.append('product_id', String(productId));
    form.append('role', role);
    form.append('creator_id', creatorIdentifier());
    return request<{ draft: Draft; revision: Draft['latest_revision'] }>('/api/creative-check', { method: 'POST', body: form });
  },
  updateDraft: (id: number, text: string, role: Role) => request<Draft>(`/api/drafts/${id}`, json({ text, role }, 'PATCH')),
  rerunCheck: (id: number, text: string, role: Role) => request<{ draft: Draft; revision: Draft['latest_revision'] }>(`/api/drafts/${id}/check`, json({ text, role })),
  submit: (id: number, role: Role) => request<Draft>(`/api/drafts/${id}/submit`, json({ role })),
  decide: (id: number, action: 'approve' | 'request_changes', comment: string) => request<Draft>(`/api/drafts/${id}/decision`, json({ action, comment, role: 'Reviewer' })),
  dismissFinding: (draftId: number, revision: number, findingIndex: number, reason: string) => request<Revision>(`/api/drafts/${draftId}/revisions/${revision}/findings/${findingIndex}/dismiss`, json({ reason, role: 'Reviewer' })),
  setFindingLabel: (draftId: number, revision: number, findingIndex: number, reviewerLabel: 'valid' | 'false_positive' | null) => request<Revision>(`/api/drafts/${draftId}/revisions/${revision}/findings/${findingIndex}/label`, json({ reviewer_label: reviewerLabel, role: 'Reviewer' }, 'PUT')),
  comments: (draftId: number) => request<DraftComment[]>(`/api/drafts/${draftId}/comments`),
  addComment: (draftId: number, message: string, role: Role) => request<DraftComment>(`/api/drafts/${draftId}/comments`, json({ message, role })),
  history: (id: number) => request<DraftHistory>(`/api/drafts/${id}/history`),
  compareRevisions: (id: number, leftRevision: number, rightRevision: number) => request<RevisionComparison>(`/api/drafts/${id}/compare?left_revision=${leftRevision}&right_revision=${rightRevision}`),
  dashboard: () => request<DashboardData>('/api/dashboard'),
  evaluationInfo: () => request<EvaluationInfo>('/api/evaluation'),
  runEvaluation: (role: Role) => request<EvaluationRun>(`/api/evaluation/run?role=${encodeURIComponent(role)}`, json({})),
  status: () => request<ServiceStatus>('/api/status'),
  auditLog: (role: Role) => request<{ items: AuditEntry[]; total: number }>(`/api/audit-log?role=${encodeURIComponent(role)}`),
  auditCsv: async (role: Role): Promise<Blob> => {
    const response = await fetch(`/api/audit-log.csv?role=${encodeURIComponent(role)}`);
    if (!response.ok) throw new ApiError('The audit CSV could not be exported.', response.status);
    return response.blob();
  },
  loadDemo: (role: Role) => request<{ loaded: boolean; preserved_existing_work: boolean }>(`/api/demo/load?role=${encodeURIComponent(role)}`, json({})),
  reset: () => request<{ reset: boolean }>('/api/demo/reset?role=Admin', json({})),
  createProduct: (data: { name: string; approved_price: number; material: string }) => request('/api/guidelines/products?role=Admin', json(data)),
  updateProduct: (id: number, data: { name: string; approved_price: number; material: string }) => request(`/api/guidelines/products/${id}?role=Admin`, json(data, 'PUT')),
  deleteProduct: (id: number) => request(`/api/guidelines/products/${id}?role=Admin`, { method: 'DELETE' }),
  createTerm: (term: string) => request('/api/guidelines/banned-terms?role=Admin', json({ term })),
  updateTerm: (id: number, term: string) => request(`/api/guidelines/banned-terms/${id}?role=Admin`, json({ term }, 'PUT')),
  deleteTerm: (id: number) => request(`/api/guidelines/banned-terms/${id}?role=Admin`, { method: 'DELETE' }),
  createPreferredTerm: (term: string, preferred: string) => request('/api/guidelines/preferred-terms?role=Admin', json({ term, preferred })),
  updatePreferredTerm: (id: number, term: string, preferred: string) => request(`/api/guidelines/preferred-terms/${id}?role=Admin`, json({ term, preferred }, 'PUT')),
  deletePreferredTerm: (id: number) => request(`/api/guidelines/preferred-terms/${id}?role=Admin`, { method: 'DELETE' }),
  createClaim: (claim: string, evidence: string) => request('/api/guidelines/approved-claims?role=Admin', json({ claim, evidence })),
  updateClaim: (id: number, claim: string, evidence: string) => request(`/api/guidelines/approved-claims/${id}?role=Admin`, json({ claim, evidence }, 'PUT')),
  deleteClaim: (id: number) => request(`/api/guidelines/approved-claims/${id}?role=Admin`, { method: 'DELETE' }),
  createTone: (name: string, description: string, threshold: number | null, enabled = true) => request('/api/guidelines/tone-rules?role=Admin', json({ name, description, threshold, enabled })),
  updateTone: (id: number, name: string, description: string, threshold: number | null, enabled: boolean) => request(`/api/guidelines/tone-rules/${id}?role=Admin`, json({ name, description, threshold, enabled }, 'PUT')),
  deleteTone: (id: number) => request(`/api/guidelines/tone-rules/${id}?role=Admin`, { method: 'DELETE' }),
  createDisclaimer: (phrase: string, applies_to: string) => request('/api/guidelines/disclaimers?role=Admin', json({ phrase, applies_to })),
  updateDisclaimer: (id: number, phrase: string, applies_to: string) => request(`/api/guidelines/disclaimers/${id}?role=Admin`, json({ phrase, applies_to }, 'PUT')),
  deleteDisclaimer: (id: number) => request(`/api/guidelines/disclaimers/${id}?role=Admin`, { method: 'DELETE' }),
  updateLogo: (version: string, approved: boolean) => request('/api/guidelines/logo?role=Admin', json({ version, approved }, 'PUT')),
  deleteLogo: () => request('/api/guidelines/logo?role=Admin', { method: 'DELETE' }),
  uploadEvidenceDocument: (title: string, file: File) => {
    const form = new FormData();
    form.append('title', title);
    form.append('file', file);
    form.append('role', 'Admin');
    return request<EvidenceDocument>('/api/guidelines/evidence-documents', { method: 'POST', body: form });
  },
  deleteEvidenceDocument: (id: number) => request<{ deleted: boolean }>(`/api/guidelines/evidence-documents/${id}?role=Admin`, { method: 'DELETE' }),
  uploadApprovedLogo: (file: File) => {
    const form = new FormData();
    form.append('file', file);
    form.append('role', 'Admin');
    return request<Guidelines['approved_logo_image']>('/api/guidelines/approved-logo-image', { method: 'POST', body: form });
  },
  async report(id: number): Promise<Blob> {
    const response = await fetch(`/api/drafts/${id}/report.pdf`);
    if (!response.ok) throw new ApiError('The report could not be exported.', response.status);
    return response.blob();
  },
};

export type { DraftHistory, DraftType };
