from __future__ import annotations

import pytest
from fastapi.testclient import TestClient

from backend.inkloom.db import make_engine
from backend.inkloom.main import create_app


@pytest.fixture
def client(tmp_path, monkeypatch):
    monkeypatch.delenv("OPENAI_API_KEY", raising=False)
    monkeypatch.delenv("ANTHROPIC_API_KEY", raising=False)
    engine = make_engine(f"sqlite:///{tmp_path / 'test-inkloom.db'}")
    app = create_app(engine)
    with TestClient(app) as test_client:
        yield test_client
    engine.dispose()


def check(client: TestClient, text: str):
    return client.post("/api/check", json={"text": text, "channel": "Instagram", "product_id": 1, "role": "Creator"})


def test_price_mismatch_is_downgraded_by_seeded_reviewer_feedback(client):
    response = check(client, "Classic tee only ₹499")
    assert response.status_code == 200
    findings = response.json()["revision"]["findings"]
    price = [item for item in findings if item["type"] == "price_mismatch"]
    assert price
    assert price[0]["severity"] == "Medium"
    assert price[0]["severity_before_feedback"] == "High"
    assert price[0]["severity_note"] == "Downgraded by reviewer feedback"
    assert price[0]["guideline_ref"] == "product:1"


def test_banned_term_detected(client):
    response = check(client, "The cheapest T-shirt in town")
    findings = response.json()["revision"]["findings"]
    assert any(item["type"] == "banned_term" and item["span"].lower() == "cheapest" for item in findings)


def test_price_content_requires_disclaimer(client):
    response = check(client, "Now just ₹499")
    findings = response.json()["revision"]["findings"]
    disclaimer = next(item for item in findings if item["type"] == "missing_disclaimer")
    assert disclaimer["span"] == "T&C apply"
    assert disclaimer["severity"] == "Medium"


def test_compliant_draft_passes_and_approved_claim_shows_evidence(client):
    response = check(client, "Classic T-shirt at ₹599. Made with 100% cotton. T&C apply.")
    assert response.status_code == 200
    revision = response.json()["revision"]
    assert revision["findings"] == []
    assert revision["verified_claims"][0]["evidence"] == "Cotton Certificate #CC-2026-14"


def test_tone_rules_flag_extra_exclamation_and_all_caps(client):
    response = check(client, "BUY NOW!!")
    types = {item["type"] for item in response.json()["revision"]["findings"]}
    assert "excessive_exclamation" in types
    assert "all_caps_word" in types


def test_no_ai_key_returns_visible_rules_only_notice(client):
    health = client.get("/health")
    assert health.status_code == 200
    assert health.json()["ai_notice"] == "AI analysis unavailable. Showing rule-based checks only."
    report = check(client, "The cheapest T-shirt")
    assert report.json()["revision"]["ai_available"] is False
    assert report.json()["revision"]["ai_notice"] == "AI analysis unavailable. Showing rule-based checks only."


def test_ai_provider_failure_falls_back_without_crashing(monkeypatch):
    from backend.inkloom.services import ai

    monkeypatch.setenv("OPENAI_API_KEY", "not-a-real-test-key")
    monkeypatch.delenv("ANTHROPIC_API_KEY", raising=False)
    monkeypatch.delenv("OPENAI_API_BASE", raising=False)

    def fail(*args, **kwargs):
        raise RuntimeError("simulated provider outage")

    monkeypatch.setattr(ai, "_call_provider", fail)
    result = ai.analyze_draft("Best quality in India", [{"ref": "tone_rule:1", "text": "professional"}])
    assert result.available is False
    assert result.findings == []
    assert result.notice == "AI analysis unavailable. Showing rule-based checks only."


def test_workflow_requires_review_role_and_records_human_decision(client):
    result = check(client, "Classic T-shirt at ₹599. Made with 100% cotton. T&C apply.").json()
    draft_id = result["draft"]["id"]
    forbidden = client.post(f"/api/drafts/{draft_id}/submit", json={"role": "Reviewer"})
    assert forbidden.status_code == 403
    submitted = client.post(f"/api/drafts/{draft_id}/submit", json={"role": "Creator"})
    assert submitted.status_code == 200
    assert submitted.json()["status"] == "in_review"
    approved = client.post(f"/api/drafts/{draft_id}/decision", json={"action": "approve", "comment": "Looks good.", "role": "Reviewer"})
    assert approved.status_code == 200
    assert approved.json()["status"] == "approved"
    events = client.get(f"/api/drafts/{draft_id}/history").json()["events"]
    assert any(item["event_type"] == "approved" and item["actor_role"] == "Reviewer" for item in events)


def test_guideline_crud_and_admin_role_guard(client):
    denied = client.post("/api/guidelines/banned-terms?role=Creator", json={"term": "overpromise"})
    assert denied.status_code == 403
    created = client.post("/api/guidelines/banned-terms?role=Admin", json={"term": "overpromise"})
    assert created.status_code == 200
    record_id = created.json()["id"]
    assert client.put(f"/api/guidelines/banned-terms/{record_id}?role=Admin", json={"term": "hype"}).status_code == 200
    assert client.delete(f"/api/guidelines/banned-terms/{record_id}?role=Admin").status_code == 200


def test_pdf_export_returns_downloadable_pdf(client):
    result = check(client, "Classic T-shirt at ₹599. T&C apply.").json()
    draft_id = result["draft"]["id"]
    response = client.get(f"/api/drafts/{draft_id}/report.pdf")
    assert response.status_code == 200
    assert response.headers["content-type"] == "application/pdf"
    assert response.content.startswith(b"%PDF")


def test_empty_text_is_rejected_with_clear_validation(client):
    response = client.post("/api/check", json={"text": "  ", "channel": "Website", "product_id": 1, "role": "Creator"})
    assert response.status_code == 422


def test_demo_reset_restores_seed_records(client):
    response = client.post("/api/demo/reset")
    assert response.status_code == 200
    data = client.get("/api/guidelines").json()
    assert data["brand"]["name"] == "DemoWear"
    assert data["products"][0]["approved_price"] == 599


def test_full_demo_flow_apply_fix_recheck_submit_approve_export_dashboard(client):
    original = check(client, "Premium T-shirt — only ₹499! Best quality in India")
    assert original.status_code == 200
    draft = original.json()["draft"]
    revision = original.json()["revision"]
    assert sum(item["type"] == "price_mismatch" for item in revision["findings"]) == 1
    assert any(item["type"] == "missing_disclaimer" for item in revision["findings"])
    assert revision["health_score"] == 64
    assert revision["health_score_breakdown"]["counts"] == {"High": 0, "Medium": 3, "Low": 0}
    assert revision["health_score_breakdown"]["weights"] == {"High": 25, "Medium": 12, "Low": 5}

    fixed_text = "Premium T-shirt — only ₹599. T&C apply."
    edited = client.patch(f"/api/drafts/{draft['id']}", json={"text": fixed_text, "role": "Creator"})
    assert edited.status_code == 200
    stale_submit = client.post(f"/api/drafts/{draft['id']}/submit", json={"role": "Creator"})
    assert stale_submit.status_code == 409
    assert "Re-run" in stale_submit.json()["detail"]
    checked = client.post(f"/api/drafts/{draft['id']}/check", json={"text": fixed_text, "role": "Creator"})
    assert checked.status_code == 200
    assert checked.json()["revision"]["number"] == 2
    assert checked.json()["revision"]["findings"] == []
    assert checked.json()["revision"]["health_score"] == 100

    submitted = client.post(f"/api/drafts/{draft['id']}/submit", json={"role": "Creator"})
    assert submitted.json()["status"] == "in_review"
    approved = client.post(f"/api/drafts/{draft['id']}/decision", json={"action": "approve", "comment": "Approved after price and disclaimer check.", "role": "Reviewer"})
    assert approved.json()["status"] == "approved"
    exported = client.get(f"/api/drafts/{draft['id']}/report.pdf")
    assert exported.status_code == 200 and exported.content.startswith(b"%PDF")
    import fitz
    report_text = "\n".join(getattr(page, "get_text")() for page in fitz.open(stream=exported.content, filetype="pdf"))
    assert "Revision 1" in report_text and "Revision 2" in report_text
    assert "₹499" in report_text and "₹599" in report_text
    assert "Brand Health Score: 64/100" in report_text
    assert "Brand Health Score: 100/100" in report_text
    history = client.get(f"/api/drafts/{draft['id']}/history").json()
    assert [item["health_score"] for item in history["revisions"]] == [64, 100]
    dashboard = client.get("/api/dashboard").json()
    assert dashboard["approval_rate"] == 100
    assert dashboard["approved"] == 1
    assert dashboard["average_health_score"] == 100
    assert dashboard["draft_health"] == [{"draft_id": draft["id"], "label": f"Draft #{draft['id']}", "score": 100}]


def test_tone_checks_honor_custom_threshold_and_disabled_rules(client):
    rules = client.get("/api/guidelines").json()["tone_rules"]
    exclamation = next(item for item in rules if "exclamation" in item["name"].casefold())
    caps = next(item for item in rules if "caps" in item["name"].casefold())
    assert client.put(f"/api/guidelines/tone-rules/{exclamation['id']}?role=Admin", json={
        "name": exclamation["name"], "description": "Allow at most two exclamation marks.", "threshold": 2, "enabled": True,
    }).status_code == 200
    custom = check(client, "Big news!!!")
    finding = next(item for item in custom.json()["revision"]["findings"] if item["type"] == "excessive_exclamation")
    assert "no more than 2" in finding["explanation"]
    assert "max 2" in finding["evidence"][0]["label"]

    for rule in (exclamation, caps):
        updated = client.put(f"/api/guidelines/tone-rules/{rule['id']}?role=Admin", json={
            "name": rule["name"], "description": rule["description"], "threshold": rule["threshold"], "enabled": False,
        })
        assert updated.status_code == 200
    disabled = check(client, "BUY NOW!!!")
    types = {item["type"] for item in disabled.json()["revision"]["findings"]}
    assert "excessive_exclamation" not in types
    assert "all_caps_word" not in types


def test_ai_findings_need_a_known_guideline_and_exact_draft_span():
    from types import SimpleNamespace
    from backend.inkloom.services.ai import AIResult
    from backend.inkloom.services.checks import check_content
    from backend.inkloom.schemas import ContentObject

    product = SimpleNamespace(id=1, name="Classic T-shirt", approved_price=599, material="100% cotton")
    invalid_items = [
        {"type": "unsupported_claim", "span": "Best quality", "explanation": "Needs evidence.", "guideline_ref": "invented:99", "severity": "Medium", "suggestion": "Quality tee", "confidence": 0.8},
        {"type": "unsupported_claim", "span": "Made-up span", "explanation": "Needs evidence.", "guideline_ref": "product:1", "severity": "Medium", "suggestion": "Quality tee", "confidence": 0.8},
    ]
    result = check_content(ContentObject(text="A comfortable tee"), product, [], [], [], [], ai_runner=lambda _text, _snippets: AIResult(True, invalid_items))
    assert result["findings"] == []


def test_guidelines_cited_in_saved_history_cannot_be_deleted(client):
    result = check(client, "The cheapest Classic T-shirt at ₹599. T&C apply.").json()
    term = next(item for item in client.get("/api/guidelines").json()["banned_terms"] if item["term"] == "cheapest")
    deletion = client.delete(f"/api/guidelines/banned-terms/{term['id']}?role=Admin")
    assert deletion.status_code == 409
    assert "saved review history" in deletion.json()["detail"]
    product = client.get("/api/guidelines").json()["products"][0]
    product_delete = client.delete(f"/api/guidelines/products/{product['id']}?role=Admin")
    assert product_delete.status_code == 409


def test_route_manifest_is_json_and_not_spa_fallback(client):
    response = client.get("/manus-routes.json")
    assert response.status_code == 200
    assert response.headers["content-type"].startswith("application/json")
    paths = [route["path"] for route in response.json()["routes"]]
    assert paths == ["/", "/new", "/batch", "/report", "/review", "/dashboard", "/history", "/guidelines", "/evidence", "/evaluation", "/audit-log", "/status"]


def test_platform_proxy_key_is_not_reported_as_app_openai_configuration(monkeypatch):
    from backend.inkloom.services.ai import ai_is_configured

    monkeypatch.setenv("OPENAI_API_KEY", "platform-only-secret")
    monkeypatch.setenv("OPENAI_API_BASE", "https://platform-proxy.invalid/v1")
    monkeypatch.delenv("OPENAI_BASE_URL", raising=False)
    monkeypatch.delenv("ANTHROPIC_API_KEY", raising=False)
    assert ai_is_configured() is False


def test_invalid_ai_json_is_retried_once_then_validated(monkeypatch):
    from backend.inkloom.services import ai

    monkeypatch.setenv("OPENAI_API_KEY", "test-provider-key")
    monkeypatch.delenv("OPENAI_API_BASE", raising=False)
    monkeypatch.delenv("ANTHROPIC_API_KEY", raising=False)
    calls = []
    responses = iter(("not-json", '{"findings": []}'))

    def respond(_prompt, attempt, _client):
        calls.append(attempt)
        return next(responses)

    monkeypatch.setattr(ai, "_call_provider", respond)
    result = ai.analyze_draft("A draft", [{"ref": "product:1", "text": "approved product"}])
    assert result.available is True
    assert result.findings == []
    assert calls == [0, 1]


def test_ai_cache_reuses_response_and_daily_cap_falls_back(client, monkeypatch):
    from backend.inkloom.services import ai

    monkeypatch.setenv("OPENAI_API_KEY", "test-provider-key")
    monkeypatch.delenv("OPENAI_API_BASE", raising=False)
    monkeypatch.delenv("ANTHROPIC_API_KEY", raising=False)
    monkeypatch.setenv("AI_DAILY_CAP", "1")
    calls = []

    def respond(_prompt, attempt, _client):
        calls.append(attempt)
        return '{"findings": []}'

    monkeypatch.setattr(ai, "_call_provider", respond)
    first = check(client, "The best T-shirt for summer").json()["revision"]
    cached = check(client, "The best T-shirt for summer").json()["revision"]
    capped = check(client, "A different draft").json()["revision"]
    assert first["ai_available"] is True
    assert cached["ai_available"] is True
    assert calls == [0]
    assert capped["ai_available"] is False
    assert capped["ai_notice"] == ai.NOTICE


def test_check_rate_limit_is_per_ip_and_returns_retry_after(client):
    from fastapi import HTTPException
    from backend.inkloom.services.rate_limit import CHECKS_PER_MINUTE, enforce_check_rate_limit

    with client.app.state.SessionLocal() as session:
        for _ in range(CHECKS_PER_MINUTE):
            enforce_check_rate_limit(session, "198.51.100.7", now=120)
        with pytest.raises(HTTPException) as error:
            enforce_check_rate_limit(session, "198.51.100.7", now=120)
        assert error.value.status_code == 429
        assert int((error.value.headers or {}).get("Retry-After", "0")) > 0
        enforce_check_rate_limit(session, "198.51.100.8", now=120)


def test_pdf_upload_is_limited_to_two_megabytes(client):
    payload = b"%PDF-1.7" + b"x" * (2 * 1024 * 1024)
    response = client.post(
        "/api/check/pdf",
        data={"channel": "Instagram", "product_id": "1", "role": "Creator"},
        files={"file": ("large.pdf", payload, "application/pdf")},
    )
    assert response.status_code == 413
    assert response.json()["detail"] == "PDF is too large. Maximum upload size is 2 MB."


def test_static_brand_mark_is_served_as_svg(client):
    response = client.get("/inkloom-mark.svg")
    assert response.status_code == 200
    assert response.headers["content-type"].startswith("image/svg+xml")
    assert b"#1F5B4B" in response.content


def test_banned_term_update_rejects_case_insensitive_duplicate(client):
    terms = client.get("/api/guidelines").json()["banned_terms"]
    target = next(item for item in terms if item["term"] == "guaranteed")
    response = client.put(
        f"/api/guidelines/banned-terms/{target['id']}?role=Admin",
        json={"term": "CHEAPEST"},
    )
    assert response.status_code == 409
    assert response.json()["detail"] == "That term is already listed."
    current = client.get("/api/guidelines").json()["banned_terms"]
    assert next(item for item in current if item["id"] == target["id"])["term"] == "guaranteed"


def test_load_demo_data_preserves_saved_work_and_guideline_edits(client):
    checked = check(client, "A saved draft").json()
    term = next(item for item in client.get("/api/guidelines").json()["banned_terms"] if item["term"] == "cheapest")
    updated = client.put(f"/api/guidelines/banned-terms/{term['id']}?role=Admin", json={"term": "overclaim"})
    assert updated.status_code == 200

    loaded = client.post("/api/demo/load")
    assert loaded.status_code == 200
    assert loaded.json()["preserved_existing_work"] is True
    assert client.get("/api/drafts").json()[0]["id"] == checked["draft"]["id"]
    terms = client.get("/api/guidelines").json()["banned_terms"]
    assert any(item["term"] == "overclaim" for item in terms)


def test_demo_reset_is_admin_scoped_and_destructive_only_when_requested(client):
    check(client, "A saved draft")
    denied = client.post("/api/demo/reset?role=Creator")
    assert denied.status_code == 403
    assert len(client.get("/api/drafts").json()) == 1

    reset = client.post("/api/demo/reset?role=Admin")
    assert reset.status_code == 200
    assert client.get("/api/drafts").json() == []
    assert client.get("/api/guidelines").json()["brand"]["name"] == "DemoWear"


def test_pdf_extraction_rejects_text_over_draft_limit(monkeypatch):
    from backend.inkloom.services import pdf

    class FakePage:
        def get_text(self, _kind):
            return "x" * 25_001

    class FakeDocument:
        page_count = 1

        def __iter__(self):
            return iter([FakePage()])

    monkeypatch.setattr(pdf.fitz, "open", lambda **_kwargs: FakeDocument())
    with pytest.raises(ValueError, match="25,000 character limit"):
        pdf.extract_pdf_text(b"%PDF-1.7")



def test_price_formats_cover_from_rs_inr_rupee_and_decimals():
    from backend.inkloom.services.rules import extract_prices

    cases = {
        "From Rs. 1,299.50": 1299.50,
        "at INR 599.00": 599.00,
        "just ₹1,299": 1299.00,
        "from 1,299.50": 1299.50,
    }
    for text, expected in cases.items():
        prices = extract_prices(text)
        assert len(prices) == 1
        assert prices[0]["amount"] == expected


def test_preferred_terminology_is_crud_admin_only_and_evidence_linked(client):
    denied = client.post("/api/guidelines/preferred-terms?role=Creator", json={"term": "cheap", "preferred": "affordable"})
    assert denied.status_code == 403
    created = client.post("/api/guidelines/preferred-terms?role=Admin", json={"term": "premium", "preferred": "considered"})
    assert created.status_code == 200
    record_id = created.json()["id"]
    duplicate = client.post("/api/guidelines/preferred-terms?role=Admin", json={"term": "PREMIUM", "preferred": "refined"})
    assert duplicate.status_code == 409
    assert client.put(f"/api/guidelines/preferred-terms/{record_id}?role=Admin", json={"term": "premium", "preferred": "thoughtful"}).status_code == 200
    assert client.delete(f"/api/guidelines/preferred-terms/{record_id}?role=Admin").status_code == 200

    default = next(item for item in client.get("/api/guidelines").json()["preferred_terms"] if item["term"] == "cheap")
    result = check(client, "This cheap tee is comfortable.").json()["revision"]["findings"]
    finding = next(item for item in result if item["type"] == "preferred_terminology")
    assert finding["span"] == "cheap"
    assert finding["guideline_ref"] == default["guideline_ref"]
    assert finding["evidence"][0]["href"] == f"guideline:preferred_term:{default['id']}"
    assert finding["replacement"] == "affordable"


def test_preferred_terms_use_whole_phrase_boundaries(client):
    findings = check(client, "This cheaper option is not the cheap one.").json()["revision"]["findings"]
    preferred = [item for item in findings if item["type"] == "preferred_terminology"]
    assert [item["span"] for item in preferred] == ["cheap"]


def test_superlatives_are_flagged_as_needs_evidence_not_false(client):
    findings = check(client, "Best quality in India. #1 choice. Top-rated comfort.").json()["revision"]["findings"]
    superlatives = [item for item in findings if item["type"] == "unsupported_claim"]
    assert len(superlatives) == 3
    assert all(item["source"] == "Rule" and item["severity"] == "Medium" for item in superlatives)
    assert all("needs approved evidence" in item["explanation"] and "not being declared false" in item["explanation"] for item in superlatives)


def test_ai_context_contains_only_relevant_guideline_snippets(client, monkeypatch):
    from backend.inkloom.services import ai

    monkeypatch.setenv("OPENAI_API_KEY", "test-provider-key")
    monkeypatch.delenv("OPENAI_API_BASE", raising=False)
    monkeypatch.delenv("ANTHROPIC_API_KEY", raising=False)
    prompts = []

    def respond(prompt, _attempt, _client):
        prompts.append(prompt)
        return '{"findings": []}'

    monkeypatch.setattr(ai, "_call_provider", respond)
    first = check(client, "Best quality in India.").json()["revision"]
    assert first["ai_available"] is True
    prompt = prompts[-1]
    assert '"ref": "product:1"' in prompt
    assert "Clear: Use clear, easy-to-understand language." in prompt
    assert "Unapproved term:" not in prompt
    assert "Approved claim:" not in prompt
    assert "Required disclaimer:" not in prompt
    assert "Preferred wording:" not in prompt

    check(client, "Only ₹499 today.")
    assert "Required disclaimer: T&C apply" in prompts[-1]



def test_approved_superlative_claim_passes_and_shows_evidence(client):
    added = client.post("/api/guidelines/approved-claims?role=Admin", json={"claim": "Best quality in India", "evidence": "Quality review #QR-17"})
    assert added.status_code == 200
    revision = check(client, "Best quality in India").json()["revision"]
    assert revision["findings"] == []
    assert revision["verified_claims"][0]["evidence"] == "Quality review #QR-17"



def test_legacy_sqlite_draft_migration_is_additive_and_preserves_rows(tmp_path):
    from backend.inkloom.db import init_database

    engine = make_engine(f"sqlite:///{tmp_path / 'legacy-inkloom.db'}")
    with engine.begin() as connection:
        connection.exec_driver_sql("CREATE TABLE products (id INTEGER NOT NULL PRIMARY KEY, name VARCHAR(160) NOT NULL, approved_price FLOAT NOT NULL, material VARCHAR(240) NOT NULL)")
        connection.exec_driver_sql("CREATE TABLE drafts (id INTEGER NOT NULL PRIMARY KEY, text TEXT NOT NULL, channel VARCHAR(40) NOT NULL, product_id INTEGER NOT NULL, status VARCHAR(40) NOT NULL, created_at DATETIME NOT NULL, updated_at DATETIME NOT NULL, FOREIGN KEY(product_id) REFERENCES products(id))")
        connection.exec_driver_sql("CREATE TABLE revisions (id INTEGER NOT NULL PRIMARY KEY, draft_id INTEGER NOT NULL, number INTEGER NOT NULL, text TEXT NOT NULL, findings_json TEXT NOT NULL, verified_claims_json TEXT NOT NULL, ai_available BOOLEAN NOT NULL, ai_notice VARCHAR(240), actor_role VARCHAR(30) NOT NULL, created_at DATETIME NOT NULL, FOREIGN KEY(draft_id) REFERENCES drafts(id))")
        connection.exec_driver_sql("INSERT INTO products (id, name, approved_price, material) VALUES (1, 'Legacy tee', 599, 'cotton')")
        connection.exec_driver_sql("INSERT INTO drafts (id, text, channel, product_id, status, created_at, updated_at) VALUES (1, 'Keep this review', 'Instagram', 1, 'draft', '2024-01-01', '2024-01-01')")
        connection.exec_driver_sql("INSERT INTO revisions (id, draft_id, number, text, findings_json, verified_claims_json, ai_available, ai_notice, actor_role, created_at) VALUES (1, 1, 1, 'Keep this review', '[]', '[]', 0, NULL, 'Creator', '2024-01-01')")

    init_database(engine)
    with engine.connect() as connection:
        row = connection.exec_driver_sql("SELECT id, text, assets_json, creator_id FROM drafts WHERE id = 1").one()
        assert row[1] == "Keep this review"
        assert row[2] == "[]"
        assert row[3] == "legacy-browser"
        revision = connection.exec_driver_sql("SELECT id, text, guideline_version FROM revisions WHERE id = 1").one()
        assert revision[1] == "Keep this review" and revision[2] == 1
        tables = {row[0] for row in connection.exec_driver_sql("SELECT name FROM sqlite_master WHERE type='table'")}
        assert {"finding_reviews", "draft_comments", "reviewer_feedback_examples"} <= tables
    engine.dispose()


def test_reserved_draft_assets_metadata_round_trips(client):
    response = client.post("/api/drafts", json={
        "text": "Future-compatible draft", "channel": "Website", "product_id": 1,
        "role": "Creator", "assets": ["future-asset-reference"],
    })
    assert response.status_code == 200
    assert response.json()["assets"] == ["future-asset-reference"]



def test_brand_health_score_is_transparent_and_floored():
    from backend.inkloom.services.health_score import calculate_health_score

    score = calculate_health_score([
        {"severity": "High"}, {"severity": "High"},
        {"severity": "Medium"}, {"severity": "Low"},
    ])
    assert score["score"] == 33
    assert score["counts"] == {"High": 2, "Medium": 1, "Low": 1}
    assert score["deductions"] == {"High": 50, "Medium": 12, "Low": 5}
    assert "25" in score["formula"] and "12" in score["formula"] and "5" in score["formula"]
    assert calculate_health_score([])["score"] == 100
    assert calculate_health_score([{"severity": "High"}] * 10)["score"] == 0



def test_revision_compare_reports_text_and_findings_in_both_directions(client):
    first = check(client, "Premium T-shirt — only ₹499! Best quality in India")
    assert first.status_code == 200
    draft_id = first.json()["draft"]["id"]
    fixed_text = "Premium T-shirt — only ₹599. T&C apply."
    edited = client.patch(f"/api/drafts/{draft_id}", json={"text": fixed_text, "role": "Creator"})
    assert edited.status_code == 200
    checked = client.post(f"/api/drafts/{draft_id}/check", json={"text": fixed_text, "role": "Creator"})
    assert checked.status_code == 200

    forward = client.get(f"/api/drafts/{draft_id}/compare?left_revision=1&right_revision=2")
    assert forward.status_code == 200
    forward_result = forward.json()
    assert forward_result["left_revision"]["number"] == 1
    assert forward_result["right_revision"]["number"] == 2
    assert {line["kind"] for line in forward_result["lines"]} >= {"removed", "added"}
    resolved_types = {item["type"] for item in forward_result["resolved_findings"]}
    assert {"price_mismatch", "missing_disclaimer"} <= resolved_types
    assert forward_result["new_findings"] == []

    reverse = client.get(f"/api/drafts/{draft_id}/compare?left_revision=2&right_revision=1")
    assert reverse.status_code == 200
    assert reverse.json()["resolved_findings"] == []
    assert {item["type"] for item in reverse.json()["new_findings"]} >= {"price_mismatch", "missing_disclaimer"}
    assert client.get(f"/api/drafts/{draft_id}/compare?left_revision=1&right_revision=1").status_code == 422
    assert client.get(f"/api/drafts/{draft_id}/compare?left_revision=1&right_revision=99").status_code == 404
    assert client.get("/api/drafts/999999/compare?left_revision=1&right_revision=2").status_code == 404



def test_batch_check_json_persists_each_draft_and_returns_summary(client):
    product_id = client.get("/api/guidelines").json()["products"][0]["id"]
    response = client.post("/api/batch-check", json={
        "texts": ["Premium T-shirt — only ₹499! Best quality in India", "Made with 100% cotton. T&C apply."],
        "channel": "Instagram", "product_id": product_id, "role": "Creator",
    })
    assert response.status_code == 200
    body = response.json()
    assert body["count"] == 2 and len(body["items"]) == 2
    assert body["items"][0]["draft"]["status"] == "draft"
    assert body["items"][0]["revision"]["health_score"] < 100
    assert body["items"][0]["top_issue"] == "price_mismatch"
    assert body["items"][1]["revision"]["findings"] == []
    assert body["items"][1]["revision"]["health_score"] == 100
    assert body["items"][1]["top_issue"] is None
    assert len(client.get("/api/drafts").json()) == 2


def test_batch_check_csv_accepts_text_header_and_quoted_multiline_cells(client):
    csv_body = ('text,title\r\n"Launch line one,\r\ncontinue with ""quoted"" text","caption"\r\n'
                '"Made with 100% cotton. T&C apply.","clean"\r\n').encode("utf-8")
    response = client.post("/api/batch-check/csv", files={"file": ("drafts.csv", csv_body, "text/csv")},
                           data={"channel": "LinkedIn", "product_id": "1", "role": "Creator"})
    assert response.status_code == 200
    body = response.json()
    assert body["count"] == 2
    assert body["items"][0]["draft"]["channel"] == "LinkedIn"
    assert "continue with \"quoted\" text" in body["items"][0]["draft"]["text"]
    assert body["items"][1]["revision"]["health_score"] == 100


def test_batch_check_csv_rejects_missing_text_header_oversize_and_over_12_rows(client):
    missing_header = client.post("/api/batch-check/csv", files={"file": ("drafts.csv", b"caption\nhello\n", "text/csv")},
                                 data={"channel": "Instagram", "product_id": "1", "role": "Creator"})
    assert missing_header.status_code == 422 and "text" in missing_header.json()["detail"]

    too_many = ("text\n" + "hello\n" * 13).encode("utf-8")
    row_limit = client.post("/api/batch-check/csv", files={"file": ("drafts.csv", too_many, "text/csv")},
                            data={"channel": "Instagram", "product_id": "1", "role": "Creator"})
    assert row_limit.status_code == 422 and "12" in row_limit.json()["detail"]

    oversized = client.post("/api/batch-check/csv", files={"file": ("drafts.csv", b"text\n" + b"a" * (2 * 1024 * 1024), "text/csv")},
                            data={"channel": "Instagram", "product_id": "1", "role": "Creator"})
    assert oversized.status_code == 413
    assert client.get("/api/drafts").json() == []


def test_batch_check_rate_limit_reserves_all_items_atomically(client, monkeypatch):
    from backend.inkloom.services import rate_limit

    monkeypatch.setattr(rate_limit, "CHECKS_PER_MINUTE", 3)
    payload = {"texts": ["Good copy one", "Good copy two"], "channel": "Instagram", "product_id": 1, "role": "Creator"}
    first = client.post("/api/batch-check", json=payload)
    assert first.status_code == 200
    second = client.post("/api/batch-check", json=payload)
    assert second.status_code == 429
    assert len(client.get("/api/drafts").json()) == 2


from typing import Any, cast



def test_reviewer_labels_and_dismissals_are_revision_scoped_and_do_not_change_checks(client):
    checked = client.post("/api/check", json={
        "text": "Premium T-shirt — only ₹499! Best quality in India", "channel": "Instagram",
        "product_id": 1, "role": "Creator",
    })
    assert checked.status_code == 200
    draft_id = checked.json()["draft"]["id"]
    original = checked.json()["revision"]
    finding_index = next(i for i, item in enumerate(original["findings"]) if item["type"] == "price_mismatch")
    original_signature = [(item["type"], item["span"], item["severity"]) for item in original["findings"]]

    label_response = client.put(
        f"/api/drafts/{draft_id}/revisions/1/findings/{finding_index}/label",
        json={"role": "Reviewer", "reviewer_label": "false_positive"},
    )
    assert label_response.status_code == 200
    labeled_finding = label_response.json()["findings"][finding_index]
    assert labeled_finding["reviewer_label"] == "false_positive"
    assert label_response.json()["health_score"] == original["health_score"]

    denied = client.put(
        f"/api/drafts/{draft_id}/revisions/1/findings/{finding_index}/label",
        json={"role": "Creator", "reviewer_label": "valid"},
    )
    assert denied.status_code == 422

    reason = "Reviewer checked the approved price card before dismissing this report."
    dismissed = client.post(
        f"/api/drafts/{draft_id}/revisions/1/findings/{finding_index}/dismiss",
        json={"role": "Reviewer", "reason": reason},
    )
    assert dismissed.status_code == 200
    dismissed_finding = dismissed.json()["findings"][finding_index]
    assert dismissed_finding["dismissal_reason"] == reason
    assert dismissed_finding["dismissed_by_role"] == "Reviewer"
    assert dismissed.json()["health_score"] == original["health_score"]

    history = client.get(f"/api/drafts/{draft_id}/history").json()
    revision_one = history["revisions"][0]
    assert revision_one["findings"][finding_index]["dismissal_reason"] == reason
    assert revision_one["findings"][finding_index]["reviewer_label"] == "false_positive"
    assert any(reason in event["comment"] for event in history["events"])

    report = client.get(f"/api/drafts/{draft_id}/report.pdf")
    assert report.status_code == 200
    import fitz
    pdf = fitz.open(stream=report.content, filetype="pdf")
    pdf_text = "\n".join(cast(Any, page).get_text() for page in pdf)
    assert reason in pdf_text and "false_positive" in pdf_text

    rerun = client.post(f"/api/drafts/{draft_id}/check", json={
        "text": "Premium T-shirt — only ₹499! Best quality in India", "role": "Creator",
    })
    assert rerun.status_code == 200
    assert [(item["type"], item["span"], item["severity"]) for item in rerun.json()["revision"]["findings"]] == original_signature
    assert all(item["reviewer_label"] is None and item["dismissal_reason"] is None for item in rerun.json()["revision"]["findings"])


def test_draft_comment_thread_is_persisted_and_included_in_history_and_pdf(client):
    checked = client.post("/api/check", json={
        "text": "Made with 100% cotton. T&C apply.", "channel": "Instagram",
        "product_id": 1, "role": "Creator",
    })
    draft_id = checked.json()["draft"]["id"]
    creator_message = "Please confirm the product image matches this claim."
    reviewer_message = "Checked the evidence file; the copy is acceptable."
    first = client.post(f"/api/drafts/{draft_id}/comments", json={"role": "Creator", "message": creator_message})
    second = client.post(f"/api/drafts/{draft_id}/comments", json={"role": "Reviewer", "message": reviewer_message})
    assert first.status_code == 200 and second.status_code == 200
    comments = client.get(f"/api/drafts/{draft_id}/comments").json()
    assert [comment["message"] for comment in comments] == [creator_message, reviewer_message]
    assert [comment["actor_role"] for comment in comments] == ["Creator", "Reviewer"]
    events = client.get(f"/api/drafts/{draft_id}/history").json()["events"]
    assert sum(event["event_type"] == "comment_added" for event in events) == 2
    import fitz
    pdf = fitz.open(stream=client.get(f"/api/drafts/{draft_id}/report.pdf").content, filetype="pdf")
    pdf_text = " ".join(" ".join(cast(Any, page).get_text().split()) for page in pdf)
    assert creator_message in pdf_text and reviewer_message in pdf_text



def test_all_guideline_mutations_increment_the_shared_version(client):
    version = client.get("/api/guidelines").json()["version"]

    def check_mutation(response):
        nonlocal version
        assert response.status_code == 200, response.text
        version += 1
        assert client.get("/api/guidelines").json()["version"] == version
        return response.json()

    product = check_mutation(client.post("/api/guidelines/products?role=Admin", json={"name": "Version test", "approved_price": 120, "material": "linen"}))
    check_mutation(client.put(f"/api/guidelines/products/{product['id']}?role=Admin", json={"name": "Version test updated", "approved_price": 125, "material": "linen"}))
    check_mutation(client.delete(f"/api/guidelines/products/{product['id']}?role=Admin"))

    term = check_mutation(client.post("/api/guidelines/banned-terms?role=Admin", json={"term": "version-term"}))
    check_mutation(client.put(f"/api/guidelines/banned-terms/{term['id']}?role=Admin", json={"term": "version-term-edited"}))
    check_mutation(client.delete(f"/api/guidelines/banned-terms/{term['id']}?role=Admin"))

    preferred = check_mutation(client.post("/api/guidelines/preferred-terms?role=Admin", json={"term": "version-word", "preferred": "version phrase"}))
    check_mutation(client.put(f"/api/guidelines/preferred-terms/{preferred['id']}?role=Admin", json={"term": "version-word", "preferred": "updated phrase"}))
    check_mutation(client.delete(f"/api/guidelines/preferred-terms/{preferred['id']}?role=Admin"))

    claim = check_mutation(client.post("/api/guidelines/approved-claims?role=Admin", json={"claim": "Version test claim", "evidence": "Version test record"}))
    check_mutation(client.put(f"/api/guidelines/approved-claims/{claim['id']}?role=Admin", json={"claim": "Updated version test claim", "evidence": "Updated version test record"}))
    check_mutation(client.delete(f"/api/guidelines/approved-claims/{claim['id']}?role=Admin"))

    tone = check_mutation(client.post("/api/guidelines/tone-rules?role=Admin", json={"name": "Version tone", "description": "Test rule", "threshold": None, "enabled": True}))
    check_mutation(client.put(f"/api/guidelines/tone-rules/{tone['id']}?role=Admin", json={"name": "Version tone updated", "description": "Updated test rule", "threshold": 2, "enabled": True}))
    check_mutation(client.delete(f"/api/guidelines/tone-rules/{tone['id']}?role=Admin"))

    disclaimer = check_mutation(client.post("/api/guidelines/disclaimers?role=Admin", json={"phrase": "Version terms apply", "applies_to": "version test"}))
    check_mutation(client.put(f"/api/guidelines/disclaimers/{disclaimer['id']}?role=Admin", json={"phrase": "Updated version terms apply", "applies_to": "version test"}))
    check_mutation(client.delete(f"/api/guidelines/disclaimers/{disclaimer['id']}?role=Admin"))

    check_mutation(client.put("/api/guidelines/logo?role=Admin", json={"version": "v-test", "approved": True}))
    check_mutation(client.delete("/api/guidelines/logo?role=Admin"))
    assert version == 21


def test_revision_snapshots_detect_stale_guidelines_and_require_recheck_before_submit(client):
    checked = check(client, "Made with 100% cotton. T&C apply.")
    assert checked.status_code == 200
    draft_id = checked.json()["draft"]["id"]
    assert checked.json()["revision"]["guideline_version"] == 1

    changed = client.post("/api/guidelines/banned-terms?role=Admin", json={"term": "newly-banned"})
    assert changed.status_code == 200
    stale = client.post(f"/api/drafts/{draft_id}/submit", json={"role": "Creator"})
    assert stale.status_code == 409
    assert stale.json()["detail"] == "Guidelines changed since this check. Re-run?"

    rerun = client.post(f"/api/drafts/{draft_id}/check", json={"text": "Made with 100% cotton. T&C apply.", "role": "Creator"})
    assert rerun.status_code == 200
    assert rerun.json()["revision"]["number"] == 2
    assert rerun.json()["revision"]["guideline_version"] == 2
    history = client.get(f"/api/drafts/{draft_id}/history").json()
    assert [item["guideline_version"] for item in history["revisions"]] == [1, 2]
    assert client.post(f"/api/drafts/{draft_id}/submit", json={"role": "Creator"}).status_code == 200

    reset = client.post("/api/demo/reset?role=Admin")
    assert reset.status_code == 200
    assert client.get("/api/guidelines").json()["version"] == 3



def test_reviewer_feedback_changes_future_severity_and_dashboard_analytics(client):
    labels = ["false_positive", "valid", "false_positive"]
    for label in labels:
        checked = client.post("/api/check", json={
            "text": "The cheapest T-shirt", "channel": "Instagram", "product_id": 1,
            "role": "Creator", "creator_id": "creator-browser-123456",
        })
        assert checked.status_code == 200
        body = checked.json()
        index = next(i for i, finding in enumerate(body["revision"]["findings"]) if finding["type"] == "banned_term")
        response = client.put(
            f"/api/drafts/{body['draft']['id']}/revisions/1/findings/{index}/label",
            json={"role": "Reviewer", "reviewer_label": label},
        )
        assert response.status_code == 200

    future = client.post("/api/check", json={
        "text": "The cheapest T-shirt", "channel": "Instagram", "product_id": 1,
        "role": "Creator", "creator_id": "creator-browser-123456",
    })
    assert future.status_code == 200
    banned = next(item for item in future.json()["revision"]["findings"] if item["type"] == "banned_term")
    assert banned["severity_before_feedback"] == "High"
    assert banned["severity"] == "Medium"
    assert banned["severity_note"] == "Downgraded by reviewer feedback"

    dashboard = client.get("/api/dashboard").json()
    banned_rate = next(item for item in dashboard["false_positive_by_rule"] if item["rule"] == "banned_term")
    assert banned_rate["labelled_findings"] == 3
    assert banned_rate["false_positives"] == 2
    assert banned_rate["false_positive_rate"] == pytest.approx(2 / 3)
    assert banned_rate["downgrade_active"] is True
    creator_row = next(item for item in dashboard["recurring_by_creator"] if item["creator_id"] == "creator-browser-123456" and item["rule"] == "banned_term")
    assert creator_row["count"] == 4
    assert creator_row["demo_example"] is False
    assert any(item["rule"] == "price_mismatch" for item in dashboard["recurring_by_rule"])


def test_reviewer_feedback_threshold_and_lowest_level_downgrade():
    from backend.inkloom.services.reviewer_feedback import apply_feedback_downgrades

    findings = [
        {"type": "enough_false_positives", "severity": "Low"},
        {"type": "only_two_labels", "severity": "High"},
        {"type": "exactly_half", "severity": "High"},
    ]
    apply_feedback_downgrades(findings, {
        "enough_false_positives": {"labelled_findings": 3, "false_positives": 2, "false_positive_rate": 2 / 3},
        "only_two_labels": {"labelled_findings": 2, "false_positives": 2, "false_positive_rate": 1.0},
        "exactly_half": {"labelled_findings": 4, "false_positives": 2, "false_positive_rate": 0.5},
    })
    assert findings[0]["severity"] == "Info"
    assert findings[0]["severity_note"] == "Downgraded by reviewer feedback"
    assert findings[1]["severity"] == "High"
    assert findings[2]["severity"] == "High"


def test_seeded_evidence_library_and_no_match_message(client):
    guidelines = client.get("/api/guidelines").json()
    assert any(item["title"] == "Cotton Certificate CC-2026-14" for item in guidelines["evidence_documents"])
    report = check(client, "Best quality in India")
    assert report.status_code == 200
    finding = next(item for item in report.json()["revision"]["findings"] if item["type"] == "unsupported_claim")
    assert finding["evidence"][0]["label"] == "No evidence found"
    assert "Searched" in finding["evidence"][0]["detail"]


def test_admin_text_evidence_supports_claim_and_keeps_referenced_document(client):
    before_version = client.get("/api/guidelines").json()["version"]
    denied = client.post(
        "/api/guidelines/evidence-documents",
        data={"title": "Unauthorized", "role": "Creator"},
        files={"file": ("proof.txt", b"Best quality in India.", "text/plain")},
    )
    assert denied.status_code == 403

    uploaded = client.post(
        "/api/guidelines/evidence-documents",
        data={"title": "Quality review QR-17", "role": "Admin"},
        files={"file": ("quality.txt", b"Best quality in India was verified in the independent quality review.", "text/plain")},
    )
    assert uploaded.status_code == 200, uploaded.text
    document = uploaded.json()
    assert document["title"] == "Quality review QR-17"
    assert document["source_filename"] == "quality.txt"
    assert client.get("/api/guidelines").json()["version"] == before_version + 1

    checked = check(client, "Best quality in India")
    assert checked.status_code == 200
    revision = checked.json()["revision"]
    assert not any(item["type"] == "unsupported_claim" for item in revision["findings"])
    support = next(item for item in revision["verified_claims"] if item.get("document_title") == "Quality review QR-17")
    assert support["claim"] == "Best quality in India"
    assert "independent quality review" in support["evidence"]
    assert support["source"] == "Evidence library"
    removed = client.delete(f"/api/guidelines/evidence-documents/{document['id']}?role=Admin")
    assert removed.status_code == 409


def test_evidence_pdf_extraction_and_bad_uploads_are_friendly(client):
    import fitz

    pdf = fitz.open()
    page = pdf.new_page()
    page.insert_text((72, 72), "Best quality in India is supported by test report QR-17.")
    pdf_bytes = pdf.tobytes()
    pdf.close()
    valid = client.post(
        "/api/guidelines/evidence-documents",
        data={"title": "PDF quality report", "role": "Admin"},
        files={"file": ("quality.pdf", pdf_bytes, "application/pdf")},
    )
    assert valid.status_code == 200, valid.text
    check_response = check(client, "Best quality in India")
    assert not any(item["type"] == "unsupported_claim" for item in check_response.json()["revision"]["findings"])
    assert any(item.get("document_title") == "PDF quality report" for item in check_response.json()["revision"]["verified_claims"])

    wrong_type = client.post(
        "/api/guidelines/evidence-documents", data={"title": "Bad type", "role": "Admin"},
        files={"file": ("image.exe", b"not a document", "application/octet-stream")},
    )
    assert wrong_type.status_code == 415
    malformed_pdf = client.post(
        "/api/guidelines/evidence-documents", data={"title": "Bad PDF", "role": "Admin"},
        files={"file": ("broken.pdf", b"not a pdf", "application/pdf")},
    )
    assert malformed_pdf.status_code == 415
    empty = client.post(
        "/api/guidelines/evidence-documents", data={"title": "Empty", "role": "Admin"},
        files={"file": ("empty.txt", b"  \n", "text/plain")},
    )
    assert empty.status_code == 422
    oversized = client.post(
        "/api/guidelines/evidence-documents", data={"title": "Large", "role": "Admin"},
        files={"file": ("large.txt", b"a" * (2 * 1024 * 1024 + 1), "text/plain")},
    )
    assert oversized.status_code == 413



def _visual_fixture_images():
    import io
    from PIL import Image, ImageDraw, ImageFont

    font = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", 64)
    logo = Image.new("RGBA", (180, 80), (255, 255, 255, 0))
    draw = ImageDraw.Draw(logo)
    draw.rounded_rectangle((8, 8, 172, 72), radius=14, fill=(20, 80, 50, 255))
    draw.ellipse((24, 22, 54, 52), fill=(250, 220, 40, 255))
    for y, end in ((22, 150), (42, 135), (60, 145)):
        draw.line((70, y, end, y), fill="white", width=8)

    creative = Image.new("RGB", (1400, 900), "white")
    ImageDraw.Draw(creative).text((55, 150), "Classic Tee only Rs 499", font=font, fill="black")
    creative.paste(logo, (1160, 50), logo)
    output = io.BytesIO()
    creative.save(output, format="PNG")
    logo_output = io.BytesIO()
    logo.save(logo_output, format="PNG")
    blank = Image.new("RGB", (1400, 900), "white")
    blank_output = io.BytesIO()
    blank.save(blank_output, format="PNG")
    return output.getvalue(), logo_output.getvalue(), blank_output.getvalue()


def test_visual_ad_check_runs_ocr_rules_and_logo_match_and_survives_refresh(client):
    creative_bytes, logo_bytes, _ = _visual_fixture_images()
    before_version = client.get("/api/guidelines").json()["version"]
    uploaded_logo = client.post(
        "/api/guidelines/approved-logo-image",
        data={"role": "Admin"},
        files={"file": ("approved-mark.png", logo_bytes, "image/png")},
    )
    assert uploaded_logo.status_code == 200, uploaded_logo.text
    guidelines = client.get("/api/guidelines").json()
    assert guidelines["version"] == before_version + 1
    assert guidelines["approved_logo_image"]["source_filename"] == "approved-mark.png"

    response = client.post(
        "/api/creative-check",
        data={"channel": "Ad", "product_id": "1", "role": "Creator", "creator_id": "creative-browser-123"},
        files={"file": ("sale-ad.png", creative_bytes, "image/png")},
    )
    assert response.status_code == 200, response.text
    body = response.json()
    draft = body["draft"]
    assert draft["channel"] == "Ad"
    assert draft["creator_id"] == "creative-browser-123"
    assert draft["text"] and "499" in draft["text"]
    assert "detected by OpenCV" in draft["creative"]["logo_notice"]
    assert draft["creative"]["ocr_notice"] is None
    findings = body["revision"]["findings"]
    assert any(item["type"] == "price_mismatch" for item in findings)
    assert not any(item["type"] == "approved_logo_not_detected" for item in findings)

    image = client.get(f"/api/drafts/{draft['id']}/creative")
    assert image.status_code == 200
    assert image.headers["content-type"].startswith("image/png")
    assert image.headers["x-content-type-options"] == "nosniff"
    assert image.content == creative_bytes
    refreshed = next(item for item in client.get("/api/drafts").json() if item["id"] == draft["id"])
    assert refreshed["creative"]["source_filename"] == "sale-ad.png"


def test_missing_approved_logo_produces_medium_visual_finding_with_confidence(client):
    _, logo_bytes, blank_bytes = _visual_fixture_images()
    logo = client.post(
        "/api/guidelines/approved-logo-image", data={"role": "Admin"},
        files={"file": ("approved-mark.png", logo_bytes, "image/png")},
    )
    assert logo.status_code == 200, logo.text
    response = client.post(
        "/api/creative-check",
        data={"channel": "Ad", "product_id": "1", "role": "Creator", "creator_id": "blank-ad-browser"},
        files={"file": ("blank-ad.png", blank_bytes, "image/png")},
    )
    assert response.status_code == 200, response.text
    body = response.json()
    finding = next(item for item in body["revision"]["findings"] if item["type"] == "approved_logo_not_detected")
    assert finding["severity"] == "Medium"
    assert finding["source"] == "Visual"
    assert finding["span"] == ""
    assert finding["confidence_label"] in {"Low", "Moderate"}
    assert finding["uncertainty"].startswith("Confidence label:")
    assert "Approved logo not detected" in body["draft"]["creative"]["logo_notice"]
    assert body["draft"]["creative"]["ocr_notice"] is not None


def test_visual_bad_files_and_ocr_unavailable_are_friendly(client, monkeypatch):
    import pytesseract

    _, _, blank_bytes = _visual_fixture_images()
    denied_logo = client.post(
        "/api/guidelines/approved-logo-image", data={"role": "Reviewer"},
        files={"file": ("approved.png", blank_bytes, "image/png")},
    )
    assert denied_logo.status_code == 403

    wrong_extension = client.post(
        "/api/creative-check", data={"channel": "Ad", "product_id": "1", "role": "Creator"},
        files={"file": ("creative.gif", blank_bytes, "image/png")},
    )
    assert wrong_extension.status_code == 415
    wrong_contents = client.post(
        "/api/creative-check", data={"channel": "Ad", "product_id": "1", "role": "Creator"},
        files={"file": ("creative.png", b"not a real PNG", "image/png")},
    )
    assert wrong_contents.status_code == 415
    too_large = client.post(
        "/api/creative-check", data={"channel": "Ad", "product_id": "1", "role": "Creator"},
        files={"file": ("large.png", b"x" * (5 * 1024 * 1024 + 1), "image/png")},
    )
    assert too_large.status_code == 413

    monkeypatch.setattr(pytesseract.pytesseract, "tesseract_cmd", "/missing/inkloom-tesseract")
    fallback = client.post(
        "/api/creative-check", data={"channel": "Ad", "product_id": "1", "role": "Creator"},
        files={"file": ("ocr-unavailable.png", blank_bytes, "image/png")},
    )
    assert fallback.status_code == 200, fallback.text
    body = fallback.json()
    assert "OCR unavailable" in body["draft"]["creative"]["ocr_notice"]
    assert body["revision"]["findings"] == []
    assert body["revision"]["ai_notice"] == "AI analysis skipped because OCR found no readable text."
    assert "not uploaded" in body["draft"]["creative"]["logo_notice"]



def test_evaluation_dataset_is_versioned_and_contains_thirty_labeled_cases(client):
    from backend.inkloom.services.evaluation import load_evaluation_dataset

    dataset = load_evaluation_dataset()
    assert dataset["dataset_id"] == "inkloom-demo-v1"
    assert len(dataset["cases"]) == 30
    assert all(case["id"] and isinstance(case["expected_types"], list) for case in dataset["cases"])

    response = client.get("/api/evaluation")
    assert response.status_code == 200
    assert response.json()["case_count"] == 30
    assert len(response.json()["cases"]) == 30


def test_evaluation_metrics_count_true_false_positives_and_false_negatives():
    from backend.inkloom.services.evaluation import score_predictions

    cases = [
        {"id": "one", "expected_types": ["price_mismatch"]},
        {"id": "two", "expected_types": ["banned_term"]},
        {"id": "three", "expected_types": []},
    ]
    metrics = score_predictions(cases, {
        "one": ["price_mismatch", "missing_disclaimer"],
        "two": [],
        "three": ["tone_mismatch"],
    })
    assert metrics == {
        "cases": 3,
        "expected_findings": 2,
        "predicted_findings": 3,
        "true_positives": 1,
        "false_positive_count": 2,
        "false_negatives": 1,
        "precision": pytest.approx(1 / 3, abs=0.001),
        "recall": 0.5,
    }


def test_evaluation_runs_rules_and_truthfully_reports_rules_only_fallback(client):
    denied = client.post("/api/evaluation/run?role=Creator")
    assert denied.status_code == 403

    response = client.post("/api/evaluation/run?role=Admin")
    assert response.status_code == 200, response.text
    body = response.json()
    assert body["case_count"] == 30
    assert body["ai_configured"] is False
    assert body["ai_available"] is False
    assert body["ai_notice"] == "AI analysis unavailable. Showing rule-based checks only."
    assert body["combined_uses_rules_only_fallback"] is True
    assert body["metrics"]["ai_only"] is None
    assert body["metrics"]["combined"] == body["metrics"]["rules_only"]
    assert body["metrics"]["rules_only"]["cases"] == 30
    assert body["metrics"]["rules_only"]["precision"] == 1.0
    assert body["metrics"]["rules_only"]["recall"] == 1.0
    assert body["metrics"]["rules_only"]["false_positive_count"] == 0



def test_audit_log_is_admin_only_and_never_exports_comment_bodies(client):
    private_comment = "PRIVATE_COMMENT_BODY_must_not_leave_the_thread"
    checked = check(client, "Classic T-shirt at ₹599")
    draft_id = checked.json()["draft"]["id"]
    posted = client.post(f"/api/drafts/{draft_id}/comments", json={"message": private_comment, "role": "Reviewer"})
    assert posted.status_code == 200

    denied = client.get("/api/audit-log?role=Creator")
    assert denied.status_code == 403
    response = client.get("/api/audit-log?role=Admin")
    assert response.status_code == 200
    body = response.json()
    assert body["total"] >= 2
    comment_action = next(item for item in body["items"] if item["action"] == "comment_added")
    assert comment_action["actor_role"] == "Reviewer"
    assert comment_action["draft_id"] == draft_id
    assert comment_action["draft_title"] == f"Draft #{draft_id}"
    assert private_comment not in response.text

    csv_response = client.get("/api/audit-log.csv?role=Admin")
    assert csv_response.status_code == 200
    assert "text/csv" in csv_response.headers["content-type"]
    assert "role,action,draft_id,draft_title,timestamp" in csv_response.text
    assert private_comment not in csv_response.text
    assert f"Draft #{draft_id}" in csv_response.text


def test_audit_rows_survive_demo_reset_and_load_does_not_delete_work(client):
    checked = check(client, "Classic T-shirt at ₹599")
    draft_id = checked.json()["draft"]["id"]
    before = client.get("/api/drafts").json()
    loaded = client.post("/api/demo/load?role=Creator", json={})
    assert loaded.status_code == 200
    assert len(client.get("/api/drafts").json()) == len(before)

    reset = client.post("/api/demo/reset?role=Admin", json={})
    assert reset.status_code == 200
    records = client.get("/api/audit-log?role=Admin").json()["items"]
    assert any(item["action"] == "brand_check" and item["draft_id"] == draft_id for item in records)
    assert any(item["action"] == "demo_data_loaded" for item in records)
    assert any(item["action"] == "demo_data_reset" for item in records)


def test_status_reports_configured_but_unprobed_without_calling_a_provider(client, monkeypatch):
    from backend.inkloom.api import operations

    monkeypatch.setattr(operations, "ai_is_configured", lambda: True)
    usage_reads = []
    monkeypatch.setattr(operations, "ai_calls_today", lambda db: usage_reads.append(True) or 4)
    response = client.get("/api/status")
    assert response.status_code == 200
    body = response.json()
    assert body["database_health"] == "ok"
    assert body["ai_configured"] is True
    assert body["ai_reachability"] == "unknown_not_probed"
    assert body["ai_calls_used_today"] == 4
    assert body["ai_daily_cap"] == 300
    assert body["guideline_version"] >= 1
    assert body["app_version"] == "1.0.0"
    assert usage_reads == [True]
    assert client.get("/health").json()["status"] == "ok"


def test_manifest_page_routes_refresh_to_spa_and_unknown_paths_return_404(client):
    for path in ("/evaluation", "/audit-log", "/status", "/new", "/report"):
        response = client.get(path)
        assert response.status_code == 200, path
        assert "text/html" in response.headers["content-type"]
        assert "Inkloom" in response.text
    assert client.get("/not-a-declared-inkloom-page").status_code == 404
