from __future__ import annotations

import json
import os
from contextlib import asynccontextmanager
from pathlib import Path

from fastapi import FastAPI, HTTPException
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from sqlalchemy.engine import Engine

from .api.guidelines import router as guidelines_router
from .api.operations import router as operations_router
from .api.workflow import router as workflow_router
from .db import init_database, make_engine, make_session_factory, seed_demo
from .services.ai import NOTICE, ai_is_configured

STATIC_DIR = Path(__file__).parent / "static"


def create_app(engine: Engine | None = None) -> FastAPI:
    app_engine = engine or make_engine()
    SessionLocal = make_session_factory(app_engine)

    @asynccontextmanager
    async def lifespan(app: FastAPI):
        init_database(app_engine)
        with SessionLocal() as db:
            seed_demo(db)
        yield
        if engine is None:
            app_engine.dispose()

    app = FastAPI(title="Inkloom AI", version="1.0.0", lifespan=lifespan)
    app.state.engine = app_engine
    app.state.SessionLocal = SessionLocal
    app.include_router(guidelines_router)
    app.include_router(workflow_router)
    app.include_router(operations_router)

    @app.get("/health", tags=["system"])
    def health():
        ai_configured = ai_is_configured()
        return {
            "status": "ok",
            "service": "inkloom-ai",
            "ai_configured": ai_configured,
            "ai_notice": None if ai_configured else NOTICE,
        }

    if (STATIC_DIR / "assets").is_dir():
        app.mount("/assets", StaticFiles(directory=STATIC_DIR / "assets"), name="assets")

    @app.get("/", include_in_schema=False)
    def root():
        index = STATIC_DIR / "index.html"
        if index.is_file():
            return FileResponse(index)
        return {"status": "starting", "message": "Frontend assets are not built yet."}

    @app.get("/manus-routes.json", include_in_schema=False)
    def route_manifest():
        manifest = STATIC_DIR / "manus-routes.json"
        if not manifest.is_file():
            return {"detail": "Route manifest not found"}
        return FileResponse(manifest, media_type="application/json")

    @app.get("/{path:path}", include_in_schema=False)
    def spa_fallback(path: str):
        static_root = STATIC_DIR.resolve()
        candidate = (STATIC_DIR / path).resolve()
        if candidate.is_relative_to(static_root) and candidate.is_file():
            return FileResponse(candidate)
        manifest = STATIC_DIR / "manus-routes.json"
        index = STATIC_DIR / "index.html"
        if manifest.is_file() and index.is_file():
            try:
                data = json.loads(manifest.read_text(encoding="utf-8"))
                declared = {item["path"] for item in data.get("routes", []) if isinstance(item, dict) and isinstance(item.get("path"), str)}
            except (OSError, json.JSONDecodeError, TypeError):
                declared = set()
            if f"/{path}" in declared:
                return FileResponse(index)
        raise HTTPException(404, "Not found")

    return app


app = create_app()


def main() -> None:
    import uvicorn

    uvicorn.run("backend.inkloom.main:app", host="0.0.0.0", port=int(os.getenv("PORT", "3000")), reload=False)


if __name__ == "__main__":
    main()
