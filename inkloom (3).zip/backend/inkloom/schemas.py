from __future__ import annotations

from typing import Annotated, Literal

from pydantic import BaseModel, ConfigDict, Field, field_validator


Channel = Literal["Instagram", "LinkedIn", "Ad", "Website"]
Role = Literal["Creator", "Reviewer", "Admin"]
Severity = Literal["High", "Medium", "Low"]
AssetRef = Annotated[str, Field(min_length=1, max_length=512)]


class StrictModel(BaseModel):
    model_config = ConfigDict(extra="forbid", str_strip_whitespace=True)


class ContentObject(StrictModel):
    text: str = Field(max_length=25000)
    assets: list[AssetRef] = Field(default_factory=list, max_length=12)


class DraftCreate(StrictModel):
    text: str = Field(min_length=1, max_length=25000)
    channel: Channel
    product_id: int = Field(gt=0)
    role: Role = "Creator"
    creator_id: str = Field(default="unattributed-browser", min_length=1, max_length=80)
    assets: list[AssetRef] = Field(default_factory=list, max_length=12)

    @field_validator("text")
    @classmethod
    def text_must_contain_non_whitespace(cls, value: str) -> str:
        if not value.strip():
            raise ValueError("Enter draft text before running a brand check.")
        return value


class BatchCheckRequest(StrictModel):
    texts: list[Annotated[str, Field(min_length=1, max_length=25000)]] = Field(min_length=1, max_length=12)
    channel: Channel
    product_id: int = Field(gt=0)
    role: Role = "Creator"
    creator_id: str = Field(default="unattributed-browser", min_length=1, max_length=80)

    @field_validator("texts")
    @classmethod
    def batch_texts_must_be_nonempty(cls, values: list[str]) -> list[str]:
        cleaned = [value.strip() for value in values]
        if any(not value for value in cleaned):
            raise ValueError("Remove empty rows before running a batch check.")
        return cleaned


class DraftEdit(StrictModel):
    text: str = Field(min_length=1, max_length=25000)
    role: Role = "Creator"

    @field_validator("text")
    @classmethod
    def text_must_contain_non_whitespace(cls, value: str) -> str:
        if not value.strip():
            raise ValueError("Draft text cannot be empty.")
        return value


class SubmitRequest(StrictModel):
    role: Role = "Creator"


class DecisionRequest(StrictModel):
    action: Literal["approve", "request_changes"]
    comment: str = Field(default="", max_length=2000)
    role: Literal["Reviewer"] = "Reviewer"


class FindingDismissRequest(StrictModel):
    role: Literal["Reviewer"] = "Reviewer"
    reason: str = Field(min_length=1, max_length=2000)

    @field_validator("reason")
    @classmethod
    def dismissal_reason_must_be_nonempty(cls, value: str) -> str:
        if not value.strip():
            raise ValueError("Add a reason before dismissing a finding.")
        return value.strip()


class FindingLabelRequest(StrictModel):
    role: Literal["Reviewer"] = "Reviewer"
    reviewer_label: Literal["valid", "false_positive"] | None = None


class DraftCommentCreate(StrictModel):
    role: Role
    message: str = Field(min_length=1, max_length=2000)

    @field_validator("message")
    @classmethod
    def comment_must_be_nonempty(cls, value: str) -> str:
        if not value.strip():
            raise ValueError("Write a comment before sending it.")
        return value.strip()


class ProductInput(StrictModel):
    name: str = Field(min_length=1, max_length=160)
    approved_price: float = Field(gt=0, le=10000000)
    material: str = Field(default="", max_length=240)


class BannedTermInput(StrictModel):
    term: str = Field(min_length=1, max_length=160)


class PreferredTermInput(StrictModel):
    term: str = Field(min_length=1, max_length=160)
    preferred: str = Field(min_length=1, max_length=160)


class ApprovedClaimInput(StrictModel):
    claim: str = Field(min_length=1, max_length=500)
    evidence: str = Field(min_length=1, max_length=500)


class ToneRuleInput(StrictModel):
    name: str = Field(min_length=1, max_length=120)
    description: str = Field(min_length=1, max_length=500)
    threshold: int | None = Field(default=None, ge=0, le=100)
    enabled: bool = True


class DisclaimerInput(StrictModel):
    phrase: str = Field(min_length=1, max_length=240)
    applies_to: str = Field(default="price or discount posts", max_length=120)


class LogoInput(StrictModel):
    version: str = Field(min_length=1, max_length=80)
    approved: bool = True


class AIFinding(StrictModel):
    type: str = Field(min_length=1, max_length=120)
    span: str = Field(min_length=1, max_length=800)
    explanation: str = Field(min_length=1, max_length=1200)
    guideline_ref: str = Field(min_length=1, max_length=160)
    severity: Severity
    suggestion: str = Field(max_length=800)
    confidence: float = Field(ge=0, le=1)


class AIFindings(StrictModel):
    findings: list[AIFinding] = Field(default_factory=list, max_length=30)
