from __future__ import annotations

import re
from typing import Any

from sqlalchemy.orm import Session
from sqlalchemy import select

from ..schemas import ContentObject
from ..models import EvidenceDocument
from .ai import AIAnalysisWrapper, AIResult
from .evidence_library import find_matching_evidence
from .rules import extract_prices, run_rule_checks, _term_pattern


SEVERITY_RANK = {"High": 0, "Medium": 1, "Low": 2, "Info": 3}


def _ref_snippets(product: Any, banned_terms: list[Any], approved_claims: list[Any], tone_rules: list[Any], disclaimers: list[Any], preferred_terms: list[Any] | None = None, *, draft_text: str = "") -> list[dict[str, str]]:
    snippets = [{"ref": f"product:{product.id}", "text": f"{product.name}; approved price ₹{product.approved_price:,.0f}; material {product.material}"}]
    snippets += [{"ref": f"banned_term:{item.id}", "text": f"Unapproved term: {item.term}"} for item in banned_terms if _term_pattern(item.term.strip()).search(draft_text)]
    draft_tokens = set(re.findall(r"[a-z0-9]{3,}", draft_text.casefold()))
    snippets += [{"ref": f"claim:{item.id}", "text": f"Approved claim: {item.claim}; evidence: {item.evidence}"} for item in approved_claims
                 if _term_pattern(item.claim.strip()).search(draft_text) or draft_tokens.intersection(re.findall(r"[a-z0-9]{4,}", item.claim.casefold()))]
    snippets += [{"ref": f"tone_rule:{item.id}", "text": f"{item.name}: {item.description}"} for item in tone_rules if item.enabled]
    price_or_discount = bool(extract_prices(draft_text)) or bool(re.search(r"\b(discount|off|sale|save|deal|offer|price)\b", draft_text, re.IGNORECASE))
    if price_or_discount:
        snippets += [{"ref": f"disclaimer:{item.id}", "text": f"Required disclaimer: {item.phrase} ({item.applies_to})"} for item in disclaimers]
    snippets += [{"ref": f"preferred_term:{item.id}", "text": f"Preferred wording: {item.term} → {item.preferred}"} for item in (preferred_terms or [])
                 if _term_pattern(item.term.strip()).search(draft_text)]
    return snippets


def _ai_evidence(ref: str, snippets: list[dict[str, str]], product: Any, banned_terms: list[Any], approved_claims: list[Any], tone_rules: list[Any], disclaimers: list[Any], preferred_terms: list[Any]) -> list[dict[str, Any]]:
    records: dict[str, tuple[str, str]] = {f"product:{product.id}": ("Product guideline", f"guideline:product:{product.id}")}
    records.update({f"banned_term:{x.id}": (f"Unapproved term: {x.term}", f"guideline:banned_term:{x.id}") for x in banned_terms})
    records.update({f"claim:{x.id}": (f"Approved claim: {x.claim}", f"guideline:claim:{x.id}") for x in approved_claims})
    records.update({f"tone_rule:{x.id}": (f"Tone rule: {x.name}", f"guideline:tone_rule:{x.id}") for x in tone_rules})
    records.update({f"disclaimer:{x.id}": (f"Required disclaimer: {x.phrase}", f"guideline:disclaimer:{x.id}") for x in disclaimers})
    records.update({f"preferred_term:{x.id}": (f"Preferred wording: {x.term} → {x.preferred}", f"guideline:preferred_term:{x.id}") for x in preferred_terms})
    item = next((snippet for snippet in snippets if snippet["ref"] == ref), None)
    label, href = records.get(ref, ("Brand evidence library", "guideline:claims"))
    return [{"label": label if item else "No approved evidence found", "detail": item["text"] if item else "No supplied guideline record supports this wording.", "guideline_ref": ref if item else "claim:evidence_missing", "href": href}]


def check_content(content: ContentObject, product: Any, banned_terms: list[Any], approved_claims: list[Any], tone_rules: list[Any], disclaimers: list[Any], preferred_terms: list[Any] | None = None, *, ai_runner=None, session: Session | None = None, guideline_version: int = 1) -> dict[str, Any]:
    text = content.text
    preferred_terms = preferred_terms or []
    rule_findings, verified_claims = run_rule_checks(text, product, banned_terms, approved_claims, tone_rules, disclaimers, preferred_terms)
    snippets = _ref_snippets(product, banned_terms, approved_claims, tone_rules, disclaimers, preferred_terms, draft_text=text)
    allowed_refs = {snippet["ref"] for snippet in snippets}
    if not text.strip():
        ai_result = AIResult(available=False, findings=[], notice="AI analysis skipped because OCR found no readable text.")
    elif ai_runner is not None:
        ai_result: AIResult = ai_runner(text, snippets)
    else:
        ai_result = AIAnalysisWrapper(session=session, guideline_version=guideline_version).analyze(text, snippets)
    approved_phrases = [re.sub(r"\s+", " ", item["claim"]).casefold() for item in verified_claims]
    findings = list(rule_findings)
    accepted_ai_findings: list[dict[str, Any]] = []
    for item in ai_result.findings:
        if item["type"] not in {"unsupported_claim", "tone_mismatch"}:
            continue
        if item["guideline_ref"] not in allowed_refs:
            continue
        normalized_span = re.sub(r"\s+", " ", item["span"]).casefold()
        if any(normalized_span == phrase or normalized_span in phrase or phrase in normalized_span for phrase in approved_phrases):
            continue
        span_match = re.search(re.escape(item["span"]), text, flags=re.IGNORECASE)
        if span_match is None:
            continue
        start = span_match.start()
        end = span_match.end()
        evidence = _ai_evidence(item["guideline_ref"], snippets, product, banned_terms, approved_claims, tone_rules, disclaimers, preferred_terms)
        accepted_finding = {
            "type": item["type"], "span": item["span"], "start": start, "end": end,
            "explanation": item["explanation"], "guideline_ref": item["guideline_ref"], "evidence": evidence,
            "severity": item["severity"], "suggestion": item["suggestion"], "source": "AI",
            "confidence": item["confidence"], "uncertainty": f"AI confidence: {item['confidence']:.0%}. Review before applying.",
            "replacement": item["suggestion"],
        }
        accepted_ai_findings.append(accepted_finding)
        findings.append(accepted_finding)
    deduped: dict[tuple[str, str, int], dict[str, Any]] = {}
    for item in findings:
        key = (item["type"], re.sub(r"\s+", " ", item["span"]).casefold(), item["start"])
        existing = deduped.get(key)
        if existing is None or (existing["source"] == "AI" and item["source"] == "Rule"):
            deduped[key] = item
    result = sorted(deduped.values(), key=lambda item: (SEVERITY_RANK.get(item["severity"], 9), item["start"] if item["start"] >= 0 else len(text)))
    documents = list(session.scalars(select(EvidenceDocument).order_by(EvidenceDocument.id))) if session is not None else []
    supported: list[dict[str, Any]] = []
    remaining: list[dict[str, Any]] = []
    for finding in result:
        if finding.get("type") != "unsupported_claim":
            remaining.append(finding)
            continue
        match = find_matching_evidence(finding.get("span", ""), documents)
        if match:
            supported.append({
                "claim": finding.get("span", ""), "evidence": match["excerpt"],
                "guideline_ref": f"evidence_document:{match['id']}",
                "href": f"guideline:evidence_document:{match['id']}",
                "source": "Evidence library", "document_title": match["title"],
            })
        else:
            finding["evidence"] = [{
                "label": "No evidence found",
                "detail": f"Searched {len(documents)} evidence document(s); none contained a matching passage.",
                "guideline_ref": "claim:evidence_missing", "href": "guideline:claims",
            }]
            remaining.append(finding)
    verified_claims.extend(supported)
    result = remaining
    return {
        "findings": result,
        "rule_findings": rule_findings,
        "ai_findings": accepted_ai_findings,
        "verified_claims": verified_claims,
        "ai_available": ai_result.available,
        "ai_notice": ai_result.notice,
    }
