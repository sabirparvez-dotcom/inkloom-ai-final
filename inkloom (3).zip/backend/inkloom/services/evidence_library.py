from __future__ import annotations

import re
from pathlib import Path
from typing import Any

import fitz

MAX_EVIDENCE_BYTES = 2 * 1024 * 1024
MAX_EVIDENCE_PAGES = 100
MAX_EVIDENCE_TEXT_CHARS = 500_000
STOP_WORDS = {"the", "and", "for", "with", "from", "this", "that", "have", "has", "are", "was", "were", "our", "your", "its", "into", "than", "then", "when", "what", "which", "while", "over", "under", "in", "on", "of", "to", "a", "an", "is", "be", "by"}


class EvidenceUploadError(ValueError):
    def __init__(self, message: str, status_code: int = 422):
        super().__init__(message)
        self.status_code = status_code


def extract_evidence_text(filename: str, payload: bytes) -> tuple[str, str]:
    """Validate and extract a small UTF-8 text or selectable-text PDF upload."""
    if len(payload) > MAX_EVIDENCE_BYTES:
        raise EvidenceUploadError("Evidence upload is too large. Maximum size is 2 MB.", 413)
    suffix = Path(filename or "").suffix.casefold()
    safe_name = Path(filename or "evidence.txt").name[:240]
    if suffix == ".pdf":
        if not payload.startswith(b"%PDF"):
            raise EvidenceUploadError("The selected .pdf file is not a valid PDF.", 415)
        try:
            with fitz.open(stream=payload, filetype="pdf") as document:
                if document.page_count > MAX_EVIDENCE_PAGES:
                    raise EvidenceUploadError(f"PDF has too many pages. Maximum is {MAX_EVIDENCE_PAGES}.")
                text = "\n".join(page.get_text("text") for page in document).strip()
        except EvidenceUploadError:
            raise
        except Exception as error:
            raise EvidenceUploadError("We could not read this PDF. Choose a valid text-based PDF.") from error
        if not text:
            raise EvidenceUploadError("No selectable text found. Scanned PDFs are not supported in the evidence library.")
    elif suffix in {".txt", ".md"}:
        if payload.startswith(b"%PDF"):
            raise EvidenceUploadError("The file contents are a PDF, but the filename is not .pdf.", 415)
        try:
            text = payload.decode("utf-8-sig")
        except UnicodeDecodeError as error:
            raise EvidenceUploadError("Text evidence must be UTF-8 encoded.") from error
        if "\x00" in text:
            raise EvidenceUploadError("Text evidence contains binary data. Choose a plain UTF-8 text file.", 415)
        text = text.strip()
    else:
        raise EvidenceUploadError("Upload a .txt, .md, or text-based .pdf file.", 415)

    if not text:
        raise EvidenceUploadError("The evidence document is empty.")
    if len(text) > MAX_EVIDENCE_TEXT_CHARS:
        raise EvidenceUploadError("Extracted evidence text exceeds the 500,000 character safety limit.")
    return safe_name, text


def _normalize(text: str) -> str:
    return re.sub(r"\s+", " ", re.sub(r"[^\w\s%#.-]", " ", text.casefold())).strip()


def _claim_terms(text: str) -> set[str]:
    return {token for token in re.findall(r"[a-z0-9%#.-]+", text.casefold()) if len(token) >= 3 and token not in STOP_WORDS}


def find_matching_evidence(claim: str, documents: list[Any]) -> dict[str, Any] | None:
    """Return a supporting sentence only for an exact or high-overlap lexical match."""
    normalized_claim = _normalize(claim)
    if not normalized_claim:
        return None
    claim_terms = _claim_terms(normalized_claim)
    for document in documents:
        sentences = [part.strip() for part in re.split(r"(?<=[.!?])\s+|\n+", document.extracted_text or "") if part.strip()]
        for sentence in sentences:
            normalized_sentence = _normalize(sentence)
            matched = normalized_claim in normalized_sentence
            if not matched and claim_terms:
                sentence_terms = _claim_terms(normalized_sentence)
                coverage = len(claim_terms & sentence_terms) / len(claim_terms)
                matched = coverage >= 0.8 and (len(claim_terms) >= 2 or normalized_claim in normalized_sentence)
            if matched:
                excerpt = sentence if len(sentence) <= 360 else sentence[:357].rstrip() + "…"
                return {"id": document.id, "title": document.title, "excerpt": excerpt}
    return None
