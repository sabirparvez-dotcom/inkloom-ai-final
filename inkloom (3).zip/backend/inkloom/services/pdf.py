from __future__ import annotations

from io import BytesIO
from typing import Any, cast

import fitz
from reportlab.lib import colors
from reportlab.lib.pagesizes import letter
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import inch
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle
from xml.sax.saxutils import escape


MAX_PDF_BYTES = 2 * 1024 * 1024


def extract_pdf_text(payload: bytes) -> str:
    if len(payload) > MAX_PDF_BYTES:
        raise ValueError("PDF is too large. Maximum upload size is 2 MB.")
    if not payload.startswith(b"%PDF"):
        raise ValueError("Please upload a valid PDF file.")
    try:
        document = fitz.open(stream=payload, filetype="pdf")
        if document.page_count > 60:
            raise ValueError("PDF has too many pages. Maximum is 60 pages.")
        text = "\n".join(cast(Any, page).get_text("text") for page in document).strip()
    except ValueError:
        raise
    except Exception as error:
        raise ValueError("We could not read this PDF. Please try another text-based PDF.") from error
    if not text:
        raise ValueError("No selectable text found. Scanned PDFs and OCR are not supported yet.")
    if len(text) > 25_000:
        raise ValueError("Extracted PDF text exceeds the 25,000 character limit. Shorten the document before checking it.")
    return text


def _register_font() -> str:
    font_path = "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"
    bold_path = "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf"
    try:
        pdfmetrics.registerFont(TTFont("InkloomSans", font_path))
        pdfmetrics.registerFont(TTFont("InkloomSans-Bold", bold_path))
        return "InkloomSans"
    except Exception:
        return "Helvetica"


def _p(text: Any, style: ParagraphStyle) -> Paragraph:
    return Paragraph(escape(str(text)).replace("\n", "<br/>"), style)


def create_review_pdf(draft: dict[str, Any], revisions: list[dict[str, Any]], history: list[dict[str, Any]]) -> bytes:
    output = BytesIO()
    font = _register_font()
    styles = getSampleStyleSheet()
    title = ParagraphStyle("InkloomTitle", parent=styles["Title"], fontName=font, fontSize=20, leading=25, textColor=colors.HexColor("#183B32"), spaceAfter=10)
    body = ParagraphStyle("InkloomBody", parent=styles["BodyText"], fontName=font, fontSize=9, leading=13, spaceAfter=5)
    heading = ParagraphStyle("InkloomHeading", parent=styles["Heading2"], fontName=font, fontSize=12, leading=16, textColor=colors.HexColor("#183B32"), spaceBefore=12, spaceAfter=6)
    minor = ParagraphStyle("InkloomMinor", parent=body, fontSize=8, textColor=colors.HexColor("#64766B"))
    doc = SimpleDocTemplate(output, pagesize=letter, rightMargin=0.65 * inch, leftMargin=0.65 * inch, topMargin=0.6 * inch, bottomMargin=0.6 * inch)
    story: list[Any] = [_p("Inkloom AI · Brand review", title)]
    story += [_p(f"Draft #{draft['id']} · {draft['channel']} · Status: {draft['status']} · Product: {draft['product_name']}", body)]
    story += [_p("Nothing is auto-published.", body), Spacer(1, 8), _p("Current draft text", heading), _p(draft["text"], body)]
    latest_revision = draft.get("latest_revision") or {}
    if latest_revision.get("health_score") is not None:
        score_detail = latest_revision.get("health_score_breakdown", {})
        story.append(_p(f"Current Brand Health Score: {latest_revision['health_score']}/100 · {score_detail.get('formula', '')}", body))

    for revision in sorted(revisions, key=lambda item: item["number"]):
        story += [_p(f"Revision {revision['number']} · Guidelines v{revision.get('guideline_version', 1)} · {revision.get('created_at', '')} · checked by {revision.get('actor_role', 'Creator')}", heading)]
        score_detail = revision.get("health_score_breakdown", {})
        if revision.get("health_score") is not None:
            counts = score_detail.get("counts", {})
            deductions = score_detail.get("deductions", {})
            story.append(_p(f"Brand Health Score: {revision['health_score']}/100 · High {counts.get('High', 0)} (−{deductions.get('High', 0)}), Medium {counts.get('Medium', 0)} (−{deductions.get('Medium', 0)}), Low {counts.get('Low', 0)} (−{deductions.get('Low', 0)}) · {score_detail.get('formula', '')}", body))
        story += [_p("Checked draft snapshot", minor), _p(revision.get("text", ""), body)]
        findings = revision.get("findings", [])
        if findings:
            rows: list[list[Any]] = [[_p("Severity / problem", body), _p("Explanation / evidence", body), _p("Suggested correction", body)]]
            for item in findings:
                evidence_text = "; ".join(e.get("label", "") + (f" — {e.get('detail', '')}" if e.get("detail") else "") for e in item.get("evidence", []))
                review_notes = []
                if item.get("reviewer_label"):
                    review_notes.append(f"Reviewer label: {item['reviewer_label']} (informational only)")
                if item.get("dismissal_reason"):
                    review_notes.append(f"Dismissed by {item.get('dismissed_by_role') or 'Reviewer'}: {item['dismissal_reason']}")
                explanation = item.get("explanation", "")
                if evidence_text:
                    explanation += f"\nEvidence: {evidence_text}"
                if review_notes:
                    explanation += "\n" + "\n".join(review_notes)
                rows.append([
                    _p(f"{item.get('severity')} · {item.get('type')} ({item.get('source')})", body),
                    _p(explanation, body),
                    _p(item.get("suggestion", ""), body),
                ])
            table = Table(rows, colWidths=[1.55 * inch, 3.2 * inch, 1.55 * inch], repeatRows=1)
            table.setStyle(TableStyle([
                ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#E9F1ED")),
                ("GRID", (0, 0), (-1, -1), 0.4, colors.HexColor("#CED9D3")),
                ("VALIGN", (0, 0), (-1, -1), "TOP"),
                ("LEFTPADDING", (0, 0), (-1, -1), 6), ("RIGHTPADDING", (0, 0), (-1, -1), 6),
                ("TOPPADDING", (0, 0), (-1, -1), 6), ("BOTTOMPADDING", (0, 0), (-1, -1), 6),
            ]))
            story.append(table)
        else:
            story.append(_p("No findings in this revision.", body))
        verified = revision.get("verified_claims", [])
        if verified:
            story += [_p("Approved claims with evidence", minor)]
            for claim in verified:
                story.append(_p(f"{claim['claim']} — {claim['evidence']}", body))

    story += [_p("Decision and event history", heading)]
    if history:
        for event in history:
            story.append(_p(f"{event.get('created_at', '')} · {event.get('actor_role', '')} · {event.get('event_type', '')} · {event.get('status', '')} {event.get('comment', '')}", body))
    else:
        story.append(_p("No review decisions recorded.", body))
    doc.build(story)
    return output.getvalue()
