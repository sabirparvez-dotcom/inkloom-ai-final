from __future__ import annotations

import re
from typing import Any


PRICE_NUMBER = r"(?:\d{1,3}(?:,\d{3})+|\d+)(?:\.\d{1,2})?"
CURRENCY_PRICE = re.compile(rf"(?:₹\s*{PRICE_NUMBER}|\b(?:Rs\.?|INR)\s*{PRICE_NUMBER})", re.IGNORECASE)
CONTEXT_PRICE = re.compile(rf"\b(?:only|at|just|from)\s+(?:₹\s*|(?:Rs\.?|INR)\s*)?{PRICE_NUMBER}", re.IGNORECASE)
AMOUNT = re.compile(PRICE_NUMBER)
SUPERLATIVE = re.compile(r"(?:\b(?:best|top[- ]rated|highest|ultimate)\b|#\s*1\b|\b(?:number|no\.?)\s+one\b)(?:\s+[A-Za-z][A-Za-z0-9'-]*){0,3}", re.IGNORECASE)


def _term_pattern(phrase: str) -> re.Pattern[str]:
    return re.compile(rf"(?<!\w){re.escape(phrase)}(?!\w)", re.IGNORECASE)


def _finding(*, kind: str, span: str, start: int, end: int, explanation: str, guideline_ref: str,
             evidence: list[dict[str, Any]], severity: str, suggestion: str, source: str = "Rule",
             confidence: float | None = None, replacement: str | None = None) -> dict[str, Any]:
    return {
        "type": kind,
        "span": span,
        "start": start,
        "end": end,
        "explanation": explanation,
        "guideline_ref": guideline_ref,
        "evidence": evidence,
        "severity": severity,
        "suggestion": suggestion,
        "source": source,
        "confidence": confidence,
        "uncertainty": None if source == "Rule" else "AI finding — review this suggestion; it may be uncertain.",
        "replacement": replacement,
    }


def extract_prices(text: str) -> list[dict[str, Any]]:
    """Extract ₹/Rs/INR prices and numbers introduced by only/at/just/from."""
    matches: list[dict[str, Any]] = []
    currency_spans: list[tuple[int, int]] = []
    for match in CURRENCY_PRICE.finditer(text):
        amount_match = AMOUNT.search(match.group(0))
        if not amount_match:
            continue
        amount = float(amount_match.group(0).replace(",", ""))
        currency_spans.append((match.start(), match.end()))
        matches.append({"start": match.start(), "end": match.end(), "span": match.group(0), "amount": amount})
    for match in CONTEXT_PRICE.finditer(text):
        if any(start < match.end() and end > match.start() for start, end in currency_spans):
            continue
        amount_match = AMOUNT.search(match.group(0))
        if not amount_match:
            continue
        amount = float(amount_match.group(0).replace(",", ""))
        matches.append({"start": match.start(), "end": match.end(), "span": match.group(0), "amount": amount})
    return sorted(matches, key=lambda item: item["start"])


def _approved_claims_in_text(text: str, approved_claims: list[Any]) -> list[dict[str, Any]]:
    verified: list[dict[str, Any]] = []
    for claim in approved_claims:
        phrase = claim.claim.strip()
        if phrase and re.search(re.escape(phrase), text, flags=re.IGNORECASE):
            verified.append({
                "claim": phrase,
                "evidence": claim.evidence,
                "guideline_ref": f"claim:{claim.id}",
                "href": f"guideline:claim:{claim.id}",
            })
    return verified


def run_rule_checks(text: str, product: Any, banned_terms: list[Any], approved_claims: list[Any],
                    tone_rules: list[Any], disclaimers: list[Any], preferred_terms: list[Any] | None = None) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    findings: list[dict[str, Any]] = []
    preferred_terms = preferred_terms or []
    verified_claims = _approved_claims_in_text(text, approved_claims)
    product_evidence = [{
        "label": f"Approved price: ₹{product.approved_price:,.0f}",
        "detail": f"{product.name}" + (f" · {product.material}" if product.material else ""),
        "guideline_ref": f"product:{product.id}",
        "href": f"guideline:product:{product.id}",
    }]

    prices = extract_prices(text)
    for price in prices:
        if abs(price["amount"] - float(product.approved_price)) > 0.009:
            findings.append(_finding(
                kind="price_mismatch", span=price["span"], start=price["start"], end=price["end"],
                explanation=f"This draft lists ₹{price['amount']:,.2f}, but the approved price for {product.name} is ₹{product.approved_price:,.0f}.",
                guideline_ref=f"product:{product.id}", evidence=product_evidence, severity="High",
                suggestion=f"Use the approved price ₹{product.approved_price:,.0f} after confirming it is still current.",
                replacement=f"₹{product.approved_price:,.0f}",
            ))

    for term in banned_terms:
        phrase = term.term.strip()
        if not phrase:
            continue
        for match in _term_pattern(phrase).finditer(text):
            evidence = [{"label": f"Unapproved term: {phrase}", "detail": "Remove or rewrite this wording.",
                        "guideline_ref": f"banned_term:{term.id}", "href": f"guideline:banned_term:{term.id}"}]
            findings.append(_finding(
                kind="banned_term", span=match.group(0), start=match.start(), end=match.end(),
                explanation=f"“{phrase}” is listed as a banned or unapproved term in the brand guidelines.",
                guideline_ref=f"banned_term:{term.id}", evidence=evidence, severity="High",
                suggestion="Remove the unapproved wording; do not replace it with another unsupported promise.", replacement="",
            ))

    for term in preferred_terms:
        phrase = term.term.strip()
        replacement = term.preferred.strip()
        if not phrase or not replacement:
            continue
        for match in _term_pattern(phrase).finditer(text):
            ref = f"preferred_term:{term.id}"
            findings.append(_finding(
                kind="preferred_terminology", span=match.group(0), start=match.start(), end=match.end(),
                explanation=f"The brand prefers “{replacement}” over “{phrase}” for clear, on-brand wording.",
                guideline_ref=ref,
                evidence=[{"label": f"Preferred wording: {phrase} → {replacement}", "detail": "Use the preferred term in future-facing copy.",
                           "guideline_ref": ref, "href": f"guideline:{ref}"}],
                severity="Low", suggestion=f"Replace “{phrase}” with “{replacement}”.", replacement=replacement,
            ))

    approved_phrases = [claim.claim.casefold() for claim in approved_claims]
    for match in SUPERLATIVE.finditer(text):
        if any(match.group(0).casefold() in phrase or phrase in match.group(0).casefold() for phrase in approved_phrases):
            continue
        ref = "claim:evidence_missing"
        findings.append(_finding(
            kind="unsupported_claim", span=match.group(0), start=match.start(), end=match.end(),
            explanation=f"“{match.group(0)}” is a superlative that needs approved evidence; it has not been verified and is not being declared false.",
            guideline_ref=ref,
            evidence=[{"label": "Needs approved evidence", "detail": "No approved claim record supports this wording.",
                       "guideline_ref": ref, "href": "guideline:claims"}],
            severity="Medium", suggestion="Replace it with a specific, supported product fact or add evidence under Approved claims.", replacement="",
        ))

    price_or_discount_content = bool(prices) or bool(re.search(r"\b(discount|off|sale|save|deal|offer|price)\b", text, re.IGNORECASE))
    if price_or_discount_content:
        for disclaimer in disclaimers:
            if disclaimer.phrase.casefold() not in text.casefold():
                findings.append(_finding(
                    kind="missing_disclaimer", span=disclaimer.phrase, start=-1, end=-1,
                    explanation=f"Price or discount content must include the required disclaimer “{disclaimer.phrase}”.",
                    guideline_ref=f"disclaimer:{disclaimer.id}",
                    evidence=[{"label": f"Required disclaimer: {disclaimer.phrase}", "detail": disclaimer.applies_to,
                              "guideline_ref": f"disclaimer:{disclaimer.id}", "href": f"guideline:disclaimer:{disclaimer.id}"}],
                    severity="Medium", suggestion=f"Add “{disclaimer.phrase}” to this post.", replacement=disclaimer.phrase,
                ))

    exclamation_rule = next((rule for rule in tone_rules if rule.enabled and "exclamation" in rule.name.casefold()), None)
    max_exclamations = (exclamation_rule.threshold if exclamation_rule and exclamation_rule.threshold is not None else 1)
    exclamations = list(re.finditer(r"!", text))
    if exclamation_rule and len(exclamations) > max_exclamations:
        match = exclamations[max_exclamations]
        evidence = [{"label": f"Tone rule: max {max_exclamations} exclamation mark(s)", "detail": exclamation_rule.description,
                    "guideline_ref": f"tone_rule:{exclamation_rule.id}",
                    "href": f"guideline:tone_rule:{exclamation_rule.id}"}]
        findings.append(_finding(
            kind="excessive_exclamation", span="!", start=match.start(), end=match.end(),
            explanation=f"The tone guidance allows no more than {max_exclamations} exclamation mark(s); this draft uses {len(exclamations)}.",
            guideline_ref=evidence[0]["guideline_ref"], evidence=evidence, severity="Low",
            suggestion="Keep the emphasis in words and remove the extra exclamation mark.", replacement="",
        ))

    caps_rule = next((rule for rule in tone_rules if rule.enabled and "caps" in rule.name.casefold()), None)
    if caps_rule:
        for match in re.finditer(r"\b[A-Z]{2,}\b", text):
            if match.group(0) in {"INR"}:
                continue
            ref = f"tone_rule:{caps_rule.id}"
            findings.append(_finding(
                kind="all_caps_word", span=match.group(0), start=match.start(), end=match.end(),
                explanation=f"“{match.group(0)}” is written in all caps; {caps_rule.description}",
                guideline_ref=ref,
                evidence=[{"label": f"Tone rule: {caps_rule.name}", "detail": caps_rule.description,
                          "guideline_ref": ref, "href": f"guideline:tone_rule:{caps_rule.id}"}],
                severity="Low", suggestion=f"Use sentence case: {match.group(0).title()}.", replacement=match.group(0).title(),
            ))

    findings.sort(key=lambda item: (item["start"] if item["start"] >= 0 else len(text), item["type"]))
    return findings, verified_claims
