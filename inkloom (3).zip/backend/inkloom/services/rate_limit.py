from __future__ import annotations

import time

from fastapi import HTTPException
from sqlalchemy import delete
from sqlalchemy.dialects.sqlite import insert
from sqlalchemy.orm import Session

from ..models import RateLimitWindow, utcnow

CHECKS_PER_MINUTE: int = 30
WINDOW_SECONDS: int = 60


def enforce_check_rate_limit(session: Session, client_ip: str, *, cost: int = 1, now: int | None = None) -> None:
    if cost < 1 or cost > CHECKS_PER_MINUTE:
        raise HTTPException(status_code=422, detail=f"A batch must contain between 1 and {CHECKS_PER_MINUTE} checks.")
    current = int(time.time() if now is None else now)
    window_start = current // WINDOW_SECONDS * WINDOW_SECONDS
    ip = client_ip or "unknown"
    bucket_key = f"{ip}:{window_start}"
    statement = insert(RateLimitWindow).values(
        bucket_key=bucket_key,
        client_ip=ip,
        window_start=window_start,
        count=cost,
        updated_at=utcnow(),
    ).on_conflict_do_update(
        index_elements=[RateLimitWindow.bucket_key],
        set_={"count": RateLimitWindow.count + cost, "updated_at": utcnow()},
        where=RateLimitWindow.count + cost <= CHECKS_PER_MINUTE,
    )
    result = session.execute(statement)
    if result.rowcount == 0:
        session.rollback()
        retry_after = max(1, window_start + WINDOW_SECONDS - current)
        raise HTTPException(
            status_code=429,
            detail="Check limit reached. Please wait a minute before running another check.",
            headers={"Retry-After": str(retry_after)},
        )
    session.execute(delete(RateLimitWindow).where(RateLimitWindow.window_start < window_start - WINDOW_SECONDS))
    session.commit()
