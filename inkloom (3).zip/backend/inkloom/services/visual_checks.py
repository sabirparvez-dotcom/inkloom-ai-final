from __future__ import annotations

import io
import warnings
from pathlib import Path
from typing import Any

from PIL import Image, ImageOps

MAX_CREATIVE_BYTES = 5 * 1024 * 1024
MAX_IMAGE_PIXELS = 20_000_000
MAX_OCR_TEXT_CHARS = 25_000
OCR_TIMEOUT_SECONDS = 8
LOGO_MATCH_THRESHOLD = 0.72


class CreativeImageError(ValueError):
    def __init__(self, message: str, status_code: int = 422):
        super().__init__(message)
        self.status_code = status_code


def validate_image_upload(filename: str, payload: bytes, *, max_bytes: int = MAX_CREATIVE_BYTES) -> dict[str, Any]:
    """Verify PNG/JPEG bytes using Pillow, not the client-provided MIME header."""
    if len(payload) > max_bytes:
        limit_mb = max_bytes // (1024 * 1024)
        raise CreativeImageError(f"Image upload is too large. Maximum size is {limit_mb} MB.", 413)
    suffix = Path(filename or "").suffix.casefold()
    if suffix not in {".png", ".jpg", ".jpeg"}:
        raise CreativeImageError("Upload a PNG or JPG/JPEG image.", 415)
    try:
        with warnings.catch_warnings():
            warnings.simplefilter("error", Image.DecompressionBombWarning)
            with Image.open(io.BytesIO(payload)) as image:
                image_format = image.format
                width, height = image.size
                if width <= 0 or height <= 0 or width * height > MAX_IMAGE_PIXELS:
                    raise CreativeImageError("Image dimensions exceed the 20-megapixel safety limit.", 413)
                expected_format = "PNG" if suffix == ".png" else "JPEG"
                if image_format != expected_format:
                    raise CreativeImageError("The file contents do not match the .png or .jpg filename.", 415)
                image.verify()
    except CreativeImageError:
        raise
    except (Image.DecompressionBombError, Image.DecompressionBombWarning) as error:
        raise CreativeImageError("Image dimensions exceed the safe processing limit.", 413) from error
    except Exception as error:
        raise CreativeImageError("We could not read this image. Choose a valid PNG or JPG file.", 415) from error
    return {
        "source_filename": Path(filename or "creative.png").name[:240],
        "content_type": "image/png" if image_format == "PNG" else "image/jpeg",
        "width": width,
        "height": height,
    }


def extract_ocr_text(payload: bytes) -> tuple[str, str | None]:
    """OCR a validated image using Tesseract; never let an OCR failure abort a check."""
    try:
        import pytesseract
    except Exception:
        return "", "OCR unavailable — text checks were skipped; visual logo matching can still run."
    try:
        with Image.open(io.BytesIO(payload)) as source:
            image = ImageOps.exif_transpose(source).convert("RGB")
            image.thumbnail((2600, 2600), Image.Resampling.LANCZOS)
            text = pytesseract.image_to_string(image, lang="eng", config="--psm 6", timeout=OCR_TIMEOUT_SECONDS)
        text = " ".join(text.split())
    except Exception as error:
        if isinstance(error, getattr(pytesseract, "TesseractNotFoundError", ())):
            return "", "OCR unavailable — Tesseract is not installed; text checks were skipped."
        if "timeout" in type(error).__name__.casefold() or isinstance(error, RuntimeError):
            return "", "OCR timed out — text checks were skipped; the visual logo check still ran."
        return "", "OCR could not read this image — text checks were skipped; the visual logo check still ran."
    if not text:
        return "", "No readable text was found in this creative; the visual logo check still ran."
    if len(text) > MAX_OCR_TEXT_CHARS:
        return text[:MAX_OCR_TEXT_CHARS], "OCR text was longer than 25,000 characters and was truncated for checks."
    return text, None


def _gray_and_edges(cv2: Any, image: Any, *, crop_alpha: bool = False) -> Any:
    if len(image.shape) == 2:
        gray = image
    elif image.shape[2] == 4:
        alpha = image[:, :, 3]
        if crop_alpha and alpha.max() > 0:
            points = cv2.findNonZero((alpha > 8).astype("uint8") * 255)
            if points is not None:
                x, y, width, height = cv2.boundingRect(points)
                image = image[y:y + height, x:x + width]
                alpha = image[:, :, 3]
        rgb = image[:, :, :3].astype("float32")
        transparency = alpha.astype("float32")[:, :, None] / 255.0
        white = 255.0
        composite = (rgb * transparency + white * (1.0 - transparency)).clip(0, 255).astype("uint8")
        gray = cv2.cvtColor(composite, cv2.COLOR_BGR2GRAY)
    else:
        gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    return cv2.Canny(gray, 60, 160)


def _resize_within(cv2: Any, image: Any, max_dimension: int) -> Any:
    height, width = image.shape[:2]
    longest = max(height, width)
    if longest <= max_dimension:
        return image
    scale = max_dimension / longest
    return cv2.resize(image, (max(1, round(width * scale)), max(1, round(height * scale))), interpolation=cv2.INTER_AREA)


def find_approved_logo_match(creative_bytes: bytes, logo_bytes: bytes | None) -> dict[str, Any]:
    """Look for a tightly cropped approved logo at several sizes; result is advisory."""
    if not logo_bytes:
        return {"available": False, "matched": False, "score": None,
                "notice": "Approved logo image is not uploaded; visual logo matching was skipped."}
    try:
        import cv2
        import numpy as np
    except Exception:
        return {"available": False, "matched": False, "score": None,
                "notice": "OpenCV unavailable — visual logo matching was skipped; OCR and text rules still ran."}
    try:
        creative = cv2.imdecode(np.frombuffer(creative_bytes, dtype=np.uint8), cv2.IMREAD_UNCHANGED)
        logo = cv2.imdecode(np.frombuffer(logo_bytes, dtype=np.uint8), cv2.IMREAD_UNCHANGED)
        if creative is None or logo is None:
            return {"available": False, "matched": False, "score": None,
                    "notice": "The approved logo reference could not be decoded; logo matching was skipped."}
        creative = _resize_within(cv2, creative, 1600)
        logo = _resize_within(cv2, logo, 720)
        source_edges = _gray_and_edges(cv2, creative)
        template_edges = _gray_and_edges(cv2, logo, crop_alpha=True)
        source_height, source_width = source_edges.shape[:2]
        template_height, template_width = template_edges.shape[:2]
        if min(template_height, template_width) < 8:
            return {"available": False, "matched": False, "score": None,
                    "notice": "Approved logo image is too small to match reliably; upload a larger, tightly cropped logo."}
        best_score = -1.0
        for scale in (0.12, 0.16, 0.2, 0.25, 0.33, 0.4, 0.5, 0.67, 0.8, 1.0, 1.25, 1.5, 2.0, 2.5, 3.0):
            width = max(8, round(template_width * scale))
            height = max(8, round(template_height * scale))
            if width > source_width or height > source_height:
                continue
            interpolation = cv2.INTER_AREA if scale < 1 else cv2.INTER_CUBIC
            resized = cv2.resize(template_edges, (width, height), interpolation=interpolation)
            if resized.std() < 1.0:
                continue
            response = cv2.matchTemplate(source_edges, resized, cv2.TM_CCOEFF_NORMED)
            _, score, _, _ = cv2.minMaxLoc(response)
            best_score = max(best_score, float(score))
        if best_score < 0:
            return {"available": False, "matched": False, "score": None,
                    "notice": "The uploaded creative is too small for the logo reference; visual matching was skipped."}
        best_score = max(0.0, min(1.0, best_score))
        matched = best_score >= LOGO_MATCH_THRESHOLD
        if matched:
            notice = f"Approved logo detected by OpenCV template matching ({best_score:.0%} similarity)."
        else:
            notice = f"Approved logo not detected (best template match {best_score:.0%}); transformed, recolored, or obscured logos may be missed."
        return {"available": True, "matched": matched, "score": best_score, "notice": notice}
    except Exception:
        return {"available": False, "matched": False, "score": None,
                "notice": "OpenCV could not complete visual matching; OCR and text rules still ran."}
