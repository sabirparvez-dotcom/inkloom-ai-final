from __future__ import annotations

import json
from collections import Counter, defaultdict
from typing import Any

from sqlalchemy import select
from sqlalchemy.orm import Session

from ..models import Draft, FindingReview, ReviewerFeedbackExample, Revision

SEVERITY_DOWNGRADE = {"High": "Medium", "Medium": "Low", "Low": "Info"}


def _finding_type(findings_json: str, index: int) -> str | None:
    try:
        findings = json.loads(findings_json or "[]")
    except (TypeError, json.JSONDecodeError):
        return None
    if not isinstance(findings, list) or not 0 <= index < len(findings):
        return None
    value = findings[index]
    return str(value.get("type")) if isinstance(value, dict) and value.get("type") else None


def feedback_rates(session: Session) -> dict[str, dict[str, float | int]]:
    """Aggregate the latest saved label per finding record, plus labeled demo examples."""
    totals: Counter[str] = Counter()
    false_positives: Counter[str] = Counter()
    rows = session.execute(
        select(Revision.findings_json, FindingReview.finding_index, FindingReview.reviewer_label)
        .join(FindingReview, FindingReview.revision_id == Revision.id)
        .where(FindingReview.reviewer_label.in_(["valid", "false_positive"]))
    )
    for findings_json, index, label in rows:
        rule = _finding_type(findings_json, index)
        if not rule:
            continue
        totals[rule] += 1
        if label == "false_positive":
            false_positives[rule] += 1

    for example in session.scalars(select(ReviewerFeedbackExample)):
        totals[example.rule_key] += 1
        if example.reviewer_label == "false_positive":
            false_positives[example.rule_key] += 1

    return {
        rule: {
            "labelled_findings": count,
            "false_positives": false_positives[rule],
            "false_positive_rate": false_positives[rule] / count if count else 0.0,
        }
        for rule, count in totals.items()
    }


def apply_feedback_downgrades(findings: list[dict[str, Any]], rates: dict[str, dict[str, float | int]]) -> list[dict[str, Any]]:
    """Lower qualifying findings by one severity level, recording why on each item."""
    for finding in findings:
        rule = str(finding.get("type", ""))
        metric = rates.get(rule)
        if not metric or metric["labelled_findings"] < 3 or metric["false_positive_rate"] <= 0.5:
            continue
        current = finding.get("severity")
        downgraded = SEVERITY_DOWNGRADE.get(str(current))
        if downgraded:
            finding["severity_before_feedback"] = current
            finding["severity"] = downgraded
            finding["severity_downgraded_by_feedback"] = True
            finding["severity_note"] = "Downgraded by reviewer feedback"
            finding["feedback_false_positive_rate"] = round(float(metric["false_positive_rate"]), 4)
            finding["feedback_label_count"] = int(metric["labelled_findings"])
    return findings


def _latest_revision_map(revisions: list[Revision]) -> dict[int, Revision]:
    latest: dict[int, Revision] = {}
    for revision in revisions:
        saved = latest.get(revision.draft_id)
        if saved is None or revision.number > saved.number:
            latest[revision.draft_id] = revision
    return latest


def feedback_dashboard(session: Session) -> dict[str, list[dict[str, Any]]]:
    rates = feedback_rates(session)
    false_positive_by_rule = [
        {"rule": rule, **metric, "downgrade_active": metric["labelled_findings"] >= 3 and metric["false_positive_rate"] > 0.5}
        for rule, metric in sorted(rates.items(), key=lambda item: (-float(item[1]["false_positive_rate"]), -int(item[1]["labelled_findings"]), item[0]))
    ]

    rule_counts: Counter[str] = Counter()
    creator_rule_counts: Counter[tuple[str, str]] = Counter()
    drafts = list(session.scalars(select(Draft)))
    revisions = list(session.scalars(select(Revision)))
    latest = _latest_revision_map(revisions)
    for draft in drafts:
        revision = latest.get(draft.id)
        if revision is None:
            continue
        try:
            findings = json.loads(revision.findings_json or "[]")
        except (TypeError, json.JSONDecodeError):
            findings = []
        for finding in findings if isinstance(findings, list) else []:
            if not isinstance(finding, dict):
                continue
            rule = str(finding.get("type", "other"))
            rule_counts[rule] += 1
            creator_rule_counts[(draft.creator_id or "legacy-browser", rule)] += 1

    # Synthetic examples are labeled as demo data in their creator identifier and count
    # toward the seeded dashboard/feedback demonstration, not as actual stored drafts.
    for example in session.scalars(select(ReviewerFeedbackExample)):
        rule_counts[example.rule_key] += 1
        creator_rule_counts[(example.creator_id, example.rule_key)] += 1

    recurring_by_rule = [
        {"rule": rule, "count": count}
        for rule, count in sorted(rule_counts.items(), key=lambda item: (-item[1], item[0]))
    ]
    recurring_by_creator = [
        {"creator_id": creator_id, "rule": rule, "count": count,
         "demo_example": creator_id.startswith("demo-creator-")}
        for (creator_id, rule), count in sorted(creator_rule_counts.items(), key=lambda item: (-item[1], item[0][0], item[0][1]))
    ]
    return {
        "false_positive_by_rule": false_positive_by_rule,
        "recurring_by_rule": recurring_by_rule,
        "recurring_by_creator": recurring_by_creator,
    }
