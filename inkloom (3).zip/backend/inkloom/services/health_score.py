from __future__ import annotations

from typing import Any


BASE_SCORE = 100
SEVERITY_WEIGHTS: dict[str, int] = {"High": 25, "Medium": 12, "Low": 5}
FORMULA = "Brand Health Score = max(0, 100 − 25×High − 12×Medium − 5×Low)"


def calculate_health_score(findings: list[dict[str, Any]]) -> dict[str, Any]:
    """Calculate one revision's transparent 0–100 score from its saved findings."""
    counts = {severity: 0 for severity in SEVERITY_WEIGHTS}
    for finding in findings:
        severity = finding.get("severity")
        if severity in counts:
            counts[severity] += 1
    deductions = {severity: counts[severity] * weight for severity, weight in SEVERITY_WEIGHTS.items()}
    score = max(0, BASE_SCORE - sum(deductions.values()))
    return {
        "score": score,
        "base_score": BASE_SCORE,
        "counts": counts,
        "weights": dict(SEVERITY_WEIGHTS),
        "deductions": deductions,
        "formula": FORMULA,
    }
