from __future__ import annotations

from sqlalchemy import event
from sqlalchemy.orm import Session

from ..models import AuditLogEntry, Draft, WorkflowEvent


def record_audit(
    session: Session,
    *,
    actor_role: str,
    action: str,
    draft_id: int | None = None,
    draft_title: str | None = None,
) -> AuditLogEntry:
    """Queue a metadata-only audit record; the owning request commits it."""
    if draft_id is not None and draft_title is None:
        draft_title = f"Draft #{draft_id}"
    role_value = getattr(actor_role, "value", actor_role)
    row = AuditLogEntry(
        actor_role=str(role_value), action=action[:100], draft_id=draft_id,
        draft_title=draft_title[:200] if draft_title else None,
    )
    session.add(row)
    return row


@event.listens_for(Session, "before_flush")
def _mirror_workflow_events(session: Session, _flush_context: object, _instances: object) -> None:
    """Mirror workflow actions while intentionally omitting WorkflowEvent.comment."""
    for row in tuple(session.new):
        if not isinstance(row, WorkflowEvent):
            continue
        record_audit(
            session,
            actor_role=row.actor_role,
            action=row.event_type,
            draft_id=row.draft_id,
        )
