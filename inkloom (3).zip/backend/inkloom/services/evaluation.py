from __future__ import annotations

import json
from pathlib import Path
from typing import Any


DATASET_PATH = Path(__file__).resolve().parents[1] / "data" / "evaluation_cases.json"


def load_evaluation_dataset() -> dict[str, Any]:
    """Load the committed, synthetic evaluation set and fail clearly on malformed data."""
    payload = json.loads(DATASET_PATH.read_text(encoding="utf-8"))
    cases = payload.get("cases")
    if not isinstance(cases, list) or not cases:
        raise ValueError("The evaluation dataset must contain at least one case.")
    ids: set[str] = set()
    for case in cases:
        if not isinstance(case, dict) or not isinstance(case.get("id"), str):
            raise ValueError("Every evaluation case needs a stable string ID.")
        if case["id"] in ids:
            raise ValueError(f"Duplicate evaluation case ID: {case['id']}")
        ids.add(case["id"])
        if not isinstance(case.get("text"), str) or not isinstance(case.get("expected_types"), list):
            raise ValueError(f"Evaluation case {case['id']} is missing text or expected labels.")
    return payload


def score_predictions(
    cases: list[dict[str, Any]],
    predictions: dict[str, list[dict[str, Any]] | list[str]],
    *,
    case_ids: set[str] | None = None,
) -> dict[str, Any]:
    """Compute micro-averaged finding-type metrics over exactly the selected cases."""
    selected = [case for case in cases if case_ids is None or case["id"] in case_ids]
    expected = {
        (case["id"], finding_type)
        for case in selected
        for finding_type in case["expected_types"]
    }
    predicted: set[tuple[str, str]] = set()
    for case in selected:
        for item in predictions.get(case["id"], []):
            finding_type = item if isinstance(item, str) else item.get("type")
            if isinstance(finding_type, str) and finding_type:
                predicted.add((case["id"], finding_type))

    true_positives = len(expected & predicted)
    false_positives = len(predicted - expected)
    false_negatives = len(expected - predicted)
    precision_denominator = true_positives + false_positives
    recall_denominator = true_positives + false_negatives
    return {
        "cases": len(selected),
        "expected_findings": len(expected),
        "predicted_findings": len(predicted),
        "true_positives": true_positives,
        "false_positive_count": false_positives,
        "false_negatives": false_negatives,
        "precision": round(true_positives / precision_denominator, 4) if precision_denominator else None,
        "recall": round(true_positives / recall_denominator, 4) if recall_denominator else None,
    }
