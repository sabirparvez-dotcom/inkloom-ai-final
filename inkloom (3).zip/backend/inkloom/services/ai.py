from __future__ import annotations

import hashlib
import json
import os
import time
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any

import httpx
from pydantic import ValidationError
from sqlalchemy import select
from sqlalchemy.dialects.sqlite import insert
from sqlalchemy.orm import Session

from ..models import AICache, AIUsage
from ..schemas import AIFindings

NOTICE = "AI analysis unavailable. Showing rule-based checks only."
DEFAULT_DAILY_CAP = 300
REQUEST_TIMEOUT_SECONDS = 12.0


def _provider_keys() -> tuple[str | None, str | None]:
    openai_key = os.getenv("OPENAI_API_KEY")
    # Manus development environments may inject a platform-only proxy key. Do not
    # treat it as the app owner's OpenAI key or send draft text to api.openai.com.
    if os.getenv("OPENAI_API_BASE") and not os.getenv("OPENAI_BASE_URL"):
        openai_key = None
    return openai_key, os.getenv("ANTHROPIC_API_KEY")


def ai_is_configured() -> bool:
    return any(_provider_keys())


def daily_call_cap() -> int:
    try:
        return max(0, int(os.getenv("AI_DAILY_CAP", str(DEFAULT_DAILY_CAP))))
    except (TypeError, ValueError):
        return DEFAULT_DAILY_CAP


@dataclass
class AIResult:
    available: bool
    findings: list[dict[str, Any]]
    notice: str | None = None


def _content_from_openai(response: httpx.Response) -> str:
    data = response.json()
    return data["choices"][0]["message"]["content"]


def _content_from_anthropic(response: httpx.Response) -> str:
    data = response.json()
    return "".join(part.get("text", "") for part in data.get("content", []) if part.get("type") == "text")


def _call_provider(prompt: str, attempt: int, client: httpx.Client) -> str:
    _ = attempt
    openai_key, anthropic_key = _provider_keys()
    if openai_key:
        model = os.getenv("OPENAI_MODEL", "gpt-4o-mini")
        response = client.post(
            os.getenv("OPENAI_BASE_URL", "https://api.openai.com/v1").rstrip("/") + "/chat/completions",
            headers={"Authorization": f"Bearer {openai_key}"},
            json={"model": model, "temperature": 0, "response_format": {"type": "json_object"},
                  "messages": [{"role": "system", "content": "Return only a JSON object matching the requested schema."},
                              {"role": "user", "content": prompt}]},
        )
        response.raise_for_status()
        return _content_from_openai(response)
    if anthropic_key:
        model = os.getenv("ANTHROPIC_MODEL", "claude-3-5-haiku-latest")
        response = client.post(
            "https://api.anthropic.com/v1/messages",
            headers={"x-api-key": anthropic_key, "anthropic-version": "2023-06-01"},
            json={"model": model, "max_tokens": 1200, "temperature": 0,
                  "system": "Return only a JSON object matching the requested schema.",
                  "messages": [{"role": "user", "content": prompt}]},
        )
        response.raise_for_status()
        return _content_from_anthropic(response)
    raise RuntimeError("No AI provider key configured")


def _prompt(text: str, guideline_snippets: list[dict[str, str]]) -> str:
    return (
        "Review this marketing draft only for unsupported superlative claims and tone mismatch. "
        "Never declare a claim false. If unsupported, say it needs evidence. Do not flag an exact approved claim "
        "when the supplied guidelines provide evidence. Return exactly this JSON shape: "
        '{"findings":[{"type":"unsupported_claim|tone_mismatch","span":"exact text from draft",'
        '"explanation":"why review is needed, without saying false","guideline_ref":"exact supplied ref",'
        '"severity":"High|Medium|Low","suggestion":"replacement text for just this span, or empty if removal is safer",'
        '"confidence":0.0}]}. No markdown or extra keys.\n\n'
        "Relevant guideline snippets (the only context you may use):\n" + json.dumps(guideline_snippets, ensure_ascii=False) +
        "\n\nDraft text:\n" + text
    )


def _cache_key(text: str, guideline_version: int) -> str:
    source = json.dumps({"text": text, "guideline_version": guideline_version}, ensure_ascii=False, sort_keys=True)
    return hashlib.sha256(source.encode("utf-8")).hexdigest()


class AIAnalysisWrapper:
    def __init__(self, *, session: Session | None = None, guideline_version: int = 1,
                 client: httpx.Client | None = None, cap: int | None = None):
        self.session = session
        self.guideline_version = guideline_version
        self.client = client
        self.cap = daily_call_cap() if cap is None else max(0, cap)

    def _cached(self, key: str) -> AIResult | None:
        if self.session is None:
            return None
        row = self.session.get(AICache, key)
        if row is None:
            return None
        try:
            parsed = AIFindings.model_validate_json(row.response_json)
            return AIResult(available=True, findings=[item.model_dump() for item in parsed.findings])
        except (ValidationError, ValueError):
            self.session.delete(row)
            self.session.commit()
            return None

    def _reserve_daily_call(self) -> bool:
        if self.session is None:
            return True
        if self.cap <= 0:
            return False
        today = datetime.now(timezone.utc).date().isoformat()
        statement = insert(AIUsage).values(day=today, calls=1).on_conflict_do_update(
            index_elements=[AIUsage.day],
            set_={"calls": AIUsage.calls + 1},
            where=AIUsage.calls < self.cap,
        )
        result = self.session.execute(statement)
        if result.rowcount == 0:
            self.session.rollback()
            return False
        self.session.commit()
        return True

    def _save_cache(self, key: str, result: AIResult) -> None:
        if self.session is None:
            return
        payload = AIFindings.model_validate({"findings": result.findings}).model_dump_json()
        statement = insert(AICache).values(cache_key=key, response_json=payload).on_conflict_do_update(
            index_elements=[AICache.cache_key],
            set_={"response_json": payload, "created_at": datetime.now(timezone.utc)},
        )
        try:
            self.session.execute(statement)
        except Exception:
            self.session.rollback()

    def analyze(self, text: str, guideline_snippets: list[dict[str, str]]) -> AIResult:
        if not ai_is_configured():
            return AIResult(available=False, findings=[], notice=NOTICE)

        key = _cache_key(text, self.guideline_version)
        cached = self._cached(key)
        if cached is not None:
            return cached
        if not self._reserve_daily_call():
            return AIResult(available=False, findings=[], notice=NOTICE)

        prompt = _prompt(text, guideline_snippets)
        owns_client = self.client is None
        active_client = self.client or httpx.Client(timeout=httpx.Timeout(REQUEST_TIMEOUT_SECONDS, connect=3.0))
        try:
            for attempt in range(2):
                if attempt:
                    time.sleep(0.25)
                try:
                    raw = _call_provider(prompt, attempt, active_client)
                    try:
                        payload = json.loads(raw)
                    except json.JSONDecodeError as error:
                        raise ValueError("AI response was not valid JSON") from error
                    validated = AIFindings.model_validate(payload)
                    result = AIResult(available=True, findings=[item.model_dump() for item in validated.findings])
                    self._save_cache(key, result)
                    return result
                except (httpx.HTTPError, KeyError, TypeError, ValueError, ValidationError):
                    if attempt == 0:
                        prompt += "\nYour previous response was invalid. Retry once with valid JSON only and the exact required fields and types."
            return AIResult(available=False, findings=[], notice=NOTICE)
        except Exception:
            return AIResult(available=False, findings=[], notice=NOTICE)
        finally:
            if owns_client:
                active_client.close()


def analyze_draft(text: str, guideline_snippets: list[dict[str, str]], *, client: httpx.Client | None = None) -> AIResult:
    return AIAnalysisWrapper(client=client).analyze(text, guideline_snippets)


def ai_calls_today(session: Session) -> int:
    today = datetime.now(timezone.utc).date().isoformat()
    return session.scalar(select(AIUsage.calls).where(AIUsage.day == today)) or 0
