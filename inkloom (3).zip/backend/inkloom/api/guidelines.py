from __future__ import annotations

import json

from fastapi import APIRouter, Depends, File, Form, HTTPException, Query, UploadFile
from sqlalchemy import select
from sqlalchemy.orm import Session

from .common import get_db, require_admin
from ..db import bump_guideline_version, get_guideline_version
from ..models import ApprovedClaim, ApprovedLogoImage, BannedTerm, Brand, Disclaimer, Draft, EvidenceDocument, LogoVersion, PreferredTerm, Product, Revision, ToneRule
from ..schemas import ApprovedClaimInput, BannedTermInput, DisclaimerInput, LogoInput, PreferredTermInput, ProductInput, Role, ToneRuleInput
from ..services.evidence_library import EvidenceUploadError, MAX_EVIDENCE_BYTES, extract_evidence_text
from ..services.audit import record_audit
from ..services.visual_checks import CreativeImageError, MAX_CREATIVE_BYTES, validate_image_upload

router = APIRouter(prefix="/api/guidelines", tags=["guidelines"])


def _commit_guideline_change(db: Session) -> None:
    bump_guideline_version(db)
    record_audit(db, actor_role="Admin", action="guidelines_updated")
    db.commit()


def _assert_unreferenced(db: Session, guideline_ref: str) -> None:
    for revision in db.scalars(select(Revision)):
        try:
            findings = json.loads(revision.findings_json or "[]")
            claims = json.loads(revision.verified_claims_json or "[]")
        except (TypeError, json.JSONDecodeError) as error:
            raise HTTPException(409, "Review history could not be verified; keep this guideline record.") from error
        if any(item.get("guideline_ref") == guideline_ref or any(e.get("guideline_ref") == guideline_ref for e in item.get("evidence", [])) for item in findings):
            raise HTTPException(409, "This guideline is cited by saved review history and cannot be deleted.")
        if any(item.get("guideline_ref") == guideline_ref for item in claims):
            raise HTTPException(409, "This guideline supports a saved approved claim and cannot be deleted.")


def _row(row):
    data = {column.name: getattr(row, column.name) for column in row.__table__.columns}
    ref_type = {
        "approved_claims": "claim",
        "logo_versions": "logo",
    }.get(row.__tablename__, row.__tablename__.removesuffix("s"))
    data["guideline_ref"] = f"{ref_type}:{row.id}"
    return data


@router.get("")
def get_guidelines(db: Session = Depends(get_db)):
    brand = db.scalar(select(Brand).order_by(Brand.id).limit(1))
    logo = db.scalar(select(LogoVersion).order_by(LogoVersion.id.desc()).limit(1))
    logo_image = db.scalar(select(ApprovedLogoImage).order_by(ApprovedLogoImage.id.desc()).limit(1))
    return {
        "version": get_guideline_version(db),
        "brand": {"id": brand.id, "name": brand.name} if brand else {"id": 0, "name": ""},
        "products": [_row(x) for x in db.scalars(select(Product).order_by(Product.id))],
        "banned_terms": [_row(x) for x in db.scalars(select(BannedTerm).order_by(BannedTerm.id))],
        "preferred_terms": [_row(x) for x in db.scalars(select(PreferredTerm).order_by(PreferredTerm.id))],
        "approved_claims": [_row(x) for x in db.scalars(select(ApprovedClaim).order_by(ApprovedClaim.id))],
        "tone_rules": [_row(x) for x in db.scalars(select(ToneRule).order_by(ToneRule.id))],
        "disclaimers": [_row(x) for x in db.scalars(select(Disclaimer).order_by(Disclaimer.id))],
        "logo": _row(logo) if logo else None,
        "approved_logo_image": _logo_image_row(logo_image) if logo_image else None,
        "evidence_documents": [_evidence_document_row(x) for x in db.scalars(select(EvidenceDocument).order_by(EvidenceDocument.id))],
    }


def _evidence_document_row(row: EvidenceDocument) -> dict:
    return {"id": row.id, "title": row.title, "source_filename": row.source_filename,
            "created_at": row.created_at.isoformat()}


def _logo_image_row(row: ApprovedLogoImage) -> dict:
    return {"source_filename": row.source_filename, "content_type": row.content_type,
            "updated_at": row.updated_at.isoformat()}


@router.post("/approved-logo-image")
async def upload_approved_logo_image(
    file: UploadFile = File(...),
    role: Role = Form("Admin"),
    db: Session = Depends(get_db),
):
    require_admin(role)
    payload = await file.read(MAX_CREATIVE_BYTES + 1)
    await file.close()
    try:
        metadata = validate_image_upload(file.filename or "", payload)
    except CreativeImageError as error:
        raise HTTPException(error.status_code, str(error)) from error
    row = db.scalar(select(ApprovedLogoImage).order_by(ApprovedLogoImage.id.desc()).limit(1))
    if row is None:
        row = ApprovedLogoImage(source_filename=metadata["source_filename"], content_type=metadata["content_type"], image_bytes=payload)
        db.add(row)
    else:
        row.source_filename = metadata["source_filename"]
        row.content_type = metadata["content_type"]
        row.image_bytes = payload
    _commit_guideline_change(db)
    db.refresh(row)
    return _logo_image_row(row)


@router.post("/evidence-documents")
async def upload_evidence_document(
    title: str = Form(..., max_length=200),
    file: UploadFile = File(...),
    role: Role = Form("Admin"),
    db: Session = Depends(get_db),
):
    require_admin(role)
    clean_title = title.strip()
    if not clean_title:
        raise HTTPException(422, "Enter a title for this evidence document.")
    payload = await file.read(MAX_EVIDENCE_BYTES + 1)
    await file.close()
    try:
        filename, extracted_text = extract_evidence_text(file.filename or "", payload)
    except EvidenceUploadError as error:
        raise HTTPException(error.status_code, str(error)) from error
    row = EvidenceDocument(title=clean_title, source_filename=filename, extracted_text=extracted_text)
    db.add(row)
    db.flush()
    _commit_guideline_change(db)
    db.refresh(row)
    return _evidence_document_row(row)


@router.delete("/evidence-documents/{record_id}")
def delete_evidence_document(record_id: int, role: Role = Query("Admin"), db: Session = Depends(get_db)):
    require_admin(role)
    row = db.get(EvidenceDocument, record_id)
    if row is None:
        raise HTTPException(404, "Evidence document not found.")
    _assert_unreferenced(db, f"evidence_document:{record_id}")
    db.delete(row)
    _commit_guideline_change(db)
    return {"deleted": True}


@router.post("/products")
def create_product(payload: ProductInput, role: Role = Query("Admin"), db: Session = Depends(get_db)):
    require_admin(role)
    row = Product(**payload.model_dump())
    db.add(row)
    _commit_guideline_change(db)
    db.refresh(row)
    return _row(row)


@router.put("/products/{record_id}")
def update_product(record_id: int, payload: ProductInput, role: Role = Query("Admin"), db: Session = Depends(get_db)):
    require_admin(role)
    row = db.get(Product, record_id)
    if row is None:
        raise HTTPException(404, "Product guideline not found.")
    for key, value in payload.model_dump().items():
        setattr(row, key, value)
    _commit_guideline_change(db)
    return _row(row)


@router.delete("/products/{record_id}")
def delete_product(record_id: int, role: Role = Query("Admin"), db: Session = Depends(get_db)):
    require_admin(role)
    row = db.get(Product, record_id)
    if row is None:
        raise HTTPException(404, "Product guideline not found.")
    if db.scalar(select(Draft.id).where(Draft.product_id == record_id).limit(1)) is not None:
        raise HTTPException(409, "This product is linked to saved drafts and cannot be deleted.")
    if db.scalar(select(Product.id).where(Product.id != record_id).limit(1)) is None:
        raise HTTPException(400, "Keep at least one product so drafts can be checked.")
    db.delete(row)
    _commit_guideline_change(db)
    return {"deleted": True}


@router.post("/banned-terms")
def create_banned_term(payload: BannedTermInput, role: Role = Query("Admin"), db: Session = Depends(get_db)):
    require_admin(role)
    if db.scalar(select(BannedTerm).where(BannedTerm.term.ilike(payload.term)).limit(1)):
        raise HTTPException(409, "That term is already listed.")
    row = BannedTerm(**payload.model_dump())
    db.add(row)
    _commit_guideline_change(db)
    db.refresh(row)
    return _row(row)


@router.put("/banned-terms/{record_id}")
def update_banned_term(record_id: int, payload: BannedTermInput, role: Role = Query("Admin"), db: Session = Depends(get_db)):
    require_admin(role)
    row = db.get(BannedTerm, record_id)
    if row is None:
        raise HTTPException(404, "Banned-term guideline not found.")
    duplicate = next((item for item in db.scalars(select(BannedTerm))
                      if item.id != row.id and item.term.casefold() == payload.term.casefold()), None)
    if duplicate is not None:
        raise HTTPException(409, "That term is already listed.")
    row.term = payload.term
    _commit_guideline_change(db)
    return _row(row)


@router.delete("/banned-terms/{record_id}")
def delete_banned_term(record_id: int, role: Role = Query("Admin"), db: Session = Depends(get_db)):
    require_admin(role)
    row = db.get(BannedTerm, record_id)
    if row is None:
        raise HTTPException(404, "Banned-term guideline not found.")
    _assert_unreferenced(db, f"banned_term:{record_id}")
    db.delete(row)
    _commit_guideline_change(db)
    return {"deleted": True}


@router.post("/preferred-terms")
def create_preferred_term(payload: PreferredTermInput, role: Role = Query("Admin"), db: Session = Depends(get_db)):
    require_admin(role)
    if any(item.term.casefold() == payload.term.casefold() for item in db.scalars(select(PreferredTerm))):
        raise HTTPException(409, "That preferred-term rule is already listed.")
    row = PreferredTerm(**payload.model_dump())
    db.add(row)
    _commit_guideline_change(db)
    db.refresh(row)
    return _row(row)


@router.put("/preferred-terms/{record_id}")
def update_preferred_term(record_id: int, payload: PreferredTermInput, role: Role = Query("Admin"), db: Session = Depends(get_db)):
    require_admin(role)
    row = db.get(PreferredTerm, record_id)
    if row is None:
        raise HTTPException(404, "Preferred-term guideline not found.")
    if any(item.id != row.id and item.term.casefold() == payload.term.casefold() for item in db.scalars(select(PreferredTerm))):
        raise HTTPException(409, "That preferred-term rule is already listed.")
    row.term = payload.term
    row.preferred = payload.preferred
    _commit_guideline_change(db)
    return _row(row)


@router.delete("/preferred-terms/{record_id}")
def delete_preferred_term(record_id: int, role: Role = Query("Admin"), db: Session = Depends(get_db)):
    require_admin(role)
    row = db.get(PreferredTerm, record_id)
    if row is None:
        raise HTTPException(404, "Preferred-term guideline not found.")
    _assert_unreferenced(db, f"preferred_term:{record_id}")
    db.delete(row)
    _commit_guideline_change(db)
    return {"deleted": True}


@router.post("/approved-claims")
def create_claim(payload: ApprovedClaimInput, role: Role = Query("Admin"), db: Session = Depends(get_db)):
    require_admin(role)
    row = ApprovedClaim(**payload.model_dump())
    db.add(row)
    _commit_guideline_change(db)
    db.refresh(row)
    return _row(row)


@router.put("/approved-claims/{record_id}")
def update_claim(record_id: int, payload: ApprovedClaimInput, role: Role = Query("Admin"), db: Session = Depends(get_db)):
    require_admin(role)
    row = db.get(ApprovedClaim, record_id)
    if row is None:
        raise HTTPException(404, "Approved claim not found.")
    for key, value in payload.model_dump().items():
        setattr(row, key, value)
    _commit_guideline_change(db)
    return _row(row)


@router.delete("/approved-claims/{record_id}")
def delete_claim(record_id: int, role: Role = Query("Admin"), db: Session = Depends(get_db)):
    require_admin(role)
    row = db.get(ApprovedClaim, record_id)
    if row is None:
        raise HTTPException(404, "Approved claim not found.")
    _assert_unreferenced(db, f"claim:{record_id}")
    db.delete(row)
    _commit_guideline_change(db)
    return {"deleted": True}


@router.post("/tone-rules")
def create_tone_rule(payload: ToneRuleInput, role: Role = Query("Admin"), db: Session = Depends(get_db)):
    require_admin(role)
    row = ToneRule(**payload.model_dump())
    db.add(row)
    _commit_guideline_change(db)
    db.refresh(row)
    return _row(row)


@router.put("/tone-rules/{record_id}")
def update_tone_rule(record_id: int, payload: ToneRuleInput, role: Role = Query("Admin"), db: Session = Depends(get_db)):
    require_admin(role)
    row = db.get(ToneRule, record_id)
    if row is None:
        raise HTTPException(404, "Tone rule not found.")
    for key, value in payload.model_dump().items():
        setattr(row, key, value)
    _commit_guideline_change(db)
    return _row(row)


@router.delete("/tone-rules/{record_id}")
def delete_tone_rule(record_id: int, role: Role = Query("Admin"), db: Session = Depends(get_db)):
    require_admin(role)
    row = db.get(ToneRule, record_id)
    if row is None:
        raise HTTPException(404, "Tone rule not found.")
    _assert_unreferenced(db, f"tone_rule:{record_id}")
    db.delete(row)
    _commit_guideline_change(db)
    return {"deleted": True}


@router.post("/disclaimers")
def create_disclaimer(payload: DisclaimerInput, role: Role = Query("Admin"), db: Session = Depends(get_db)):
    require_admin(role)
    row = Disclaimer(**payload.model_dump())
    db.add(row)
    _commit_guideline_change(db)
    db.refresh(row)
    return _row(row)


@router.put("/disclaimers/{record_id}")
def update_disclaimer(record_id: int, payload: DisclaimerInput, role: Role = Query("Admin"), db: Session = Depends(get_db)):
    require_admin(role)
    row = db.get(Disclaimer, record_id)
    if row is None:
        raise HTTPException(404, "Disclaimer not found.")
    for key, value in payload.model_dump().items():
        setattr(row, key, value)
    _commit_guideline_change(db)
    return _row(row)


@router.delete("/disclaimers/{record_id}")
def delete_disclaimer(record_id: int, role: Role = Query("Admin"), db: Session = Depends(get_db)):
    require_admin(role)
    row = db.get(Disclaimer, record_id)
    if row is None:
        raise HTTPException(404, "Disclaimer not found.")
    _assert_unreferenced(db, f"disclaimer:{record_id}")
    db.delete(row)
    _commit_guideline_change(db)
    return {"deleted": True}


@router.put("/logo")
def update_logo(payload: LogoInput, role: Role = Query("Admin"), db: Session = Depends(get_db)):
    require_admin(role)
    row = db.scalar(select(LogoVersion).order_by(LogoVersion.id.desc()).limit(1))
    if row is None:
        row = LogoVersion(**payload.model_dump())
        db.add(row)
    else:
        row.version = payload.version
        row.approved = payload.approved
    _commit_guideline_change(db)
    db.refresh(row)
    return _row(row)


@router.delete("/logo")
def delete_logo(role: Role = Query("Admin"), db: Session = Depends(get_db)):
    require_admin(role)
    row = db.scalar(select(LogoVersion).order_by(LogoVersion.id.desc()).limit(1))
    if row is None:
        raise HTTPException(404, "Logo metadata not found.")
    _assert_unreferenced(db, f"logo:{row.id}")
    db.delete(row)
    _commit_guideline_change(db)
    return {"deleted": True}
