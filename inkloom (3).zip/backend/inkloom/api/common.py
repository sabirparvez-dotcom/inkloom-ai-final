from __future__ import annotations

from collections.abc import Generator

from fastapi import HTTPException, Request
from sqlalchemy.orm import Session

from ..schemas import Role


def get_db(request: Request) -> Generator[Session, None, None]:
    session = request.app.state.SessionLocal()
    try:
        yield session
    finally:
        session.close()


def require_admin(role: Role) -> None:
    if role != "Admin":
        raise HTTPException(status_code=403, detail="Switch to the Admin role to manage brand guidelines.")


def require_creator(role: Role) -> None:
    if role != "Creator":
        raise HTTPException(status_code=403, detail="Switch to the Creator role to edit or submit a draft.")


def require_reviewer(role: Role) -> None:
    if role != "Reviewer":
        raise HTTPException(status_code=403, detail="Switch to the Reviewer role to make a decision.")
