from __future__ import annotations

import csv
import difflib
import io
import json
from datetime import datetime, timezone
from typing import Any

from fastapi import APIRouter, Depends, File, Form, HTTPException, Query, Request, UploadFile
from fastapi.responses import Response
from sqlalchemy import select
from sqlalchemy.orm import Session

from .common import get_db, require_admin, require_creator, require_reviewer
from ..db import get_guideline_version, seed_demo
from ..models import ApprovedClaim, ApprovedLogoImage, BannedTerm, CreativeAsset, Disclaimer, Draft, DraftComment, FindingReview, PreferredTerm, Product, Revision, SampleDraft, ToneRule, WorkflowEvent
from ..schemas import BatchCheckRequest, Channel, ContentObject, DecisionRequest, DraftCommentCreate, DraftCreate, DraftEdit, FindingDismissRequest, FindingLabelRequest, Role, SubmitRequest
from ..services.checks import check_content
from ..services.ai import AIAnalysisWrapper, ai_is_configured
from ..services.audit import record_audit
from ..services.evaluation import load_evaluation_dataset, score_predictions
from ..services.health_score import calculate_health_score
from ..services.pdf import MAX_PDF_BYTES, create_review_pdf, extract_pdf_text
from ..services.rate_limit import enforce_check_rate_limit
from ..services.reviewer_feedback import apply_feedback_downgrades, feedback_dashboard, feedback_rates
from ..services.visual_checks import CreativeImageError, MAX_CREATIVE_BYTES, extract_ocr_text, find_approved_logo_match, validate_image_upload

router = APIRouter(prefix="/api", tags=["draft-workflow"])
MAX_BATCH_BYTES = 2 * 1024 * 1024
MAX_BATCH_ITEMS = 12
MAX_CREATIVE_TEXT_CHARS = 25_000


def _iso(value: datetime | None) -> str | None:
    return value.isoformat() if value else None


def _revision_dict(revision: Revision, db: Session | None = None) -> dict[str, Any]:
    findings = json.loads(revision.findings_json or "[]")
    for finding in findings:
        finding.setdefault("reviewer_label", None)
        finding.setdefault("dismissal_reason", None)
        finding.setdefault("dismissed_by_role", None)
        finding.setdefault("dismissed_at", None)
        finding.setdefault("severity_downgraded_by_feedback", False)
    if db is not None:
        reviews = db.scalars(select(FindingReview).where(FindingReview.revision_id == revision.id))
        for review in reviews:
            if 0 <= review.finding_index < len(findings):
                finding = findings[review.finding_index]
                finding["reviewer_label"] = review.reviewer_label
                finding["dismissal_reason"] = review.dismissal_reason
                finding["dismissed_by_role"] = review.dismissed_by_role
                finding["dismissed_at"] = _iso(review.dismissed_at)
    health = calculate_health_score(findings)
    return {
        "id": revision.id, "draft_id": revision.draft_id, "number": revision.number,
        "text": revision.text, "findings": findings,
        "health_score": health["score"], "health_score_breakdown": health,
        "verified_claims": json.loads(revision.verified_claims_json or "[]"),
        "ai_available": revision.ai_available, "ai_notice": revision.ai_notice,
        "actor_role": revision.actor_role, "guideline_version": revision.guideline_version,
        "created_at": _iso(revision.created_at),
    }


def _event_dict(event: WorkflowEvent) -> dict[str, Any]:
    return {"id": event.id, "event_type": event.event_type, "status": event.status,
            "comment": event.comment, "actor_role": event.actor_role, "created_at": _iso(event.created_at)}


def _get_product(db: Session, product_id: int) -> Product:
    product = db.get(Product, product_id)
    if product is None:
        raise HTTPException(404, "Choose an existing product before checking this draft.")
    return product


def _run_check(db: Session, draft: Draft, text: str, role: str) -> dict[str, Any]:
    product = _get_product(db, draft.product_id)
    try:
        assets = json.loads(draft.assets_json or "[]")
        if not isinstance(assets, list):
            assets = []
    except (TypeError, json.JSONDecodeError):
        assets = []
    guideline_version = get_guideline_version(db)
    result = check_content(
        ContentObject(text=text, assets=assets), product,
        list(db.scalars(select(BannedTerm).order_by(BannedTerm.id))),
        list(db.scalars(select(ApprovedClaim).order_by(ApprovedClaim.id))),
        list(db.scalars(select(ToneRule).order_by(ToneRule.id))),
        list(db.scalars(select(Disclaimer).order_by(Disclaimer.id))),
        list(db.scalars(select(PreferredTerm).order_by(PreferredTerm.id))),
        session=db,
        guideline_version=guideline_version,
    )
    apply_feedback_downgrades(result["findings"], feedback_rates(db))
    latest = db.scalar(select(Revision).where(Revision.draft_id == draft.id).order_by(Revision.number.desc()).limit(1))
    revision = Revision(
        draft_id=draft.id, number=(latest.number + 1 if latest else 1), text=text,
        findings_json=json.dumps(result["findings"], ensure_ascii=False),
        verified_claims_json=json.dumps(result["verified_claims"], ensure_ascii=False),
        ai_available=result["ai_available"], ai_notice=result["ai_notice"], actor_role=role,
        guideline_version=guideline_version,
    )
    draft.text = text
    draft.updated_at = datetime.now(timezone.utc)
    db.add(revision)
    db.add(WorkflowEvent(draft_id=draft.id, event_type="brand_check", status=draft.status,
                         comment=f"Revision {revision.number}: {len(result['findings'])} finding(s).", actor_role=role))
    db.commit()
    db.refresh(revision)
    return {"draft": _draft_summary(db, draft), "revision": _revision_dict(revision, db)}


def _draft_summary(db: Session, draft: Draft) -> dict[str, Any]:
    product = db.get(Product, draft.product_id)
    revision = db.scalar(select(Revision).where(Revision.draft_id == draft.id).order_by(Revision.number.desc()).limit(1))
    creative = db.scalar(select(CreativeAsset).where(CreativeAsset.draft_id == draft.id))
    return {
        "id": draft.id, "text": draft.text, "channel": draft.channel, "product_id": draft.product_id,
        "creator_id": draft.creator_id,
        "assets": json.loads(draft.assets_json or "[]"),
        "creative": ({"source_filename": creative.source_filename, "content_type": creative.content_type,
                      "ocr_notice": creative.ocr_notice, "logo_notice": creative.logo_notice} if creative else None),
        "product_name": product.name if product else "Removed product", "status": draft.status,
        "created_at": _iso(draft.created_at), "updated_at": _iso(draft.updated_at),
        "latest_revision": _revision_dict(revision, db) if revision else None,
    }


@router.get("/samples")
def list_samples(db: Session = Depends(get_db)):
    return [{"id": x.id, "title": x.title, "text": x.text, "channel": x.channel} for x in db.scalars(select(SampleDraft).order_by(SampleDraft.id))]


@router.get("/drafts")
def list_drafts(db: Session = Depends(get_db)):
    drafts = db.scalars(select(Draft).order_by(Draft.updated_at.desc(), Draft.id.desc()))
    return [_draft_summary(db, draft) for draft in drafts]


@router.get("/drafts/{draft_id}/creative")
def get_creative_image(draft_id: int, db: Session = Depends(get_db)):
    if db.get(Draft, draft_id) is None:
        raise HTTPException(404, "Draft not found.")
    creative = db.scalar(select(CreativeAsset).where(CreativeAsset.draft_id == draft_id))
    if creative is None:
        raise HTTPException(404, "This draft has no uploaded creative image.")
    return Response(content=creative.image_bytes, media_type=creative.content_type,
                    headers={"Cache-Control": "no-store", "X-Content-Type-Options": "nosniff"})


@router.post("/drafts")
def create_draft(payload: DraftCreate, db: Session = Depends(get_db)):
    require_creator(payload.role)
    _get_product(db, payload.product_id)
    draft = Draft(text=payload.text, assets_json=json.dumps(payload.assets), creator_id=payload.creator_id,
                  channel=payload.channel, product_id=payload.product_id)
    db.add(draft)
    db.flush()
    db.add(WorkflowEvent(draft_id=draft.id, event_type="draft_created", status="draft", comment="Draft created.", actor_role=payload.role))
    db.commit()
    db.refresh(draft)
    return _draft_summary(db, draft)


@router.post("/check")
def check_new_draft(payload: DraftCreate, request: Request, db: Session = Depends(get_db)):
    require_creator(payload.role)
    enforce_check_rate_limit(db, request.client.host if request.client else "unknown")
    _get_product(db, payload.product_id)
    draft = Draft(text=payload.text, assets_json=json.dumps(payload.assets), creator_id=payload.creator_id,
                  channel=payload.channel, product_id=payload.product_id)
    db.add(draft)
    db.flush()
    db.add(WorkflowEvent(draft_id=draft.id, event_type="draft_created", status="draft", comment="Draft created.", actor_role=payload.role))
    db.commit()
    db.refresh(draft)
    result = _run_check(db, draft, payload.text, payload.role)
    return result


@router.post("/creative-check")
async def check_ad_creative(
    request: Request,
    file: UploadFile = File(...),
    channel: Channel = Form("Ad"),
    product_id: int = Form(..., gt=0),
    role: Role = Form("Creator"),
    creator_id: str = Form("unattributed-browser", min_length=1, max_length=80),
    db: Session = Depends(get_db),
):
    require_creator(role)
    payload = await file.read(MAX_CREATIVE_BYTES + 1)
    await file.close()
    try:
        metadata = validate_image_upload(file.filename or "", payload)
    except CreativeImageError as error:
        raise HTTPException(error.status_code, str(error)) from error
    _get_product(db, product_id)
    enforce_check_rate_limit(db, request.client.host if request.client else "unknown")
    extracted_text, ocr_notice = extract_ocr_text(payload)
    extracted_text = extracted_text[:MAX_CREATIVE_TEXT_CHARS]
    draft = Draft(
        text=extracted_text,
        assets_json=json.dumps([f"creative:{metadata['source_filename']}"]),
        creator_id=creator_id.strip() or "unattributed-browser",
        channel=channel,
        product_id=product_id,
    )
    db.add(draft)
    db.flush()
    creative = CreativeAsset(draft_id=draft.id, source_filename=metadata["source_filename"],
                             content_type=metadata["content_type"], image_bytes=payload,
                             ocr_notice=ocr_notice, logo_notice=None)
    db.add(creative)
    db.add(WorkflowEvent(draft_id=draft.id, event_type="draft_created", status="draft",
                         comment=f"Ad creative uploaded: {metadata['source_filename']}.", actor_role=role))
    db.commit()
    db.refresh(draft)

    result = _run_check(db, draft, extracted_text, role)
    logo = db.scalar(select(ApprovedLogoImage).order_by(ApprovedLogoImage.id.desc()).limit(1))
    match = find_approved_logo_match(payload, logo.image_bytes if logo else None)
    creative.logo_notice = match["notice"]
    db.add(creative)

    revision = db.scalar(select(Revision).where(Revision.draft_id == draft.id).order_by(Revision.number.desc()).limit(1))
    findings = json.loads(revision.findings_json or "[]") if revision else []
    if match["available"] and not match["matched"] and logo is not None:
        score = float(match["score"] or 0.0)
        confidence_label = "Moderate" if score < 0.25 else "Low"
        finding = {
            "type": "approved_logo_not_detected", "span": "", "start": -1, "end": -1,
            "explanation": "The approved logo image was not detected in this ad creative. Template matching looks for a close visual match; it does not understand altered or stylized logos.",
            "guideline_ref": f"approved_logo_image:{logo.id}",
            "evidence": [{"label": "Approved logo image", "detail": f"Admin reference: {logo.source_filename}.",
                          "guideline_ref": f"approved_logo_image:{logo.id}", "href": "guideline:approved_logo_image"}],
            "severity": "Medium", "suggestion": "Add the approved logo artwork or have a reviewer verify its placement manually.",
            "source": "Visual", "confidence_label": confidence_label,
            "uncertainty": f"Confidence label: {confidence_label}. Best template similarity was {score:.0%}; a transformed, recolored, rotated, or obscured logo may be missed.",
            "severity_downgraded_by_feedback": False,
        }
        apply_feedback_downgrades([finding], feedback_rates(db))
        findings.append(finding)
        findings.sort(key=lambda item: ({"High": 0, "Medium": 1, "Low": 2, "Info": 3}.get(item.get("severity"), 9),
                                        item.get("start", -1) if item.get("start", -1) >= 0 else len(extracted_text)))
        if revision:
            revision.findings_json = json.dumps(findings, ensure_ascii=False)
            db.add(WorkflowEvent(draft_id=draft.id, event_type="creative_logo_check", status=draft.status,
                                 comment=f"Approved logo not detected; {confidence_label.lower()} confidence label.", actor_role=role))
    db.commit()
    if revision:
        db.refresh(revision)
        result["revision"] = _revision_dict(revision, db)
    result["draft"] = _draft_summary(db, draft)
    if result.get("revision"):
        result["draft"]["latest_revision"] = result["revision"]
    return result


def _run_batch_texts(
    db: Session,
    request: Request,
    texts: list[str],
    channel: Channel,
    product_id: int,
    role: Role,
    creator_id: str = "unattributed-browser",
) -> dict[str, Any]:
    require_creator(role)
    _get_product(db, product_id)
    enforce_check_rate_limit(db, request.client.host if request.client else "unknown", cost=len(texts))
    items: list[dict[str, Any]] = []
    for index, text in enumerate(texts, start=1):
        draft = Draft(text=text, assets_json="[]", creator_id=creator_id, channel=channel, product_id=product_id)
        db.add(draft)
        db.flush()
        db.add(WorkflowEvent(draft_id=draft.id, event_type="draft_created", status="draft",
                             comment=f"Batch item {index} of {len(texts)}.", actor_role=role))
        db.commit()
        db.refresh(draft)
        result = _run_check(db, draft, text, role)
        revision = result["revision"]
        findings = revision["findings"]
        items.append({
            "draft": result["draft"], "revision": revision,
            "top_issue": findings[0]["type"] if findings else None,
        })
    return {"count": len(items), "items": items}


@router.post("/batch-check")
def batch_check(payload: BatchCheckRequest, request: Request, db: Session = Depends(get_db)):
    return _run_batch_texts(db, request, payload.texts, payload.channel, payload.product_id, payload.role, payload.creator_id)


@router.post("/batch-check/csv")
async def batch_check_csv(
    request: Request,
    file: UploadFile = File(...),
    channel: Channel = Form(...),
    product_id: int = Form(..., gt=0),
    role: Role = Form("Creator"),
    creator_id: str = Form("unattributed-browser", max_length=80),
    db: Session = Depends(get_db),
):
    require_creator(role)
    if not (file.filename or "").casefold().endswith(".csv"):
        raise HTTPException(422, "Upload a .csv file with a text column.")
    contents = await file.read(MAX_BATCH_BYTES + 1)
    await file.close()
    if len(contents) > MAX_BATCH_BYTES:
        raise HTTPException(413, "CSV is too large. Maximum upload size is 2 MB.")
    try:
        csv_text = contents.decode("utf-8-sig")
    except UnicodeDecodeError as exc:
        raise HTTPException(422, "CSV must be UTF-8 encoded.") from exc
    reader = csv.DictReader(io.StringIO(csv_text, newline=""), strict=True)
    original_headers = reader.fieldnames or []
    headers = [header.strip() for header in original_headers]
    if "text" not in headers:
        raise HTTPException(422, "CSV needs a column named text.")
    if len(headers) != len(set(headers)):
        raise HTTPException(422, "CSV column names must be unique.")
    text_key = original_headers[headers.index("text")]
    texts: list[str] = []
    try:
        for row_number, row in enumerate(reader, start=2):
            if None in row:
                raise HTTPException(422, f"CSV row {row_number} has more values than the header.")
            raw_text = row.get(text_key)
            if raw_text is None:
                if any(value not in (None, "") for value in row.values()):
                    raise HTTPException(422, f"CSV row {row_number} is missing its text value.")
                continue
            text = raw_text.strip()
            if not text:
                continue
            if len(text) > 25000:
                raise HTTPException(422, f"CSV row {row_number} exceeds the 25,000-character draft limit.")
            texts.append(text)
            if len(texts) > MAX_BATCH_ITEMS:
                raise HTTPException(422, f"CSV can contain at most {MAX_BATCH_ITEMS} non-empty drafts.")
    except csv.Error as exc:
        raise HTTPException(422, "Could not parse the CSV file.") from exc
    if not texts:
        raise HTTPException(422, "CSV must contain at least one non-empty draft in its text column.")
    _get_product(db, product_id)
    return _run_batch_texts(db, request, texts, channel, product_id, role, creator_id)


@router.get("/drafts/{draft_id}")
def get_draft(draft_id: int, db: Session = Depends(get_db)):
    draft = db.get(Draft, draft_id)
    if draft is None:
        raise HTTPException(404, "Draft not found.")
    return _draft_summary(db, draft)


@router.patch("/drafts/{draft_id}")
def edit_draft(draft_id: int, payload: DraftEdit, db: Session = Depends(get_db)):
    require_creator(payload.role)
    draft = db.get(Draft, draft_id)
    if draft is None:
        raise HTTPException(404, "Draft not found.")
    if draft.status not in {"draft", "changes_requested"}:
        raise HTTPException(409, "Only a draft or a draft with requested changes can be edited.")
    draft.text = payload.text
    draft.updated_at = datetime.now(timezone.utc)
    db.add(WorkflowEvent(draft_id=draft.id, event_type="draft_edited", status=draft.status, comment="Draft text edited.", actor_role=payload.role))
    db.commit()
    return _draft_summary(db, draft)


@router.post("/drafts/{draft_id}/check")
def rerun_check(draft_id: int, payload: DraftEdit, request: Request, db: Session = Depends(get_db)):
    require_creator(payload.role)
    enforce_check_rate_limit(db, request.client.host if request.client else "unknown")
    draft = db.get(Draft, draft_id)
    if draft is None:
        raise HTTPException(404, "Draft not found.")
    if draft.status not in {"draft", "changes_requested"}:
        raise HTTPException(409, "A submitted or approved draft cannot be re-checked until the review is complete.")
    return _run_check(db, draft, payload.text, payload.role)


@router.post("/drafts/{draft_id}/submit")
def submit_draft(draft_id: int, payload: SubmitRequest, db: Session = Depends(get_db)):
    require_creator(payload.role)
    draft = db.get(Draft, draft_id)
    if draft is None:
        raise HTTPException(404, "Draft not found.")
    if draft.status not in {"draft", "changes_requested"}:
        raise HTTPException(409, "Only a draft or a draft with requested changes can be submitted.")
    latest = db.scalar(select(Revision).where(Revision.draft_id == draft.id).order_by(Revision.number.desc()).limit(1))
    if latest is None:
        raise HTTPException(409, "Run a brand check before submitting this draft.")
    if latest.text != draft.text:
        raise HTTPException(409, "This draft changed after its last check. Re-run the brand check before submitting.")
    if latest.guideline_version != get_guideline_version(db):
        raise HTTPException(409, "Guidelines changed since this check. Re-run?")
    draft.status = "in_review"
    draft.updated_at = datetime.now(timezone.utc)
    db.add(WorkflowEvent(draft_id=draft.id, event_type="submitted_for_review", status=draft.status,
                         comment="Sent to a human reviewer. Nothing is auto-published.", actor_role=payload.role))
    db.commit()
    return _draft_summary(db, draft)


@router.post("/drafts/{draft_id}/decision")
def decide_draft(draft_id: int, payload: DecisionRequest, db: Session = Depends(get_db)):
    require_reviewer(payload.role)
    draft = db.get(Draft, draft_id)
    if draft is None:
        raise HTTPException(404, "Draft not found.")
    if draft.status != "in_review":
        raise HTTPException(409, "Only a draft in review can receive a reviewer decision.")
    if payload.action == "request_changes" and not payload.comment.strip():
        raise HTTPException(422, "Add a short reviewer comment when requesting changes.")
    draft.status = "approved" if payload.action == "approve" else "changes_requested"
    draft.updated_at = datetime.now(timezone.utc)
    event_type = "approved" if payload.action == "approve" else "changes_requested"
    db.add(WorkflowEvent(draft_id=draft.id, event_type=event_type, status=draft.status,
                         comment=payload.comment.strip(), actor_role=payload.role))
    db.commit()
    return _draft_summary(db, draft)


@router.get("/drafts/{draft_id}/comments")
def list_draft_comments(draft_id: int, db: Session = Depends(get_db)):
    if db.get(Draft, draft_id) is None:
        raise HTTPException(404, "Draft not found.")
    comments = db.scalars(select(DraftComment).where(DraftComment.draft_id == draft_id).order_by(DraftComment.created_at, DraftComment.id))
    return [{"id": item.id, "draft_id": item.draft_id, "actor_role": item.actor_role,
             "message": item.message, "created_at": _iso(item.created_at)} for item in comments]


@router.post("/drafts/{draft_id}/comments")
def add_draft_comment(draft_id: int, payload: DraftCommentCreate, db: Session = Depends(get_db)):
    draft = db.get(Draft, draft_id)
    if draft is None:
        raise HTTPException(404, "Draft not found.")
    comment = DraftComment(draft_id=draft_id, actor_role=payload.role, message=payload.message)
    db.add(comment)
    db.add(WorkflowEvent(draft_id=draft_id, event_type="comment_added", status=draft.status,
                         comment=payload.message, actor_role=payload.role))
    db.commit()
    db.refresh(comment)
    return {"id": comment.id, "draft_id": comment.draft_id, "actor_role": comment.actor_role,
            "message": comment.message, "created_at": _iso(comment.created_at)}


def _finding_for_review(db: Session, draft_id: int, revision_number: int, finding_index: int) -> tuple[Revision, dict[str, Any]]:
    if db.get(Draft, draft_id) is None:
        raise HTTPException(404, "Draft not found.")
    revision = db.scalar(select(Revision).where(Revision.draft_id == draft_id, Revision.number == revision_number))
    if revision is None:
        raise HTTPException(404, "Revision not found for this draft.")
    findings = json.loads(revision.findings_json or "[]")
    if finding_index < 0 or finding_index >= len(findings):
        raise HTTPException(404, "Finding not found in this revision.")
    return revision, findings[finding_index]


def _finding_review_record(db: Session, revision_id: int, finding_index: int) -> FindingReview:
    record = db.scalar(select(FindingReview).where(
        FindingReview.revision_id == revision_id, FindingReview.finding_index == finding_index,
    ))
    if record is None:
        record = FindingReview(revision_id=revision_id, finding_index=finding_index)
        db.add(record)
    return record


@router.put("/drafts/{draft_id}/revisions/{revision_number}/findings/{finding_index}/label")
def set_finding_reviewer_label(
    draft_id: int, revision_number: int, finding_index: int,
    payload: FindingLabelRequest, db: Session = Depends(get_db),
):
    require_reviewer(payload.role)
    revision, finding = _finding_for_review(db, draft_id, revision_number, finding_index)
    review = _finding_review_record(db, revision.id, finding_index)
    review.reviewer_label = payload.reviewer_label
    db.add(WorkflowEvent(
        draft_id=draft_id, event_type="finding_labeled", status="review_note",
        comment=f"{finding.get('type', 'Finding')} reviewer label: {payload.reviewer_label or 'cleared'} (future checks may adjust severity; saved revision unchanged).",
        actor_role=payload.role,
    ))
    db.commit()
    return _revision_dict(revision, db)


@router.post("/drafts/{draft_id}/revisions/{revision_number}/findings/{finding_index}/dismiss")
def dismiss_finding(
    draft_id: int, revision_number: int, finding_index: int,
    payload: FindingDismissRequest, db: Session = Depends(get_db),
):
    require_reviewer(payload.role)
    revision, finding = _finding_for_review(db, draft_id, revision_number, finding_index)
    review = _finding_review_record(db, revision.id, finding_index)
    review.dismissal_reason = payload.reason
    review.dismissed_by_role = payload.role
    review.dismissed_at = datetime.now(timezone.utc)
    evidence_span = finding.get("span") or finding.get("type", "finding")
    db.add(WorkflowEvent(
        draft_id=draft_id, event_type="finding_dismissed", status="review_note",
        comment=f"Dismissed finding “{evidence_span}” — Reason: {payload.reason}", actor_role=payload.role,
    ))
    db.commit()
    return _revision_dict(revision, db)


@router.get("/drafts/{draft_id}/history")
def draft_history(draft_id: int, db: Session = Depends(get_db)):
    draft = db.get(Draft, draft_id)
    if draft is None:
        raise HTTPException(404, "Draft not found.")
    revisions = db.scalars(select(Revision).where(Revision.draft_id == draft_id).order_by(Revision.number))
    events = db.scalars(select(WorkflowEvent).where(WorkflowEvent.draft_id == draft_id).order_by(WorkflowEvent.created_at, WorkflowEvent.id))
    return {"revisions": [_revision_dict(x, db) for x in revisions], "events": [_event_dict(x) for x in events]}


@router.get("/drafts/{draft_id}/compare")
def compare_draft_revisions(
    draft_id: int,
    left_revision: int = Query(..., ge=1),
    right_revision: int = Query(..., ge=1),
    db: Session = Depends(get_db),
):
    draft = db.get(Draft, draft_id)
    if draft is None:
        raise HTTPException(404, "Draft not found.")
    if left_revision == right_revision:
        raise HTTPException(422, "Choose two different revisions to compare.")
    left = db.scalar(select(Revision).where(Revision.draft_id == draft_id, Revision.number == left_revision))
    right = db.scalar(select(Revision).where(Revision.draft_id == draft_id, Revision.number == right_revision))
    if left is None:
        raise HTTPException(404, f"Revision {left_revision} was not found for this draft.")
    if right is None:
        raise HTTPException(404, f"Revision {right_revision} was not found for this draft.")

    left_lines = left.text.splitlines(keepends=True)
    right_lines = right.text.splitlines(keepends=True)
    inline_diff: list[dict[str, str]] = []
    matcher = difflib.SequenceMatcher(a=left_lines, b=right_lines, autojunk=False)
    for operation, left_start, left_end, right_start, right_end in matcher.get_opcodes():
        if operation == "equal":
            inline_diff.extend({"kind": "unchanged", "text": line} for line in left_lines[left_start:left_end])
        elif operation == "delete":
            inline_diff.extend({"kind": "removed", "text": line} for line in left_lines[left_start:left_end])
        elif operation == "insert":
            inline_diff.extend({"kind": "added", "text": line} for line in right_lines[right_start:right_end])
        else:
            inline_diff.extend({"kind": "removed", "text": line} for line in left_lines[left_start:left_end])
            inline_diff.extend({"kind": "added", "text": line} for line in right_lines[right_start:right_end])

    left_findings = json.loads(left.findings_json or "[]")
    right_findings = json.loads(right.findings_json or "[]")
    finding_key = lambda finding: tuple(str(finding.get(field, "")).strip().casefold() for field in ("type", "span", "guideline_ref"))
    left_keys = {finding_key(finding) for finding in left_findings}
    right_keys = {finding_key(finding) for finding in right_findings}
    return {
        "left_revision": _revision_dict(left, db),
        "right_revision": _revision_dict(right, db),
        "lines": inline_diff,
        "resolved_findings": [finding for finding in left_findings if finding_key(finding) not in right_keys],
        "new_findings": [finding for finding in right_findings if finding_key(finding) not in left_keys],
    }


@router.get("/evaluation")
def evaluation_info():
    dataset = load_evaluation_dataset()
    return {
        "dataset_id": dataset["dataset_id"],
        "dataset_version": dataset["dataset_version"],
        "case_count": len(dataset["cases"]),
        "cases": [{
            "id": case["id"], "title": case["title"], "text": case["text"],
            "expected_types": case["expected_types"],
        } for case in dataset["cases"]],
    }


@router.post("/evaluation/run")
def run_evaluation(role: Role = Query("Admin"), db: Session = Depends(get_db)):
    require_admin(role)
    dataset = load_evaluation_dataset()
    product = db.scalar(select(Product).order_by(Product.id).limit(1))
    if product is None:
        raise HTTPException(409, "Load demo brand data before running the evaluation.")
    banned_terms = list(db.scalars(select(BannedTerm).order_by(BannedTerm.id)))
    approved_claims = list(db.scalars(select(ApprovedClaim).order_by(ApprovedClaim.id)))
    tone_rules = list(db.scalars(select(ToneRule).order_by(ToneRule.id)))
    disclaimers = list(db.scalars(select(Disclaimer).order_by(Disclaimer.id)))
    preferred_terms = list(db.scalars(select(PreferredTerm).order_by(PreferredTerm.id)))
    guideline_version = get_guideline_version(db)
    ai_runner = AIAnalysisWrapper(session=db, guideline_version=guideline_version).analyze

    rule_predictions: dict[str, list[dict[str, Any]]] = {}
    ai_predictions: dict[str, list[dict[str, Any]]] = {}
    combined_predictions: dict[str, list[dict[str, Any]]] = {}
    ai_results: list[dict[str, Any]] = []
    for case in dataset["cases"]:
        result = check_content(
            ContentObject(text=case["text"], assets=[]), product, banned_terms, approved_claims,
            tone_rules, disclaimers, preferred_terms, ai_runner=ai_runner, session=db,
            guideline_version=guideline_version,
        )
        rule_predictions[case["id"]] = result["rule_findings"]
        ai_predictions[case["id"]] = result["ai_findings"]
        combined_predictions[case["id"]] = result["findings"]
        ai_results.append(result)

    rules_metrics = score_predictions(dataset["cases"], rule_predictions)
    ai_available = bool(ai_results) and all(item["ai_available"] for item in ai_results)
    # Never present a partial provider outage/cap result as a complete AI benchmark.
    if ai_available:
        ai_metrics = score_predictions(dataset["cases"], ai_predictions)
        combined_metrics = score_predictions(dataset["cases"], combined_predictions)
        fallback = False
        notice = None
    else:
        ai_metrics = None
        combined_metrics = rules_metrics
        fallback = True
        notice = next((item["ai_notice"] for item in ai_results if item.get("ai_notice")), None)

    record_audit(db, actor_role="Admin", action="evaluation_run")
    db.commit()
    return {
        "dataset_id": dataset["dataset_id"],
        "dataset_version": dataset["dataset_version"],
        "case_count": len(dataset["cases"]),
        "ai_configured": ai_is_configured(),
        "ai_available": ai_available,
        "ai_notice": notice,
        "combined_uses_rules_only_fallback": fallback,
        "metrics": {"rules_only": rules_metrics, "ai_only": ai_metrics, "combined": combined_metrics},
    }


@router.get("/dashboard")
def dashboard(db: Session = Depends(get_db)):
    revisions = list(db.scalars(select(Revision)))
    all_findings = [finding for revision in revisions for finding in json.loads(revision.findings_json or "[]")]
    by_type: dict[str, int] = {}
    by_severity: dict[str, int] = {"High": 0, "Medium": 0, "Low": 0, "Info": 0}
    for item in all_findings:
        by_type[item.get("type", "other")] = by_type.get(item.get("type", "other"), 0) + 1
        severity = item.get("severity", "Low")
        by_severity[severity] = by_severity.get(severity, 0) + 1
    drafts = list(db.scalars(select(Draft).order_by(Draft.updated_at.desc(), Draft.id.desc())))
    latest_by_draft: dict[int, Revision] = {}
    for revision in revisions:
        saved = latest_by_draft.get(revision.draft_id)
        if saved is None or revision.number > saved.number:
            latest_by_draft[revision.draft_id] = revision
    draft_health = []
    for draft in drafts:
        revision = latest_by_draft.get(draft.id)
        if revision is not None:
            score = calculate_health_score(json.loads(revision.findings_json or "[]"))["score"]
            draft_health.append({"draft_id": draft.id, "label": f"Draft #{draft.id}", "score": score})
    average_health_score = round(sum(item["score"] for item in draft_health) / len(draft_health), 1) if draft_health else None
    events = list(db.scalars(select(WorkflowEvent).where(WorkflowEvent.event_type.in_(["approved", "changes_requested"]))))
    decisions = len(events)
    approved = sum(1 for event in events if event.event_type == "approved")
    changes = sum(1 for event in events if event.event_type == "changes_requested")
    return {
        "by_type": [{"type": key, "count": value} for key, value in sorted(by_type.items(), key=lambda x: (-x[1], x[0]))],
        "by_severity": [{"severity": key, "count": by_severity[key]} for key in ("High", "Medium", "Low", "Info")],
        "top_issues": [{"type": key, "count": value} for key, value in sorted(by_type.items(), key=lambda x: (-x[1], x[0]))[:5]],
        "approval_rate": round(approved / decisions * 100, 1) if decisions else 0,
        "changes_requested_rate": round(changes / decisions * 100, 1) if decisions else 0,
        "decisions": decisions,
        "drafts_total": len(drafts),
        "in_review": sum(1 for draft in drafts if draft.status == "in_review"),
        "approved": sum(1 for draft in drafts if draft.status == "approved"),
        "average_health_score": average_health_score,
        "draft_health": draft_health[:10],
        **feedback_dashboard(db),
    }


@router.post("/demo/load")
def load_demo(role: Role = Query("Creator"), db: Session = Depends(get_db)):
    seed_demo(db)
    record_audit(db, actor_role=role, action="demo_data_loaded")
    db.commit()
    return {"loaded": True, "brand": "DemoWear", "preserved_existing_work": True}


@router.post("/demo/reset")
def reset_demo(role: Role = Query("Admin"), db: Session = Depends(get_db)):
    require_admin(role)
    seed_demo(db, reset=True)
    record_audit(db, actor_role=role, action="demo_data_reset")
    db.commit()
    return {"reset": True, "brand": "DemoWear"}


@router.post("/check/pdf")
async def check_pdf(request: Request, file: UploadFile = File(...), channel: Channel = Form(...), product_id: int = Form(...), role: Role = Form("Creator"), creator_id: str = Form("unattributed-browser", max_length=80), db: Session = Depends(get_db)):
    require_creator(role)
    enforce_check_rate_limit(db, request.client.host if request.client else "unknown")
    if file.content_type not in {"application/pdf", "application/octet-stream"}:
        raise HTTPException(415, "Upload a PDF file to extract its text.")
    content = await file.read(MAX_PDF_BYTES + 1)
    if len(content) > MAX_PDF_BYTES:
        raise HTTPException(413, "PDF is too large. Maximum upload size is 2 MB.")
    try:
        text = extract_pdf_text(content)
    except ValueError as error:
        raise HTTPException(400, str(error)) from error
    _get_product(db, product_id)
    draft = Draft(text=text, creator_id=creator_id, channel=channel, product_id=product_id)
    db.add(draft)
    db.flush()
    db.add(WorkflowEvent(draft_id=draft.id, event_type="draft_created", status="draft", comment=f"Text extracted from {file.filename or 'uploaded PDF'}.", actor_role=role))
    db.commit()
    db.refresh(draft)
    return _run_check(db, draft, text, role)


@router.get("/drafts/{draft_id}/report.pdf")
def export_report(draft_id: int, db: Session = Depends(get_db)):
    draft = db.get(Draft, draft_id)
    if draft is None:
        raise HTTPException(404, "Draft not found.")
    summary = _draft_summary(db, draft)
    revisions = list(db.scalars(select(Revision).where(Revision.draft_id == draft.id).order_by(Revision.number)))
    history = draft_history(draft_id, db)["events"]
    pdf_data = create_review_pdf(summary, [_revision_dict(item, db) for item in revisions], history)
    return Response(content=pdf_data, media_type="application/pdf", headers={"Content-Disposition": f'attachment; filename="inkloom-review-{draft_id}.pdf"'})
