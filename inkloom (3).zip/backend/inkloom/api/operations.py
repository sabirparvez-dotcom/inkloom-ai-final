from __future__ import annotations

import csv
import io
from datetime import timezone

from fastapi import APIRouter, Depends, Query, Request
from fastapi.responses import Response
from sqlalchemy import func, select, text
from sqlalchemy.exc import SQLAlchemyError
from sqlalchemy.orm import Session

from .common import get_db, require_admin
from ..models import AuditLogEntry, GuidelineState
from ..schemas import Role
from ..services.ai import ai_calls_today, ai_is_configured, daily_call_cap

router = APIRouter(prefix="/api", tags=["operations"])


def _iso(value) -> str:
    if value.tzinfo is None:
        return value.replace(tzinfo=timezone.utc).isoformat()
    return value.isoformat()


def _entry_dict(row: AuditLogEntry) -> dict[str, object]:
    return {
        "id": str(row.id),
        "actor_role": row.actor_role,
        "action": row.action,
        "draft_id": row.draft_id,
        "draft_title": row.draft_title,
        "created_at": _iso(row.created_at),
    }


def _audit_rows(db: Session, limit: int) -> list[AuditLogEntry]:
    return list(db.scalars(
        select(AuditLogEntry)
        .order_by(AuditLogEntry.created_at.desc(), AuditLogEntry.id.desc())
        .limit(limit)
    ))


@router.get("/audit-log")
def audit_log(role: Role = Query("Admin"), limit: int = Query(200, ge=1, le=500), db: Session = Depends(get_db)):
    require_admin(role)
    total = db.scalar(select(func.count()).select_from(AuditLogEntry)) or 0
    return {"items": [_entry_dict(row) for row in _audit_rows(db, limit)], "total": total}


def _spreadsheet_safe(value: object) -> str:
    text_value = "" if value is None else str(value)
    if text_value.startswith(("=", "+", "-", "@", "\t", "\r")):
        return "'" + text_value
    return text_value


@router.get("/audit-log.csv")
def audit_log_csv(role: Role = Query("Admin"), db: Session = Depends(get_db)):
    require_admin(role)
    output = io.StringIO(newline="")
    writer = csv.writer(output)
    writer.writerow(["role", "action", "draft_id", "draft_title", "timestamp"])
    for row in _audit_rows(db, 500):
        writer.writerow([
            _spreadsheet_safe(row.actor_role), _spreadsheet_safe(row.action),
            _spreadsheet_safe(row.draft_id), _spreadsheet_safe(row.draft_title),
            _spreadsheet_safe(_iso(row.created_at)),
        ])
    return Response(
        output.getvalue(), media_type="text/csv; charset=utf-8",
        headers={"Content-Disposition": 'attachment; filename="inkloom-audit-log.csv"'},
    )


@router.get("/status")
def service_status(request: Request, db: Session = Depends(get_db)):
    database_health = "ok"
    guideline_version = None
    calls_today = 0
    try:
        db.execute(text("SELECT 1"))
        guideline_version = db.scalar(select(GuidelineState.version).where(GuidelineState.id == 1))
        calls_today = ai_calls_today(db)
    except SQLAlchemyError:
        database_health = "unavailable"
        db.rollback()
    configured = ai_is_configured()
    return {
        "database_health": database_health,
        "ai_configured": configured,
        "ai_reachability": "unknown_not_probed" if configured else "not_configured",
        "ai_calls_used_today": calls_today,
        "ai_daily_cap": daily_call_cap(),
        "guideline_version": guideline_version,
        "app_version": request.app.version,
    }
