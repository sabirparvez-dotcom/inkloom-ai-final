from __future__ import annotations

import os
from pathlib import Path
from typing import Any

from sqlalchemy import create_engine, select
from sqlalchemy.engine import Engine
from sqlalchemy.orm import DeclarativeBase, Session, sessionmaker


class Base(DeclarativeBase):
    pass


def make_engine(database_url: str | None = None) -> Engine:
    url = database_url or os.getenv("DATABASE_URL", "sqlite:///./inkloom.db")
    kwargs: dict[str, Any] = {"pool_pre_ping": True}
    if url.startswith("sqlite"):
        kwargs["connect_args"] = {"check_same_thread": False}
        if url.startswith("sqlite:///") and url != "sqlite:///:memory:":
            db_file = url.removeprefix("sqlite:///").split("?", 1)[0]
            if db_file and db_file != ":memory:":
                Path(db_file).expanduser().resolve().parent.mkdir(parents=True, exist_ok=True)
    return create_engine(url, **kwargs)


def make_session_factory(engine: Engine) -> sessionmaker[Session]:
    return sessionmaker(bind=engine, autoflush=False, expire_on_commit=False)


def init_database(engine: Engine) -> None:
    from . import models  # noqa: F401

    Base.metadata.create_all(bind=engine)
    if engine.dialect.name == "sqlite":
        with engine.begin() as connection:
            columns = {row[1] for row in connection.exec_driver_sql("PRAGMA table_info(drafts)")}
            if columns and "assets_json" not in columns:
                connection.exec_driver_sql("ALTER TABLE drafts ADD COLUMN assets_json TEXT NOT NULL DEFAULT '[]'")
            if columns and "creator_id" not in columns:
                connection.exec_driver_sql("ALTER TABLE drafts ADD COLUMN creator_id VARCHAR(80) NOT NULL DEFAULT 'legacy-browser'")
            revision_columns = {row[1] for row in connection.exec_driver_sql("PRAGMA table_info(revisions)")}
            if revision_columns and "guideline_version" not in revision_columns:
                connection.exec_driver_sql("ALTER TABLE revisions ADD COLUMN guideline_version INTEGER NOT NULL DEFAULT 1")


def seed_demo(session: Session, *, reset: bool = False) -> None:
    from .models import (
        ApprovedClaim,
        ApprovedLogoImage,
        BannedTerm,
        Brand,
        Disclaimer,
        Draft,
        DraftComment,
        EvidenceDocument,
        CreativeAsset,
        FindingReview,
        GuidelineState,
        LogoVersion,
        PreferredTerm,
        Product,
        ReviewerFeedbackExample,
        Revision,
        SampleDraft,
        ToneRule,
        WorkflowEvent,
    )

    if session.get(GuidelineState, 1) is None:
        session.add(GuidelineState(id=1, version=1))
        session.flush()
    if reset:
        for model in (WorkflowEvent, DraftComment, FindingReview, ReviewerFeedbackExample, CreativeAsset, Revision, Draft, ApprovedLogoImage, EvidenceDocument, SampleDraft, LogoVersion, Disclaimer, ToneRule, ApprovedClaim, PreferredTerm, BannedTerm, Product, Brand):
            session.query(model).delete(synchronize_session=False)
        session.commit()
    elif session.scalar(select(Brand.id).limit(1)) is not None:
        if get_guideline_version(session) == 1 and session.scalar(select(PreferredTerm.id).limit(1)) is None:
            session.add(PreferredTerm(term="cheap", preferred="affordable"))
            bump_guideline_version(session)
        added_evidence = _seed_evidence_document(session)
        if added_evidence:
            bump_guideline_version(session)
        _seed_reviewer_feedback(session)
        session.commit()
        return

    brand = Brand(name="DemoWear")
    product = Product(name="Classic T-shirt", approved_price=599, material="100% cotton")
    session.add_all([
        brand,
        product,
        BannedTerm(term="cheapest"),
        BannedTerm(term="guaranteed"),
        BannedTerm(term="100% safe"),
        PreferredTerm(term="cheap", preferred="affordable"),
        ApprovedClaim(claim="Made with 100% cotton", evidence="Cotton Certificate #CC-2026-14"),
        ToneRule(name="Clear", description="Use clear, easy-to-understand language."),
        ToneRule(name="Professional", description="Keep a professional, helpful tone."),
        ToneRule(name="Exclamation marks", description="Use no more than one exclamation mark.", threshold=1),
        ToneRule(name="ALL-CAPS words", description="Avoid words written entirely in capital letters."),
        Disclaimer(phrase="T&C apply", applies_to="price or discount posts"),
        LogoVersion(version="v3", approved=True),
        SampleDraft(title="Price mismatch + unsupported superlative", text="Premium T-shirt — only ₹499! Best quality in India", channel="Instagram"),
        SampleDraft(title="Evidence-backed and compliant", text="Made with 100% cotton. Classic T-shirt at ₹599. T&C apply.", channel="Instagram"),
        SampleDraft(title="Banned terms", text="Guaranteed comfort — the cheapest tee around, and 100% safe.", channel="Ad"),
        SampleDraft(title="Professional product description", text="Meet your everyday T-shirt, made with 100% cotton.", channel="Website"),
    ])
    if reset:
        bump_guideline_version(session)
    _seed_evidence_document(session)
    _seed_reviewer_feedback(session)
    session.commit()


def _seed_evidence_document(session: Session) -> bool:
    from .models import EvidenceDocument

    title = "Cotton Certificate CC-2026-14"
    if session.scalar(select(EvidenceDocument.id).where(EvidenceDocument.title == title).limit(1)) is not None:
        return False
    session.add(EvidenceDocument(
        title=title,
        source_filename="CC-2026-14-demo.txt",
        extracted_text="Cotton Certificate CC-2026-14. DemoWear Classic T-shirt is made with 100% cotton. This sample record is seeded demo evidence for review and must not be treated as a real-world certificate.",
    ))
    return True


def _seed_reviewer_feedback(session: Session) -> None:
    from .models import ReviewerFeedbackExample

    if session.scalar(select(ReviewerFeedbackExample.id).limit(1)) is not None:
        return
    session.add_all([
        ReviewerFeedbackExample(rule_key="price_mismatch", reviewer_label="false_positive", creator_id="demo-creator-a", finding_span="₹499"),
        ReviewerFeedbackExample(rule_key="price_mismatch", reviewer_label="false_positive", creator_id="demo-creator-a", finding_span="₹499 sale copy"),
        ReviewerFeedbackExample(rule_key="price_mismatch", reviewer_label="valid", creator_id="demo-creator-b", finding_span="₹499"),
    ])


def get_guideline_version(session: Session) -> int:
    from .models import GuidelineState

    state = session.get(GuidelineState, 1)
    if state is None:
        state = GuidelineState(id=1, version=1)
        session.add(state)
        session.flush()
    return state.version


def bump_guideline_version(session: Session) -> int:
    from .models import GuidelineState, utcnow

    state = session.get(GuidelineState, 1)
    if state is None:
        state = GuidelineState(id=1, version=1)
        session.add(state)
        session.flush()
    state.version += 1
    state.updated_at = utcnow()
    return state.version
